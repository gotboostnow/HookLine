"""Reusable view mixins."""

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.core.exceptions import PermissionDenied


class StaffRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Redirect anonymous users to login and return 403 for signed-in non-staff."""

    def test_func(self) -> bool:
        return bool(self.request.user.is_authenticated and self.request.user.is_staff)

    def handle_no_permission(self):
        if self.request.user.is_authenticated:
            raise PermissionDenied("Staff access is required.")
        return super().handle_no_permission()
