"""Extra response headers for the demo and recipient surfaces."""

from django.conf import settings


class DevNullOriginMiddleware:
    """Ignore opaque `null` Origins from sandboxed editor previews in DEBUG.

    Production never reaches this branch. It exists so local development works
    in embedded browser panes that send `Origin: null` instead of a real URL.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if settings.DEBUG and request.META.get("HTTP_ORIGIN") == "null":
            request.META.pop("HTTP_ORIGIN", None)
        return self.get_response(request)


class PermissionsPolicyMiddleware:
    """Disable powerful browser features that Hookline never uses."""

    POLICY = "camera=(), microphone=(), geolocation=(), payment=(), usb=()"

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response.setdefault("Permissions-Policy", self.POLICY)
        return response
