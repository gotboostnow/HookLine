"""Create the Northwind Logistics demo dataset."""

from __future__ import annotations

import os
import random
import secrets
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from campaigns.models import Campaign, CampaignRecipient
from core.models import Organization
from lures.models import LureTemplate
from targets.models import Group, Target
from tracking.models import TrackingEvent

DEMO_ORG_NAME = "Northwind Logistics"
DEMO_DOMAIN = "northwind.example"
TARGET_COUNT = 200
Q3_CAMPAIGN = "Q3 Invoice Review"
DRAFT_CAMPAIGN = "October Password Reset"
RNG_SEED = 20261124

FIRST_NAMES = [
    "Alex",
    "Jordan",
    "Priya",
    "Mateo",
    "Sofia",
    "Noah",
    "Ava",
    "Liam",
    "Mia",
    "Ethan",
    "Chloe",
    "Owen",
    "Nora",
    "Mason",
    "Layla",
    "Leo",
    "Zoe",
    "Hugo",
    "Ivy",
    "Sam",
]

LAST_NAMES = [
    "Chen",
    "Patel",
    "Garcia",
    "Kim",
    "Novak",
    "Silva",
    "Okafor",
    "Haddad",
    "Nguyen",
    "Kowalski",
    "Rossi",
    "Dubois",
    "Andersen",
    "Mensah",
    "Tanaka",
    "Rivera",
    "Fischer",
    "Ali",
    "Costa",
    "Ivanov",
]

DEPARTMENT_COUNTS = {
    "Finance": 24,
    "HR": 12,
    "Sales": 40,
    "Operations": 48,
    "IT": 18,
    "Customer Support": 58,
}

EXCLUSIONS = [
    ("Operations", "On parental leave"),
    ("Finance", "Legal hold"),
    ("Sales", "Opted out of simulations"),
]

INVOICE_LURE = {
    "name": "Supplier invoice overdue",
    "description": "A fake supplier invoice that uses authority and a same-day deadline.",
    "principles": ["authority", "urgency"],
    "difficulty": LureTemplate.Difficulty.MEDIUM,
    "sender_name": "Brightline Supplies Billing",
    "sender_email": "billing@brightline-supplies.example",
    "subject": "Invoice INV-4821 — payment due today",
    "body_html": (
        "<p>Hi {{ first_name }},</p>"
        "<p>Invoice <strong>INV-4821</strong> from Brightline Supplies is ready "
        "for review. The total is <strong>$4,860.00</strong> and payment is due "
        "today to avoid a late fee.</p>"
        "<p>Please review the invoice in the supplier portal:</p>"
        '<p><a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a></p>'
        "<p>Thanks,<br>Brightline Accounts</p>"
    ),
    "cta_text": "Review invoice",
    "red_flags": [
        "The invoice was unexpected and does not reference a purchase order you recognize.",
        "The sender's domain is not one your finance team normally uses.",
        "The message uses a same-day deadline to rush you.",
        "The payment link asks you to review billing outside your normal procurement process.",
    ],
}

PASSWORD_LURE = {
    "name": "Password expiry notice",
    "description": "A fake IT notice that uses fear of lost access and a same-day deadline.",
    "principles": ["fear", "urgency"],
    "difficulty": LureTemplate.Difficulty.EASY,
    "sender_name": "Northwind IT Service Desk",
    "sender_email": "it-helpdesk@northwind-support.example",
    "subject": "Action required: password expires today",
    "body_html": (
        "<p>Hi {{ first_name }},</p>"
        "<p>Our records show that your Northwind Logistics password expires today. "
        "To avoid losing access to email and shared files, renew your access now.</p>"
        '<p><a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a></p>'
        "<p>Northwind IT Service Desk<br>Ext. 4100</p>"
    ),
    "cta_text": "Renew access",
    "red_flags": [
        "The display name says Northwind IT, but the address is on a different domain.",
        "It uses fear of losing access to push you to act immediately.",
        "IT does not ask you to renew access through a link in an email.",
        "The link text does not say where it actually goes.",
    ],
}


class Command(BaseCommand):
    help = "Create the Northwind Logistics demo organization, targets, lures, and campaigns."

    def add_arguments(self, parser):
        parser.add_argument(
            "--reset",
            action="store_true",
            help="Delete existing Hookline data before seeding.",
        )
        parser.add_argument(
            "--with-admin",
            action="store_true",
            help="Create or update an admin superuser and print a generated password.",
        )

    def handle(self, *args, **options):
        output: list[str] = []

        with transaction.atomic():
            if options["reset"]:
                self._wipe()

            organization = self._seed_organization()
            targets = self._seed_targets(organization)
            self._seed_groups(organization)
            lures = self._seed_lures(organization)

            demo_user = self._demo_admin()
            if options["with_admin"]:
                admin_user, password = self._admin_user()
                demo_user = admin_user
                output.append(f"Admin username: {admin_user.username}")
                output.append(f"Admin password: {password}")

            _, recipients, clicked, reported = self._seed_active_campaign(
                organization, lures["invoice"], demo_user
            )
            self._seed_draft_campaign(organization, lures["password"], demo_user)

            excluded = targets.filter(is_excluded=True).count()
            output.extend(
                [
                    "Hookline demo data ready.",
                    f"  Organization: {organization.name} ({organization.domain})",
                    f"  Targets: {targets.count()} ({excluded} excluded)",
                    "  Groups: Finance, All Staff, Executives",
                    f"  Lures: {len(lures)}",
                    (
                        f"  Campaigns: {Q3_CAMPAIGN} (active, {len(recipients)} recipients, "
                        f"{clicked} clicks, {reported} reports); {DRAFT_CAMPAIGN} (draft)"
                    ),
                ]
            )
            output.extend(self._sample_urls(recipients))

        for line in output:
            self.stdout.write(line)

    def _wipe(self) -> None:
        TrackingEvent.objects.all().delete()
        CampaignRecipient.objects.all().delete()
        Campaign.objects.all().delete()
        Group.objects.all().delete()
        LureTemplate.objects.all().delete()
        Target.objects.all().delete()
        Organization.objects.all().delete()

    def _seed_organization(self) -> Organization:
        organization = Organization.load()
        organization.name = DEMO_ORG_NAME
        organization.domain = DEMO_DOMAIN
        organization.retention_days = 90
        organization.save()
        return organization

    def _seed_targets(self, organization: Organization):
        plan: list[str] = []
        for department, count in DEPARTMENT_COUNTS.items():
            plan.extend([department] * count)

        rng = random.Random(RNG_SEED)
        rng.shuffle(plan)

        for index, department in enumerate(plan):
            first_name = FIRST_NAMES[index % len(FIRST_NAMES)]
            last_name = LAST_NAMES[(index // len(FIRST_NAMES)) % len(LAST_NAMES)]
            email = f"{first_name.lower()}.{last_name.lower()}@northwind.example"
            Target.objects.update_or_create(
                organization=organization,
                email=email,
                defaults={
                    "first_name": first_name,
                    "last_name": last_name,
                    "department": department,
                    "is_excluded": False,
                    "exclusion_reason": "",
                },
            )

        targets = Target.objects.filter(organization=organization)
        for department, reason in EXCLUSIONS:
            target = targets.filter(department=department).first()
            if target:
                target.mark_excluded(reason)

        return targets

    def _seed_groups(self, organization: Organization) -> None:
        all_targets = list(Target.objects.filter(organization=organization))
        finance = [target for target in all_targets if target.department == "Finance"]
        executives = all_targets[::17][:12]

        groups = [
            ("All Staff", "Everyone in the demo company.", all_targets),
            ("Finance", "The finance team.", finance),
            ("Executives", "A small leadership sample.", executives),
        ]
        for name, description, members in groups:
            group, _ = Group.objects.update_or_create(
                organization=organization,
                name=name,
                defaults={"description": description},
            )
            group.targets.set(members)

    def _seed_lures(self, organization: Organization) -> dict[str, LureTemplate]:
        lures: dict[str, LureTemplate] = {}
        for key, spec in (("invoice", INVOICE_LURE), ("password", PASSWORD_LURE)):
            lure, _ = LureTemplate.objects.update_or_create(
                organization=organization,
                name=spec["name"],
                defaults={
                    "description": spec["description"],
                    "principles": spec["principles"],
                    "difficulty": spec["difficulty"],
                    "sender_name": spec["sender_name"],
                    "sender_email": spec["sender_email"],
                    "subject": spec["subject"],
                    "body_html": spec["body_html"],
                    "cta_text": spec["cta_text"],
                    "red_flags": spec["red_flags"],
                    "is_active": True,
                },
            )
            lures[key] = lure
        return lures

    def _demo_admin(self):
        User = get_user_model()
        user, created = User.objects.get_or_create(
            username="demo-admin",
            defaults={
                "email": "dana.ruiz@northwind.example",
                "first_name": "Dana",
                "last_name": "Ruiz",
                "is_staff": True,
                "is_active": True,
            },
        )
        if created:
            user.set_unusable_password()
            user.save(update_fields=["password"])
        return user

    def _admin_user(self):
        User = get_user_model()
        password = secrets.token_urlsafe(12)
        user, _ = User.objects.get_or_create(
            username="admin",
            defaults={
                "email": "admin@northwind.example",
                "first_name": "Demo",
                "last_name": "Admin",
            },
        )
        user.is_staff = True
        user.is_superuser = True
        user.is_active = True
        user.set_password(password)
        user.save()
        return user, password

    def _seed_active_campaign(
        self,
        organization: Organization,
        lure: LureTemplate,
        created_by,
    ):
        Campaign.objects.filter(name__in=[Q3_CAMPAIGN, DRAFT_CAMPAIGN]).delete()

        now = timezone.now()
        launched_at = now - timedelta(days=6, hours=2)
        campaign = Campaign.objects.create(
            organization=organization,
            name=Q3_CAMPAIGN,
            lure=lure,
            status=Campaign.Status.ACTIVE,
            reporting_mode=Campaign.ReportingMode.NAMED,
            authorized_by="Dana Ruiz, IT Manager",
            authorization_scope=(
                "All Northwind staff, Q3 2026 security-awareness exercise. Approved by the COO."
            ),
            authorization_acknowledged=True,
            authorized_at=launched_at - timedelta(days=1),
            created_by=created_by,
            launched_at=launched_at,
        )

        eligible = list(
            Target.objects.filter(organization=organization, is_excluded=False).order_by("id")
        )
        recipients = [
            CampaignRecipient.objects.create(
                campaign=campaign,
                target=target,
                sent_at=launched_at,
            )
            for target in eligible
        ]

        rng = random.Random(RNG_SEED)
        click_count = round(len(recipients) * 0.38)
        report_count = round(len(recipients) * 0.12)
        overlap_count = round(report_count * 0.35)

        clickers = rng.sample(recipients, click_count)
        clicker_ids = {recipient.pk for recipient in clickers}
        non_clickers = [recipient for recipient in recipients if recipient.pk not in clicker_ids]
        overlap = rng.sample(clickers, overlap_count)
        reporters_only = rng.sample(non_clickers, report_count - overlap_count)

        click_times: dict[int, object] = {}
        for recipient in clickers:
            occurred_at = launched_at + timedelta(minutes=rng.randint(45, 5 * 24 * 60))
            self._record_event(
                recipient,
                TrackingEvent.EventType.CLICK,
                occurred_at,
                "clicked_at",
            )
            click_times[recipient.pk] = occurred_at

        for recipient in overlap:
            occurred_at = click_times[recipient.pk] + timedelta(minutes=rng.randint(10, 180))
            self._record_event(
                recipient,
                TrackingEvent.EventType.REPORT,
                occurred_at,
                "reported_at",
            )

        for recipient in reporters_only:
            occurred_at = launched_at + timedelta(minutes=rng.randint(45, 5 * 24 * 60))
            self._record_event(
                recipient,
                TrackingEvent.EventType.REPORT,
                occurred_at,
                "reported_at",
            )

        return campaign, recipients, click_count, report_count

    def _record_event(self, recipient, event_type: str, occurred_at, field: str) -> None:
        setattr(recipient, field, occurred_at)
        recipient.save(update_fields=[field])
        event = TrackingEvent.objects.create(recipient=recipient, event_type=event_type)
        TrackingEvent.objects.filter(pk=event.pk).update(occurred_at=occurred_at)

    def _seed_draft_campaign(
        self,
        organization: Organization,
        lure: LureTemplate,
        created_by,
    ) -> None:
        campaign = Campaign.objects.create(
            organization=organization,
            name=DRAFT_CAMPAIGN,
            lure=lure,
            status=Campaign.Status.DRAFT,
            reporting_mode=Campaign.ReportingMode.AGGREGATE,
            created_by=created_by,
        )
        for target in Target.objects.filter(organization=organization, is_excluded=False).order_by(
            "id"
        ):
            CampaignRecipient.objects.create(campaign=campaign, target=target)

    def _sample_urls(self, recipients) -> list[str]:
        base_url = os.environ.get("HOOKLINE_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
        clicked_sample = next(
            recipient for recipient in recipients if recipient.clicked_at is not None
        )
        reported_sample = next(
            recipient
            for recipient in recipients
            if recipient.reported_at is not None and recipient.clicked_at is None
        )
        no_action_sample = next(
            recipient
            for recipient in recipients
            if recipient.clicked_at is None and recipient.reported_at is None
        )

        return [
            "Sample recipient links (Q3 campaign is active):",
            f"  Clicked inbox:      {base_url}/i/{clicked_sample.token}/",
            f"  Clicked education:  {base_url}/education/{clicked_sample.token}/",
            f"  Reported inbox:     {base_url}/i/{reported_sample.token}/",
            f"  No-action inbox:    {base_url}/i/{no_action_sample.token}/",
        ]
