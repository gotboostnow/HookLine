"""Delete tracking events outside the organization's retention window."""

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from core.models import Organization
from tracking.models import TrackingEvent


class Command(BaseCommand):
    help = "Delete tracking events older than Organization.retention_days."

    def handle(self, *args, **options):
        organization = Organization.load()
        cutoff = timezone.now() - timedelta(days=organization.retention_days)
        deleted, _ = TrackingEvent.objects.filter(occurred_at__lt=cutoff).delete()
        self.stdout.write(f"Deleted {deleted} tracking event(s) older than {cutoff.date()}.")
