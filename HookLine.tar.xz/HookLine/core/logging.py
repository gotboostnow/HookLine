"""Logging helpers for Hookline."""

import logging
import re

TOKEN_ROUTE_RE = re.compile(r"(/(?:i|t|education)/)[^/\s?]+")


class RedactRecipientRoutesFilter(logging.Filter):
    """Replace capability tokens in recipient routes before they hit logs."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self._redact(record.msg)
        if isinstance(record.args, tuple):
            record.args = tuple(self._redact(arg) for arg in record.args)
        elif isinstance(record.args, dict):
            record.args = {key: self._redact(value) for key, value in record.args.items()}
        return True

    @staticmethod
    def _redact(value: object) -> object:
        if isinstance(value, str):
            return TOKEN_ROUTE_RE.sub(r"\1<redacted>", value)
        return value
