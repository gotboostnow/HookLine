from django.urls import path

from . import views

urlpatterns = [
    path("", views.DashboardView.as_view(), name="dashboard"),
    path("settings/", views.SettingsView.as_view(), name="settings"),
    path("health/", views.health, name="health"),
]
