"""Small template filters shared across admin pages."""

from django import template

register = template.Library()


@register.filter
def percent(value) -> str:
    """Format a 0–1 rate as a whole percentage."""
    if value is None:
        return "0%"
    return f"{float(value) * 100:.0f}%"
