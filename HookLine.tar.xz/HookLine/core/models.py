"""Core models for Hookline."""

from django.db import models


class Organization(models.Model):
    """The single organization that owns this Hookline instance."""

    id = models.PositiveSmallIntegerField(primary_key=True, default=1, editable=False)
    name = models.CharField(max_length=200)
    domain = models.CharField(max_length=253)
    retention_days = models.PositiveIntegerField(default=90)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name

    def save(self, *args, **kwargs):
        # v1 is single-tenant: there is exactly one organization row.
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def load(cls) -> "Organization":
        """Return the singleton organization, creating a neutral one if needed."""
        organization, _ = cls.objects.get_or_create(
            pk=1,
            defaults={"name": "My Organization", "domain": "organization.example"},
        )
        return organization
