"""Template context shared by every page."""

VALID_THEMES = {"light", "dark", "system"}


def navigation(request):
    """Mark the active sidebar section without per-template conditionals."""
    match = getattr(request, "resolver_match", None)
    section = ""
    if match is not None:
        if match.namespace == "campaigns":
            section = "campaigns"
        elif match.namespace == "lures":
            section = "lures"
        elif match.namespace == "targets":
            group_routes = {
                "groups",
                "group_create",
                "group_edit",
                "group_delete",
            }
            section = "groups" if match.url_name in group_routes else "targets"
        elif match.url_name == "settings":
            section = "settings"
        elif match.url_name == "dashboard":
            section = "dashboard"
    return {"active_section": section}


def theme(request):
    """Expose the stored theme so the server can render it before paint."""
    preference = "system"
    if request is not None:
        preference = request.COOKIES.get("hookline_theme", "system")
    if preference not in VALID_THEMES:
        preference = "system"
    return {"theme_preference": preference}
