from django.conf import settings
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.views.generic import TemplateView

from campaigns.models import Campaign
from campaigns.reporting import campaign_metrics, dashboard_stats
from campaigns.senders import get_sender

from .mixins import StaffRequiredMixin
from .models import Organization


def health(request):
    return JsonResponse({"status": "ok"})


class DashboardView(StaffRequiredMixin, TemplateView):
    template_name = "core/dashboard.html"
    paginate_by = 10

    def get_template_names(self):
        if self.request.headers.get("HX-Request") == "true":
            return ["core/_dashboard_campaigns.html"]
        return [self.template_name]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        organization = Organization.load()
        campaigns = (
            Campaign.objects.filter(organization=organization)
            .select_related("lure")
            .order_by("-created_at")
        )

        selected_status = self.request.GET.get("status", "").strip()
        if selected_status in Campaign.Status.values:
            campaigns = campaigns.filter(status=selected_status)

        page_obj = Paginator(campaigns, self.paginate_by).get_page(self.request.GET.get("page"))
        for campaign in page_obj:
            campaign.report_metrics = campaign_metrics(campaign)

        context.update(dashboard_stats())
        context.update(
            {
                "campaigns": page_obj,
                "page_obj": page_obj,
                "selected_status": selected_status,
                "status_counts": {
                    status: Campaign.objects.filter(
                        organization=organization, status=status
                    ).count()
                    for status in Campaign.Status.values
                },
            }
        )
        return context


class SettingsView(StaffRequiredMixin, TemplateView):
    template_name = "core/settings.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        sender = get_sender()
        context["organization"] = Organization.load()
        context["demo_mode"] = settings.DEMO_MODE
        context["sender_label"] = "Simulated inbox" if sender.name == "simulated" else "SMTP"
        context["allowed_domains"] = settings.ALLOWED_RECIPIENT_DOMAINS
        return context
