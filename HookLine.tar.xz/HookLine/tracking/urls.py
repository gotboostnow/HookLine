from django.urls import path

from . import views

app_name = "tracking"

urlpatterns = [
    path("i/<str:token>/", views.InboxView.as_view(), name="inbox"),
    path("t/<str:token>/", views.ClickView.as_view(), name="click"),
    path("t/<str:token>/report/", views.ReportView.as_view(), name="report"),
    path("education/<str:token>/", views.EducationView.as_view(), name="education"),
]
