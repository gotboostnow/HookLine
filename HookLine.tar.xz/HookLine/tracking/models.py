"""Tracking event log."""

from django.db import models

from campaigns.models import CampaignRecipient


class TrackingEvent(models.Model):
    """An append-only click or report event. No IP, user agent, or PII."""

    class EventType(models.TextChoices):
        CLICK = "click", "Click"
        REPORT = "report", "Report"

    recipient = models.ForeignKey(
        CampaignRecipient, on_delete=models.CASCADE, related_name="events"
    )
    event_type = models.CharField(max_length=20, choices=EventType.choices)
    occurred_at = models.DateTimeField(auto_now_add=True)
    metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-occurred_at"]
        indexes = [
            models.Index(
                fields=["recipient", "event_type", "occurred_at"],
                name="event_recipient_type_time_idx",
            )
        ]

    def __str__(self) -> str:
        return f"{self.event_type} · {self.recipient.target.full_name}"
