"""Recipient-facing inbox, click, report, and education views."""

from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect
from django.utils.decorators import method_decorator
from django.utils.html import escape, strip_tags
from django.views.decorators.csrf import csrf_protect
from django.views.generic import DetailView, View

from campaigns.models import Campaign, CampaignRecipient
from lures.sanitizer import render_lure

from .services import record_click, record_report, report_rate_limited


def render_message_body(campaign: Campaign, recipient: CampaignRecipient, cta_url: str) -> str:
    """Render one lure for one recipient, with a CTA fallback."""
    lure = campaign.lure
    target = recipient.target
    body_html = render_lure(
        lure.body_html,
        {
            "first_name": target.first_name,
            "last_name": target.last_name,
            "full_name": target.full_name,
            "email": target.email,
            "department": target.department,
            "company_name": campaign.organization.name,
            "cta_url": cta_url,
            "cta_text": lure.cta_text,
        },
    )
    if cta_url not in body_html:
        body_html += f'<p><a class="email-cta" href="{cta_url}">{escape(lure.cta_text)}</a></p>'
    return body_html


def tracking_recipient(token: str) -> CampaignRecipient:
    """Look up a recipient whose campaign can still show a recipient page."""
    return get_object_or_404(
        CampaignRecipient.objects.filter(
            campaign__status__in=[Campaign.Status.ACTIVE, Campaign.Status.CLOSED]
        ).select_related("campaign__lure", "campaign__organization", "target"),
        token=token,
    )


class InboxView(DetailView):
    """The private simulated inbox for one campaign recipient.

    Opening the inbox is deliberately inert: it renders the lure but records no
    event. Only the CTA and the report form create tracking events.
    """

    template_name = "tracking/inbox.html"
    context_object_name = "recipient"
    slug_field = "token"
    slug_url_kwarg = "token"

    def get_queryset(self):
        return CampaignRecipient.objects.filter(
            campaign__status=Campaign.Status.ACTIVE
        ).select_related(
            "campaign__lure",
            "campaign__organization",
            "target",
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        recipient = self.object
        campaign = recipient.campaign
        target = recipient.target
        lure = campaign.lure

        cta_url = f"/t/{recipient.token}/"
        body_html = render_message_body(campaign, recipient, cta_url)
        sent_at = recipient.sent_at or campaign.launched_at
        preview_text = " ".join(strip_tags(body_html).split())[:140]

        context.update(
            {
                "campaign": campaign,
                "lure": lure,
                "target": target,
                "body_html": body_html,
                "cta_url": cta_url,
                "report_url": f"/t/{recipient.token}/report/",
                "sent_at": sent_at,
                "provider_name": "Northwind Mail",
                "account_initial": (target.first_name or target.email)[:1].upper(),
                "sender_initial": (lure.sender_name or lure.sender_email)[:1].upper(),
                "preview_text": preview_text,
            }
        )
        return context


class ClickView(View):
    """Record a click, then show the lesson. Closed campaigns record nothing."""

    def get(self, request, token):
        recipient = tracking_recipient(token)
        if recipient.campaign.status == Campaign.Status.ACTIVE:
            record_click(recipient)
        return redirect("tracking:education", token=token)


@method_decorator(csrf_protect, name="dispatch")
class ReportView(View):
    """Record a report, then show a positive confirmation on the lesson page."""

    def post(self, request, token):
        if report_rate_limited(token):
            return HttpResponse(
                "Too many reports for this link. Please try again later.", status=429
            )
        recipient = tracking_recipient(token)
        if recipient.campaign.status == Campaign.Status.ACTIVE:
            record_report(recipient)
        return redirect("tracking:education", token=token)


class EducationView(DetailView):
    """The personalized reveal page. Viewing it never creates an event."""

    template_name = "tracking/education.html"
    context_object_name = "recipient"
    slug_field = "token"
    slug_url_kwarg = "token"

    def get_queryset(self):
        return CampaignRecipient.objects.filter(
            campaign__status__in=[Campaign.Status.ACTIVE, Campaign.Status.CLOSED]
        ).select_related("campaign__lure", "campaign__organization", "target")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        recipient = self.object
        campaign = recipient.campaign
        lure = campaign.lure
        cta_url = f"/t/{recipient.token}/"

        context.update(
            {
                "campaign": campaign,
                "lure": lure,
                "target": recipient.target,
                "body_html": render_message_body(campaign, recipient, cta_url),
                "red_flags": lure.red_flags or [],
                "principle_details": lure.principle_details,
                "clicked": recipient.clicked_at is not None,
                "reported": recipient.reported_at is not None,
                "outcome": self._outcome(recipient),
                "can_report": (
                    recipient.reported_at is None and campaign.status == Campaign.Status.ACTIVE
                ),
                "inbox_available": campaign.status == Campaign.Status.ACTIVE,
                "report_url": f"/t/{recipient.token}/report/",
                "inbox_url": f"/i/{recipient.token}/",
                "cta_url": cta_url,
            }
        )
        return context

    @staticmethod
    def _outcome(recipient: CampaignRecipient) -> str:
        if recipient.reported_at:
            return "You reported this email — nice work."
        if recipient.clicked_at:
            return "You clicked the link."
        return "You opened the simulated email."
