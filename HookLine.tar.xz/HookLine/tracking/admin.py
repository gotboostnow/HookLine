"""Admin registration for tracking events."""

from django.contrib import admin

from .models import TrackingEvent


@admin.register(TrackingEvent)
class TrackingEventAdmin(admin.ModelAdmin):
    list_display = ("recipient", "event_type", "occurred_at")
    list_filter = ("event_type",)
    search_fields = ("recipient__target__email",)
    readonly_fields = ("recipient", "event_type", "occurred_at", "metadata")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
