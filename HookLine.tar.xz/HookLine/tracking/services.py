"""Tracking writes for clicks and reports.

Only first timestamps are stored on the recipient; every interaction is also
appended to the event log. No request metadata is kept.
"""

import hashlib

from django.core.cache import cache
from django.db import transaction
from django.utils import timezone

from campaigns.models import Campaign, CampaignRecipient

from .models import TrackingEvent

REPORT_LIMIT = 10
REPORT_WINDOW_SECONDS = 60


def report_rate_limited(token: str) -> bool:
    """Throttle repeated reports per token without storing the token itself."""
    key = "hookline:report:" + hashlib.sha256(token.encode()).hexdigest()
    count = cache.get(key, 0)
    if count >= REPORT_LIMIT:
        return True
    cache.set(key, count + 1, REPORT_WINDOW_SECONDS)
    return False


def _record(
    recipient: CampaignRecipient,
    timestamp_field: str,
    event_type: str,
) -> bool:
    """Record one interaction. Return True when this was the first one."""
    with transaction.atomic():
        locked = (
            CampaignRecipient.objects.select_for_update()
            .select_related("campaign")
            .get(pk=recipient.pk)
        )
        if locked.campaign.status != Campaign.Status.ACTIVE:
            return False

        first = getattr(locked, timestamp_field) is None
        if first:
            setattr(locked, timestamp_field, timezone.now())
            locked.save(update_fields=[timestamp_field])

        TrackingEvent.objects.create(recipient=locked, event_type=event_type)

    recipient.refresh_from_db()
    return first


def record_click(recipient: CampaignRecipient) -> bool:
    return _record(recipient, "clicked_at", TrackingEvent.EventType.CLICK)


def record_report(recipient: CampaignRecipient) -> bool:
    return _record(recipient, "reported_at", TrackingEvent.EventType.REPORT)
