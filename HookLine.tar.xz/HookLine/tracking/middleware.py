"""Privacy headers for recipient-facing routes."""

RECIPIENT_PREFIXES = ("/i/", "/t/", "/education/")


class RecipientHeadersMiddleware:
    """Keep capability-token routes out of referrers, search indexes, and caches."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if request.path.startswith(RECIPIENT_PREFIXES):
            response["Referrer-Policy"] = "no-referrer"
            response["X-Robots-Tag"] = "noindex"
        return response
