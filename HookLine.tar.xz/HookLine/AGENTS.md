# AGENTS.md — Hookline

## What this is

Hookline is a self-hosted phishing simulation and awareness platform for small teams. It is a **portfolio artifact** for cybersecurity hiring managers: single-tenant, demo-first, and built to show product thinking, Django craft, security awareness, and ethical judgment.

The app imports employees, stores a library of parameterized phishing lures, runs campaigns, shows each recipient a private simulated inbox, tracks clicks and reports, and teaches the recipient on a personalized education page.

## Source of truth

Read these before changing anything:

- `docs/spec.md` — the full specification (copy of the planning spec).
- `docs/tickets.md` — ticket breakdown, dependencies, and status.
- `docs/adr/` — architecture decision records.
- `docs/GLOSSARY.md` — domain vocabulary.
- `docs/DEMO.md` — the five-minute demo script.

Planning originals (outside the repo):

- `/home/ranas/.opencode/plan/hookline-spec.md`
- `/home/ranas/.opencode/plan/hookline-tickets.md`

If a ticket and the spec disagree, resolve the spec first.

## Current status

- **Phase:** build in progress.
- **Last updated:** 2026-11-25.
- **Current milestone:** M8 — lures, video, and final QA.
- **Next ticket:** T14 — four lures (human-in-the-loop; waiting on the owner).
- **Build mode:** active.

Update this section and the status table in `docs/tickets.md` whenever a ticket moves.

T14 and T15 are human-in-the-loop: the owner writes four lures and captures the
video/screenshots. Do not auto-generate those lures or claim a recording exists.

## Stack

- Python 3.12+; Django (latest release compatible with the installed Python; prefer an LTS).
- HTMX for partial updates.
- SQLite for local storage.
- Plain CSS with custom properties; light/dark themes; no Node, no Tailwind CDN.
- Native local run; **no Docker**.
- Mailpit optional standalone binary for the SMTP path.
- pytest, pytest-django, factory_boy, ruff, pip-audit, GitHub Actions.

## Commands

```bash
make setup        # create .venv and install dependencies
make migrate      # apply migrations
make seed         # create the demo organization and data
make run          # run the development server
make test         # run pytest
make lint         # run ruff
make mailpit      # download the Mailpit binary into .tools/
make mailpit-run  # run Mailpit (SMTP 1025, web UI 8025)
make demo         # setup + migrate + seed + run
```

Every target is also documented as a plain command in the README, so `make` is optional.

## Safety invariants (non-negotiable)

1. **No credential capture.** No fake login page, no password field, no credential storage anywhere in the recipient flow. Click-only.
2. **No real brand names, logos, or domains in lures.** Use fictional brands and `.example` domains.
3. **No attachments.**
4. **No external SMTP by default.** Demo mode plus a recipient-domain allowlist is required before anything leaves the machine.
5. **No IP address, user agent, geolocation, or device fingerprint storage.**
6. **No PII or raw tokens in application logs.** Redact recipient routes.
7. **No third-party requests from recipient pages.** No external fonts, images, analytics, or CDNs.
8. **Aggregate reporting is the default.** Named reporting is an explicit per-campaign opt-in.
9. **Every campaign requires an authorization record before launch.**
10. **Excluded targets are skipped.**

If a request conflicts with these, stop and ask the owner.

## Architecture at a glance

- `core` — Organization singleton, dashboard, settings, auth shell, `seed_demo`.
- `targets` — Target, Group, CSV import.
- `lures` — LureTemplate, `nh3` sanitizer, preview.
- `campaigns` — Campaign, CampaignRecipient, launch/close, sender adapters.
- `tracking` — TrackingEvent, recipient inbox, click, report, education page.
- `config` — Django settings and root URLs.
- `templates/` — base layout and app templates.
- `static/` — CSS, tiny JS, local images.
- `docs/` — spec, tickets, glossary, ADRs, threat model, playbook, demo, business case.

Key models: `Organization`, `Target`, `Group`, `LureTemplate`, `Campaign`, `CampaignRecipient`, `TrackingEvent`.

Key routes:

- `/i/<token>/` — simulated inbox.
- `/t/<token>/` — click tracking + redirect.
- `/t/<token>/report/` — report (POST).
- `/education/<token>/` — personalized education page.
- Admin routes are staff-only; Django admin lives at `/django-admin/`.

## Conventions

- Keep the app small and readable; prefer plain Django over clever abstractions.
- Templates: project-level base + app-level pages; partials for HTMX.
- CSS: custom properties, `data-theme` on `<html>`, no utility framework.
- Tests: every model behavior and view behavior has a test; use factories.
- Formatting: `ruff check` and `ruff format`.
- Commits: small, scoped to one ticket, reference the ticket ID.
- Docs: add an ADR for irreversible decisions; update the glossary when a term changes.
- Update `docs/tickets.md` and this file as you go.

## Progress log

### 2026-11-24 — Planning complete

- Product, scope, domain model, UX, security posture, and demo package settled.
- Spec written: `docs/spec.md`.
- Tickets written: `docs/tickets.md` (T0–T16).
- No code yet.

### 2026-11-24 — T0 complete

- Fresh git repository initialized inside `PhishingSimulator/` (the home directory is a separate outer repo and was left alone).
- Added `.gitignore`, `.editorconfig`, `LICENSE` (MIT + responsible-use notice), and a README stub.
- Copied the spec and tickets into `docs/`.
- Added `AGENTS.md`.
- Initial commit: `T0: bootstrap repository and handoff docs`.
- Next: T1 — Django scaffold and tooling.

### 2026-11-24 — T1 complete

- Created `.venv` with Python 3.15 and Django 6.1.3; pinned runtime and dev dependencies.
- Scaffolded `config` plus `core`, `targets`, `lures`, `campaigns`, and `tracking` apps.
- Added settings with `.env` loading, SQLite, templates/static paths, auth redirects, security headers, `MAILERS`, and a log-redaction filter for recipient routes.
- Added `Makefile`, `.env.example`, `pyproject.toml` (ruff + pytest), and a GitHub Actions workflow.
- Added the base app shell, login page, dashboard placeholder, theme toggle script, and the first CSS custom-property design system.
- `make test` and `make lint` pass. `python manage.py check` is clean.
- Next: T2 — core data model.

### 2026-11-24 — T2 complete

- Added `Organization` (enforced singleton), `Target`, `Group`, `LureTemplate`, `Campaign`, `CampaignRecipient`, and `TrackingEvent`.
- Added the 256-bit capability-token generator, model constraints/indexes, launch blockers, exclusion helpers, and lure validation for principles and reserved `.example` sender domains.
- Registered all models in Django admin with read-only event/recipient-token fields.
- Added `factory_boy` factories and 30 model/admin tests, including token uniqueness, exclusion filtering, and launch gates.
- `makemigrations --check` reports no changes; `make test` and `make lint` pass.
- Next: T3 — seed demo command.

### 2026-11-24 — T3 complete

- Added `python manage.py seed_demo` with `--reset` and `--with-admin`.
- Seeds Northwind Logistics, 200 deterministic targets across six departments, 3 exclusions, 3 groups, and 2 lures.
- Seeds an active Q3 campaign with 197 recipients, 75 clicks, 24 reports, named reporting, and 99 events spread across five days; the campaign stays active so the printed inbox links resolve.
- Seeds a 197-recipient October Password Reset draft that is blocked on authorization.
- Prints three sample inbox URLs and an admin password when requested.
- Added 9 seed tests covering counts, rates, idempotency, reset, exclusions, sample URLs, and admin creation.
- `make test` and `make lint` pass.
- Next: T4 — auth and app shell.

### 2026-11-24 — T4 complete

- Added `StaffRequiredMixin`: anonymous visitors redirect to login, signed-in non-staff get 403.
- Added a working sidebar with active states for Dashboard, Campaigns, Lures, Targets, Groups, and Settings.
- Added staff-only placeholder routes for the sections that arrive in later tickets, plus a read-only settings summary.
- Added server-side theme preference via the `hookline_theme` cookie and the pre-paint script; dark/light/system persists without a flash.
- Added 403 and 404 pages, badges, tables, empty states, definition lists, and responsive rules.
- Added 11 auth/shell tests, including login/logout, theme cookies, active navigation, and no external assets.
- The suite passes; `make lint` and `manage.py check` are clean.
- Next: T5 — targets and groups.

### 2026-11-24 — T5 complete

- Added the target table with name, email, department, groups, exclusion badge and reason.
- Added HTMX search, department filter, and status filter; the table and pagination swap without a full reload, and plain GET works without JavaScript.
- Added target create/edit forms with duplicate-email validation.
- Added exclude/unexclude actions with a required reason and a safe `next` redirect.
- Added CSV import: creates new targets, updates existing targets by email, preserves exclusions, adds semicolon-separated group memberships, and reports bad rows without aborting valid ones.
- Added group list, create, edit, and delete with target assignment.
- Vendored HTMX 2.0.4 (Zero-Clause BSD) under `static/js/` and added its licence.
- Added 28 target/import/group tests; the suite passes, `make lint` and `manage.py check` are clean.
- Next: T6 — lure library.

### 2026-11-25 — T6 complete

- Added `lures/sanitizer.py`: an `nh3` allowlist for the spec's tags and attributes, link `rel` hardening, script/style removal, and `img` source rules (`/static/` or `data:` only).
- Lure bodies are sanitised on save and again after Django template rendering; the fixed context is limited to the eight documented recipient fields.
- Added the lure card grid with principles, difficulty, sender, subject, active badge, and an active/inactive filter.
- Added create/edit forms with principles checkboxes, one-red-flag-per-line editing, duplicate-name and `.example` sender validation, and a required `{{ cta_url }}` placeholder.
- Added a live HTMX preview endpoint with the sample recipient Alex Chen, Finance, Northwind Logistics; template errors render in the preview panel.
- Added the in-app authoring guide and `docs/social-engineering.md`.
- Added 29 sanitizer, form, preview, and library tests; 119 tests pass, `make lint` and `manage.py check` are clean.
- Next: T7 — campaign draft and authorization.

### 2026-11-25 — T7 complete

- Added the campaign list with draft/active/closed counts and an HTMX status filter that swaps the panel without a full reload.
- Added draft create/edit forms with name, lure, reporting mode, and an authorization record.
- Added the target picker: client-side search, group filter, select-all-visible, selected count, and excluded targets disabled with their reason.
- Draft saves sync `CampaignRecipient` rows: removed targets lose their draft row, retained rows keep their tokens, and new rows get unique capability tokens.
- Added launch-readiness blockers to the edit page; excluded targets are rejected even if forged into the POST.
- `authorized_at` is set when the authorizer, scope, and acknowledgment are complete, and cleared when the acknowledgment is removed.
- Added 18 campaign view tests; 137 tests pass, `make lint` and `manage.py check` are clean.
- Next: T8 — launch and sender adapters.

### 2026-11-25 — T8 complete

- Added `campaigns/senders.py`: the `Sender` protocol, `SimulatedInboxSender`, and `SmtpSender`, with per-recipient message rendering and tracking URLs.
- Added the external-delivery gate: SMTP is refused in demo mode, without an allowlist, or when any recipient domain is outside `ALLOWED_RECIPIENT_DOMAINS`.
- Added launch and close confirmation pages, plus launch/close actions on the campaign list.
- Launch validates readiness, drops excluded recipients, sets `sent_at`, activates the campaign, and hands messages to the configured sender inside a transaction; sender failures roll back to draft.
- Sender failures are logged with the campaign id and exception class only, never recipient addresses or message content.
- The settings summary now reports the active sender and allowlisted domains.
- Added 22 launch, close, sender, and gate tests; 159 tests pass, `make lint` and `manage.py check` are clean.
- Next: T9 — recipient inbox.

### 2026-11-25 — T9 complete

- Added `/i/<token>/`: a private, staff-independent simulated inbox available only for active campaigns.
- Built the Northwind Mail layout with a provider bar, decorative folder list and search, one selected message, a reading pane, and a CSRF-protected report form.
- Lure bodies render with the recipient's real name and a per-recipient `/t/<token>/` CTA; a CTA is appended if a lure omits the placeholder.
- Invalid tokens, drafts, and closed campaigns return 404. Opening the inbox records no event.
- Added `static/css/recipient.css` with responsive mail-client layout that follows the site's light/dark preference.
- Added recipient-route middleware sending `Referrer-Policy: no-referrer` and `X-Robots-Tag: noindex`, including on 404s.
- Added 12 inbox and header tests; 171 tests pass, `make lint` and `manage.py check` are clean.
- Next: T10 — tracking, education, and report.

### 2026-11-25 — T10 complete

- Added `/t/<token>/`: records the first click once, appends a click event, and redirects to the education page.
- Added `/t/<token>/report/`: CSRF-protected POST that sets the first report timestamp once and appends a report event.
- Added `/education/<token>/`: personalized reveal with the outcome, the lure preview, numbered red flags, principle explanations, a next-steps checklist, and a report CTA.
- Closed campaigns redirect click/report to education without recording anything; draft and unknown tokens return 404.
- Added `lures/principles.py` so the authoring guide and education page share one principle vocabulary.
- No IP address, user agent, or request metadata is stored. Recipient privacy headers apply to every recipient route.
- Added 18 tracking, report, CSRF, and education tests; 189 tests pass, `make lint` and `manage.py check` are clean.
- Next: T11 — dashboard and reporting.

### 2026-11-25 — T11 complete

- Added dashboard KPIs: campaign count, target count, and mean click/report rates across launched campaigns.
- Added a campaign table on the dashboard with status, lure, delivered count, click rate, report rate, and launch date, plus HTMX status filters and pagination.
- Enriched the campaign list with click and report rates and links to the new detail page.
- Added campaign detail: no-blame banner, funnel, department breakdown, activity timeline, event log, and a recipient table only in named mode.
- Aggregate mode hides recipient names everywhere on the detail page; named mode shows names, emails, and timestamps.
- Added `campaigns/reporting.py` for rate, breakdown, timeline, and dashboard calculations, and a `percent` template filter.
- Added 15 reporting, privacy, and auth tests; 204 tests pass, `make lint` and `manage.py check` are clean.
- Next: T12 — security hardening.

### 2026-11-25 — T12 complete

- Added global `Referrer-Policy: no-referrer` and a `Permissions-Policy` header; `nosniff` and `X-Frame-Options: DENY` were already enabled and are now covered by tests.
- Audited XSS handling across sanitizer, rendering, preview, inbox, and education paths with a shared payload test.
- Verified 256-bit token entropy, token uniqueness, and the unique token field; added a test that 404 pages do not echo tokens.
- Tested the log-redaction filter on message strings and log arguments, plus CSRF enforcement on representative admin and report POSTs.
- Added a per-token report throttle (10 per minute) using hashed cache keys, and a `purge_events` management command for the 90-day retention window.
- Added `docs/threat-model.md` and `SECURITY.md`, and linked both from the README.
- `pip-audit -r requirements.txt` reports no known vulnerabilities; the audit already runs in CI.
- Added 20 security tests; 224 tests pass, `make lint` and `manage.py check` are clean.
- Next: T13 — docs and demo package.

### 2026-11-25 — T13 complete

- Rewrote the README with features, safety, a working quickstart, an architecture diagram, test commands, and documentation links; screenshot and video slots are labelled placeholders for T15.
- Added `docs/GLOSSARY.md`, `docs/DEMO.md`, `docs/business-case.md`, and all six ADRs under `docs/adr/`.
- Linked the threat model and `SECURITY.md` from the README; verified every local Markdown link resolves.
- Polished `seed_demo` sample output to include an education URL alongside the three inbox links.
- Rehearsed the five-minute demo end to end against seeded data: dashboard, detail, draft, inbox, click, education, report, and dashboard refresh all work.
- 224 tests pass, `make lint` and `manage.py check` are clean.
- Next: T14 and T15 — four lures and the video/screenshot package, both human-in-the-loop.

### 2026-11-25 — post-T13 troubleshooting

- Login page: anonymous pages now use `.app-shell--auth` so the empty 260px sidebar column is not reserved; the card is centered on desktop.
- Lure form: clarified that `{{ cta_url }}` belongs in **Body HTML**'s link href, not the Cta text field (which is only the button label); the validation error now says so.
- Excluded the owner's local `sqlite_bro.py` DB viewer from ruff so `make lint` stays clean.
- 233 tests pass; `make lint` and `manage.py check` are clean. T14/T15 remain human-in-the-loop.
- T14 in progress: prepared `docs/lure-worksheet.md` for the owner to fill in the four lures. Agent will review, add them to seed data, and update docs once the drafts arrive. T15/T16 are owner-only.

## How to resume

1. Read `docs/spec.md`, `docs/tickets.md`, and this file.
2. Run `make setup && make test` to verify the environment (after T1 exists).
3. Find the first `todo` ticket whose blockers are `done`.
4. Mark it `in_progress` in `docs/tickets.md` and add a line to the progress log here.
5. Implement, test, and update the status.
6. If interrupted, leave the ticket status and a short note so the next agent knows exactly where to continue.

## Do not

- Do not add credential capture, fake login pages, or real-brand impersonation.
- Do not enable external SMTP without the demo-mode gate and allowlist.
- Do not store IP addresses, user agents, or raw tokens in logs.
- Do not add Docker unless the owner explicitly asks.
- Do not add a runtime LLM dependency; the generator seam is for future work.
- Do not delete or overwrite planning documents without updating the spec first.
