"""Delivery adapters for campaign messages.

The simulated inbox is the default: it needs no mail server and is always
available. SMTP is an optional adapter for Mailpit or an allowlisted real
recipient domain, and is gated by demo mode plus an explicit allowlist.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.utils.html import strip_tags

from lures.sanitizer import render_lure

from .models import Campaign, CampaignRecipient


class ExternalDeliveryBlocked(Exception):
    """Raised when SMTP delivery is not explicitly allowed."""


@dataclass(frozen=True)
class RenderedMessage:
    recipient: CampaignRecipient
    subject: str
    body_html: str
    cta_url: str


class Sender(Protocol):
    name: str

    def send(self, campaign: Campaign, messages: list[RenderedMessage]) -> None:
        """Deliver every rendered message for a campaign."""


def build_messages(campaign: Campaign, base_url: str) -> list[RenderedMessage]:
    """Render one message per recipient with a per-recipient tracking URL."""
    lure = campaign.lure
    base_url = base_url.rstrip("/")
    messages: list[RenderedMessage] = []

    recipients = campaign.recipients.select_related("target").order_by("id")
    for recipient in recipients:
        target = recipient.target
        cta_url = f"{base_url}/t/{recipient.token}/"
        body_html = render_lure(
            lure.body_html,
            {
                "first_name": target.first_name,
                "last_name": target.last_name,
                "full_name": target.full_name,
                "email": target.email,
                "department": target.department,
                "company_name": campaign.organization.name,
                "cta_url": cta_url,
                "cta_text": lure.cta_text,
            },
        )
        messages.append(
            RenderedMessage(
                recipient=recipient,
                subject=lure.subject,
                body_html=body_html,
                cta_url=cta_url,
            )
        )

    return messages


class SimulatedInboxSender:
    """The default sender: messages are read in the app's private inbox."""

    name = "simulated"

    def send(self, campaign: Campaign, messages: list[RenderedMessage]) -> None:
        return None


class SmtpSender:
    """Send messages through the configured Django email backend."""

    name = "smtp"

    def _check_gate(self, messages: list[RenderedMessage]) -> None:
        if settings.DEMO_MODE:
            raise ExternalDeliveryBlocked("External SMTP delivery is disabled in demo mode.")

        allowed_domains = {
            domain.strip().lower()
            for domain in settings.ALLOWED_RECIPIENT_DOMAINS
            if domain.strip()
        }
        if not allowed_domains:
            raise ExternalDeliveryBlocked(
                "No recipient domains are allowlisted for external delivery."
            )

        blocked_domains = sorted(
            {
                message.recipient.target.email.rsplit("@", 1)[-1].lower()
                for message in messages
                if message.recipient.target.email.rsplit("@", 1)[-1].lower() not in allowed_domains
            }
        )
        if blocked_domains:
            raise ExternalDeliveryBlocked(
                "Recipient domain(s) not allowlisted: " + ", ".join(blocked_domains) + "."
            )

    def send(self, campaign: Campaign, messages: list[RenderedMessage]) -> None:
        self._check_gate(messages)

        lure = campaign.lure
        from_email = f"{lure.sender_name} <{lure.sender_email}>"

        for message in messages:
            plain_text = strip_tags(message.body_html).strip()
            if message.cta_url not in plain_text:
                plain_text = f"{plain_text}\n\n{message.cta_url}"

            email = EmailMultiAlternatives(
                subject=message.subject,
                body=plain_text,
                from_email=from_email,
                to=[message.recipient.target.email],
            )
            email.attach_alternative(message.body_html, "text/html")
            email.send(fail_silently=False)


def get_sender() -> Sender:
    """Pick the adapter from the configured Django mailer backend."""
    backend = (
        settings.MAILERS.get("default", {}).get("BACKEND", "")
        if hasattr(settings, "MAILERS")
        else ""
    )
    if backend.endswith("smtp.EmailBackend"):
        return SmtpSender()
    return SimulatedInboxSender()
