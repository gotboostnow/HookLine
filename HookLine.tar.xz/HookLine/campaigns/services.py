"""Campaign services."""

from django.db import transaction
from django.utils import timezone

from .models import Campaign, CampaignRecipient
from .senders import build_messages


class CampaignLaunchError(Exception):
    """Raised when a draft fails a launch gate."""

    def __init__(self, blockers: list[str]):
        self.blockers = blockers
        super().__init__(" ".join(blockers))


class CampaignStateError(Exception):
    """Raised when an action does not apply to the campaign's current state."""


def sync_recipients(campaign: Campaign, targets) -> None:
    """Make the draft's recipient rows match the selected targets.

    Existing rows are kept so their capability tokens and any recorded outcomes
    survive an edit. Removed targets lose their draft row; new targets get one.
    """
    selected_ids = {target.pk for target in targets}
    existing_ids = set(campaign.recipients.values_list("target_id", flat=True))

    stale_ids = existing_ids - selected_ids
    if stale_ids:
        campaign.recipients.filter(target_id__in=stale_ids).delete()

    for target in targets:
        if target.pk not in existing_ids:
            CampaignRecipient.objects.create(campaign=campaign, target=target)


def launch_campaign(campaign: Campaign, *, sender, base_url: str) -> Campaign:
    """Snapshot delivery, activate the campaign, and hand messages to the sender.

    Excluded targets are removed before validation, so they can never receive a
    message even if the draft was edited or forged. Delivery runs inside the
    transaction: a sender failure rolls the campaign back to draft.
    """
    with transaction.atomic():
        locked = (
            Campaign.objects.select_for_update()
            .select_related("lure", "organization")
            .get(pk=campaign.pk)
        )
        locked.recipients.filter(target__is_excluded=True).delete()

        blockers = locked.launch_blockers()
        if blockers:
            raise CampaignLaunchError(blockers)

        now = timezone.now()
        locked.recipients.filter(sent_at__isnull=True).update(sent_at=now)
        locked.status = Campaign.Status.ACTIVE
        locked.launched_at = now
        locked.save(update_fields=["status", "launched_at", "updated_at"])

        messages = build_messages(locked, base_url)
        sender.send(locked, messages)

    campaign.refresh_from_db()
    return campaign


def close_campaign(campaign: Campaign) -> Campaign:
    """Freeze an active campaign and stop accepting new tracking events."""
    with transaction.atomic():
        locked = Campaign.objects.select_for_update().get(pk=campaign.pk)
        if locked.status != Campaign.Status.ACTIVE:
            raise CampaignStateError("Only active campaigns can be closed.")

        locked.status = Campaign.Status.CLOSED
        locked.closed_at = timezone.now()
        locked.save(update_fields=["status", "closed_at", "updated_at"])

    campaign.refresh_from_db()
    return campaign
