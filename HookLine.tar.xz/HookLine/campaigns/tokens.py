"""Capability-token generation for recipient routes."""

import secrets

TOKEN_BYTES = 32


def generate_token() -> str:
    """Return a URL-safe capability token with 256 bits of entropy."""
    return secrets.token_urlsafe(TOKEN_BYTES)
