"""Campaign and recipient models."""

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models

from core.models import Organization
from lures.models import LureTemplate
from targets.models import Target

from .tokens import generate_token


class Campaign(models.Model):
    """One simulation run with one lure and a fixed recipient snapshot."""

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        ACTIVE = "active", "Active"
        CLOSED = "closed", "Closed"

    class ReportingMode(models.TextChoices):
        AGGREGATE = "aggregate", "Aggregate only"
        NAMED = "named", "Named recipients"

    organization = models.ForeignKey(
        Organization, on_delete=models.CASCADE, related_name="campaigns"
    )
    name = models.CharField(max_length=200)
    lure = models.ForeignKey(LureTemplate, on_delete=models.PROTECT, related_name="campaigns")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    reporting_mode = models.CharField(
        max_length=20,
        choices=ReportingMode.choices,
        default=ReportingMode.AGGREGATE,
    )
    authorized_by = models.CharField(max_length=200, blank=True)
    authorization_scope = models.TextField(blank=True)
    authorization_acknowledged = models.BooleanField(default=False)
    authorized_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="created_campaigns",
    )
    launched_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(
                fields=["organization", "status"],
                name="campaign_org_status_idx",
            )
        ]

    def __str__(self) -> str:
        return self.name

    @property
    def is_editable(self) -> bool:
        return self.status == self.Status.DRAFT

    @property
    def authorization_complete(self) -> bool:
        return bool(
            self.authorized_by.strip()
            and self.authorization_scope.strip()
            and self.authorization_acknowledged
        )

    def launch_blockers(self) -> list[str]:
        """Return every reason this campaign cannot launch right now."""
        blockers: list[str] = []
        if self.status != self.Status.DRAFT:
            blockers.append("Only draft campaigns can be launched.")
        if not self.pk or not self.recipients.exists():
            blockers.append("Add at least one recipient.")
        if self.lure_id and not self.lure.is_active:
            blockers.append("The selected lure is inactive.")
        if not self.authorized_by.strip():
            blockers.append("Record who authorized this campaign.")
        if not self.authorization_scope.strip():
            blockers.append("Describe the authorization scope.")
        if not self.authorization_acknowledged:
            blockers.append("Acknowledge the authorization before launching.")
        if self.pk and self.recipients.filter(target__is_excluded=True).exists():
            blockers.append("Remove excluded targets before launching.")
        return blockers

    @property
    def can_launch(self) -> bool:
        return not self.launch_blockers()


class CampaignRecipient(models.Model):
    """A target's snapshot inside one campaign, addressed by a capability token."""

    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE, related_name="recipients")
    target = models.ForeignKey(Target, on_delete=models.PROTECT, related_name="campaign_recipients")
    token = models.CharField(max_length=64, unique=True, editable=False)
    sent_at = models.DateTimeField(null=True, blank=True)
    clicked_at = models.DateTimeField(null=True, blank=True)
    reported_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["id"]
        constraints = [
            models.UniqueConstraint(
                fields=["campaign", "target"],
                name="unique_target_per_campaign",
            )
        ]

    def __str__(self) -> str:
        return f"{self.target.full_name} in {self.campaign.name}"

    def save(self, *args, **kwargs):
        if not self.token:
            self.token = generate_token()
            if kwargs.get("update_fields") is not None:
                kwargs["update_fields"] = set(kwargs["update_fields"]) | {"token"}
        super().save(*args, **kwargs)

    def clean(self):
        super().clean()
        if (
            self.campaign_id
            and self.target_id
            and self.campaign.organization_id != self.target.organization_id
        ):
            raise ValidationError("The target must belong to the campaign's organization.")
