"""Aggregate and campaign-level reporting helpers."""

from django.db.models import Count, Q

from core.models import Organization
from tracking.models import TrackingEvent

from .models import Campaign, Target


def rate(numerator: int, denominator: int) -> float:
    """Return a 0–1 rate, or zero when nothing was delivered."""
    return numerator / denominator if denominator else 0.0


def campaign_metrics(campaign: Campaign) -> dict:
    """Unique clicks and reports divided by delivered recipients."""
    counts = campaign.recipients.aggregate(
        delivered=Count("pk", filter=Q(sent_at__isnull=False)),
        clicked=Count("pk", filter=Q(clicked_at__isnull=False)),
        reported=Count("pk", filter=Q(reported_at__isnull=False)),
    )
    return {
        "delivered": counts["delivered"],
        "clicked": counts["clicked"],
        "reported": counts["reported"],
        "click_rate": rate(counts["clicked"], counts["delivered"]),
        "report_rate": rate(counts["reported"], counts["delivered"]),
    }


def department_breakdown(campaign: Campaign) -> list[dict]:
    """One row per department for delivered recipients."""
    rows = (
        campaign.recipients.filter(sent_at__isnull=False)
        .values("target__department")
        .annotate(
            delivered=Count("pk"),
            clicked=Count("pk", filter=Q(clicked_at__isnull=False)),
            reported=Count("pk", filter=Q(reported_at__isnull=False)),
        )
        .order_by("target__department")
    )
    return [
        {
            "department": row["target__department"] or "Unassigned",
            "delivered": row["delivered"],
            "clicked": row["clicked"],
            "reported": row["reported"],
            "click_rate": rate(row["clicked"], row["delivered"]),
            "report_rate": rate(row["reported"], row["delivered"]),
        }
        for row in rows
    ]


def event_timeline(campaign: Campaign) -> list[dict]:
    """Daily click/report counts. Contains no recipient identifiers."""
    rows = (
        TrackingEvent.objects.filter(recipient__campaign=campaign)
        .values("occurred_at__date")
        .annotate(
            clicks=Count("pk", filter=Q(event_type=TrackingEvent.EventType.CLICK)),
            reports=Count("pk", filter=Q(event_type=TrackingEvent.EventType.REPORT)),
        )
        .order_by("occurred_at__date")
    )
    return [
        {
            "date": row["occurred_at__date"],
            "clicks": row["clicks"],
            "reports": row["reports"],
        }
        for row in rows
    ]


def dashboard_stats() -> dict:
    """KPIs shown on the dashboard, scoped to the single organization."""
    organization = Organization.load()
    campaigns = Campaign.objects.filter(organization=organization)
    launched = campaigns.filter(launched_at__isnull=False)

    rates = [campaign_metrics(campaign)["click_rate"] for campaign in launched]
    report_rates = [campaign_metrics(campaign)["report_rate"] for campaign in launched]

    return {
        "campaign_count": campaigns.count(),
        "target_count": Target.objects.filter(organization=organization).count(),
        "active_count": campaigns.filter(status=Campaign.Status.ACTIVE).count(),
        "average_click_rate": sum(rates) / len(rates) if rates else 0.0,
        "average_report_rate": sum(report_rates) / len(report_rates) if report_rates else 0.0,
    }
