"""Admin registration for campaigns."""

from django.contrib import admin

from .models import Campaign, CampaignRecipient


@admin.register(Campaign)
class CampaignAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "status",
        "reporting_mode",
        "lure",
        "created_by",
        "launched_at",
    )
    list_filter = ("status", "reporting_mode")
    search_fields = ("name", "lure__name")
    readonly_fields = (
        "created_at",
        "updated_at",
        "launched_at",
        "closed_at",
    )


@admin.register(CampaignRecipient)
class CampaignRecipientAdmin(admin.ModelAdmin):
    list_display = ("target", "campaign", "sent_at", "clicked_at", "reported_at")
    list_filter = ("campaign",)
    search_fields = ("target__first_name", "target__last_name", "target__email")
    readonly_fields = (
        "token",
        "sent_at",
        "clicked_at",
        "reported_at",
        "created_at",
    )
