"""Views for campaign drafts and authorization."""

import logging

from django.contrib import messages
from django.db import transaction
from django.db.models import Count
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views import View
from django.views.generic import CreateView, DetailView, ListView, UpdateView

from core.mixins import StaffRequiredMixin
from core.models import Organization
from targets.models import Group, Target
from tracking.models import TrackingEvent

from .forms import CampaignForm
from .models import Campaign
from .reporting import campaign_metrics, department_breakdown, event_timeline
from .senders import ExternalDeliveryBlocked, get_sender
from .services import (
    CampaignLaunchError,
    CampaignStateError,
    close_campaign,
    launch_campaign,
    sync_recipients,
)

logger = logging.getLogger(__name__)


def picker_context(selected_ids: set[int]) -> dict:
    organization = Organization.load()
    return {
        "picker_targets": (
            Target.objects.filter(organization=organization)
            .prefetch_related("groups")
            .order_by("last_name", "first_name")
        ),
        "picker_groups": Group.objects.filter(organization=organization).order_by("name"),
        "selected_target_ids": selected_ids,
    }


def selected_ids_from_post(request) -> set[int]:
    selected: set[int] = set()
    for value in request.POST.getlist("targets"):
        try:
            selected.add(int(value))
        except (TypeError, ValueError):
            continue
    return selected


class CampaignListView(StaffRequiredMixin, ListView):
    model = Campaign
    template_name = "campaigns/list.html"
    context_object_name = "campaigns"

    def get_queryset(self):
        queryset = (
            Campaign.objects.filter(organization=Organization.load())
            .select_related("lure")
            .annotate(recipient_count=Count("recipients"))
            .order_by("-created_at")
        )
        status = self.request.GET.get("status", "").strip()
        if status in Campaign.Status.values:
            queryset = queryset.filter(status=status)
        return queryset

    def get_template_names(self):
        if self.request.headers.get("HX-Request") == "true":
            return ["campaigns/_panel.html"]
        return [self.template_name]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        all_campaigns = Campaign.objects.filter(organization=Organization.load())
        for campaign in context["campaigns"]:
            campaign.report_metrics = campaign_metrics(campaign)
        context.update(
            {
                "selected_status": self.request.GET.get("status", "").strip(),
                "total_count": all_campaigns.count(),
                "draft_count": all_campaigns.filter(status=Campaign.Status.DRAFT).count(),
                "active_count": all_campaigns.filter(status=Campaign.Status.ACTIVE).count(),
                "closed_count": all_campaigns.filter(status=Campaign.Status.CLOSED).count(),
            }
        )
        return context


class CampaignDetailView(StaffRequiredMixin, DetailView):
    model = Campaign
    template_name = "campaigns/detail.html"
    context_object_name = "campaign"

    def get_queryset(self):
        return Campaign.objects.filter(organization=Organization.load()).select_related("lure")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        campaign = self.object
        events = (
            TrackingEvent.objects.filter(recipient__campaign=campaign)
            .select_related("recipient__target")
            .order_by("-occurred_at")[:50]
        )
        context.update(
            {
                "metrics": campaign_metrics(campaign),
                "departments": department_breakdown(campaign),
                "timeline": event_timeline(campaign),
                "events": events,
                "named": campaign.reporting_mode == Campaign.ReportingMode.NAMED,
            }
        )
        return context


class CampaignCreateView(StaffRequiredMixin, CreateView):
    model = Campaign
    form_class = CampaignForm
    template_name = "campaigns/form.html"
    extra_context = {"page_title": "New campaign"}

    def form_valid(self, form):
        with transaction.atomic():
            form.instance.organization = Organization.load()
            form.instance.created_by = self.request.user
            self.object = form.save()
            sync_recipients(self.object, form.cleaned_data["targets"])
        messages.success(
            self.request,
            f"Created draft {self.object.name} with {self.object.recipients.count()} recipients.",
        )
        return redirect(self.get_success_url())

    def get_success_url(self):
        return reverse("campaigns:list")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        selected_ids = (
            selected_ids_from_post(self.request) if self.request.method == "POST" else set()
        )
        context.update(picker_context(selected_ids))
        context["launch_blockers"] = None
        return context


class CampaignUpdateView(StaffRequiredMixin, UpdateView):
    model = Campaign
    form_class = CampaignForm
    template_name = "campaigns/form.html"
    extra_context = {"page_title": "Edit campaign"}

    def get_queryset(self):
        return Campaign.objects.filter(
            organization=Organization.load(),
            status=Campaign.Status.DRAFT,
        ).select_related("lure")

    def form_valid(self, form):
        with transaction.atomic():
            self.object = form.save()
            sync_recipients(self.object, form.cleaned_data["targets"])
        messages.success(
            self.request,
            f"Saved draft {self.object.name} with {self.object.recipients.count()} recipients.",
        )
        return redirect(self.get_success_url())

    def get_success_url(self):
        return reverse("campaigns:list")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.method == "POST":
            selected_ids = selected_ids_from_post(self.request)
        else:
            selected_ids = set(self.object.recipients.values_list("target_id", flat=True))
        context.update(picker_context(selected_ids))
        context["launch_blockers"] = self.object.launch_blockers()
        return context


class CampaignLaunchView(StaffRequiredMixin, View):
    """Confirm and launch a draft campaign."""

    template_name = "campaigns/confirm.html"

    def get_campaign(self) -> Campaign:
        return get_object_or_404(
            Campaign.objects.select_related("lure"),
            pk=self.kwargs["pk"],
            organization=Organization.load(),
        )

    def get(self, request, *args, **kwargs):
        campaign = self.get_campaign()
        if campaign.status != Campaign.Status.DRAFT:
            messages.info(request, "Only draft campaigns can be launched.")
            return redirect("campaigns:list")

        return render(
            request,
            self.template_name,
            {
                "campaign": campaign,
                "action": "launch",
                "blockers": campaign.launch_blockers(),
                "recipient_count": campaign.recipients.count(),
            },
        )

    def post(self, request, *args, **kwargs):
        campaign = self.get_campaign()
        sender = get_sender()
        try:
            launch_campaign(
                campaign,
                sender=sender,
                base_url=request.build_absolute_uri("/"),
            )
        except CampaignLaunchError as exc:
            for blocker in exc.blockers:
                messages.error(request, blocker)
            return redirect("campaigns:launch", pk=campaign.pk)
        except ExternalDeliveryBlocked as exc:
            messages.error(request, str(exc))
            return redirect("campaigns:launch", pk=campaign.pk)
        except Exception as exc:  # noqa: BLE001 - sender failures must not leak PII
            logger.error(
                "Campaign %s delivery failed with %s",
                campaign.pk,
                type(exc).__name__,
            )
            messages.error(
                request,
                "Delivery failed, so the campaign was not launched. Check the logs.",
            )
            return redirect("campaigns:launch", pk=campaign.pk)

        messages.success(
            request,
            f"Launched {campaign.name} to {campaign.recipients.count()} recipients "
            f"via the {sender.name} sender.",
        )
        return redirect("campaigns:list")


class CampaignCloseView(StaffRequiredMixin, View):
    """Confirm and close an active campaign."""

    template_name = "campaigns/confirm.html"

    def get_campaign(self) -> Campaign:
        return get_object_or_404(
            Campaign.objects.select_related("lure"),
            pk=self.kwargs["pk"],
            organization=Organization.load(),
        )

    def get(self, request, *args, **kwargs):
        campaign = self.get_campaign()
        if campaign.status != Campaign.Status.ACTIVE:
            messages.info(request, "Only active campaigns can be closed.")
            return redirect("campaigns:list")

        return render(
            request,
            self.template_name,
            {
                "campaign": campaign,
                "action": "close",
                "blockers": [],
                "recipient_count": campaign.recipients.count(),
            },
        )

    def post(self, request, *args, **kwargs):
        campaign = self.get_campaign()
        try:
            close_campaign(campaign)
        except CampaignStateError as exc:
            messages.error(request, str(exc))
            return redirect("campaigns:list")

        messages.success(request, f"Closed {campaign.name}.")
        return redirect("campaigns:list")
