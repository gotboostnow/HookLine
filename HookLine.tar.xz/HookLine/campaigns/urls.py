from django.urls import path

from . import views

app_name = "campaigns"

urlpatterns = [
    path("", views.CampaignListView.as_view(), name="list"),
    path("add/", views.CampaignCreateView.as_view(), name="create"),
    path("<int:pk>/", views.CampaignDetailView.as_view(), name="detail"),
    path("<int:pk>/edit/", views.CampaignUpdateView.as_view(), name="edit"),
    path("<int:pk>/launch/", views.CampaignLaunchView.as_view(), name="launch"),
    path("<int:pk>/close/", views.CampaignCloseView.as_view(), name="close"),
]
