"""Forms for campaign drafts."""

from django import forms
from django.utils import timezone

from core.models import Organization
from lures.models import LureTemplate
from targets.models import Target

from .models import Campaign


class CampaignForm(forms.ModelForm):
    targets = forms.ModelMultipleChoiceField(
        queryset=Target.objects.none(),
        required=False,
        widget=forms.MultipleHiddenInput,
    )

    class Meta:
        model = Campaign
        fields = [
            "name",
            "lure",
            "reporting_mode",
            "authorized_by",
            "authorization_scope",
            "authorization_acknowledged",
        ]
        widgets = {
            "authorization_scope": forms.Textarea(attrs={"rows": 4}),
        }
        labels = {
            "authorization_acknowledged": ("I confirm this campaign has written authorization."),
        }
        help_texts = {
            "name": "An internal name for this exercise.",
            "lure": "The message every recipient will see.",
            "reporting_mode": (
                "Aggregate is the default. Named reporting links outcomes to "
                "people and must be an explicit choice."
            ),
            "authorized_by": "Name and role of the person who approved this exercise.",
            "authorization_scope": "Who, what, and when. Be specific.",
            "authorization_acknowledged": (
                "This is a launch gate. Do not check it without a real approval."
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        organization = Organization.load()
        self.fields["lure"].queryset = LureTemplate.objects.filter(
            organization=organization
        ).order_by("name")
        self.fields["targets"].queryset = Target.objects.filter(organization=organization).order_by(
            "last_name", "first_name"
        )

    def clean_targets(self):
        targets = self.cleaned_data["targets"]
        if not targets:
            raise forms.ValidationError("Select at least one recipient.")
        if any(target.is_excluded for target in targets):
            raise forms.ValidationError("Excluded targets cannot be added to a campaign.")
        return targets

    def save(self, commit=True):
        campaign = super().save(commit=False)

        if campaign.authorization_complete:
            if not campaign.authorized_at:
                campaign.authorized_at = timezone.now()
        else:
            campaign.authorized_at = None

        if commit:
            campaign.save()
            self.save_m2m()
        return campaign
