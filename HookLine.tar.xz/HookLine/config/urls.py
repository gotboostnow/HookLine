from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path

urlpatterns = [
    path("django-admin/", admin.site.urls),
    path("accounts/login/", auth_views.LoginView.as_view(), name="login"),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("campaigns/", include("campaigns.urls")),
    path("lures/", include("lures.urls")),
    path("targets/", include("targets.urls")),
    path("", include("tracking.urls")),
    path("", include("core.urls")),
]
