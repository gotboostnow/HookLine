"""Forms for targets, groups, and CSV import."""

from django import forms
from django.core.exceptions import ValidationError

from core.models import Organization

from .models import Group, Target


class TargetForm(forms.ModelForm):
    class Meta:
        model = Target
        fields = ["first_name", "last_name", "email", "department"]

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        duplicates = Target.objects.filter(organization=Organization.load(), email=email)
        if self.instance.pk:
            duplicates = duplicates.exclude(pk=self.instance.pk)
        if duplicates.exists():
            raise ValidationError("A target with this email already exists.")
        return email


class CsvImportForm(forms.Form):
    csv_file = forms.FileField(
        label="CSV file",
        help_text="UTF-8 CSV with first_name, last_name, email, department, groups.",
    )

    def clean_csv_file(self):
        uploaded = self.cleaned_data["csv_file"]
        if not uploaded.name.lower().endswith(".csv"):
            raise ValidationError("Upload a .csv file.")
        if uploaded.size > 2 * 1024 * 1024:
            raise ValidationError("Keep the file under 2 MB.")
        return uploaded


class GroupForm(forms.ModelForm):
    class Meta:
        model = Group
        fields = ["name", "description", "targets"]
        widgets = {
            "targets": forms.SelectMultiple(attrs={"size": 12}),
        }
        help_texts = {
            "targets": (
                "Hold Ctrl (Windows/Linux) or Cmd (macOS) to select more than one. "
                "Excluded targets can stay in a group; campaigns skip them."
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["targets"].queryset = Target.objects.filter(
            organization=Organization.load()
        ).order_by("last_name", "first_name")
        self.fields["targets"].required = False

    def clean_name(self):
        name = self.cleaned_data["name"].strip()
        duplicates = Group.objects.filter(organization=Organization.load(), name=name)
        if self.instance.pk:
            duplicates = duplicates.exclude(pk=self.instance.pk)
        if duplicates.exists():
            raise ValidationError("A group with this name already exists.")
        return name
