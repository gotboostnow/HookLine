"""Admin registration for targets and groups."""

from django.contrib import admin

from .models import Group, Target


@admin.register(Target)
class TargetAdmin(admin.ModelAdmin):
    list_display = (
        "full_name",
        "email",
        "department",
        "is_excluded",
        "organization",
    )
    list_filter = ("department", "is_excluded")
    search_fields = ("first_name", "last_name", "email")
    list_select_related = ("organization",)


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ("name", "organization", "target_count", "created_at")
    search_fields = ("name",)
    filter_horizontal = ("targets",)

    @admin.display(description="Targets")
    def target_count(self, obj: Group) -> int:
        return obj.targets.count()
