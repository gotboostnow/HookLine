"""CSV import for targets."""

import csv
from dataclasses import dataclass, field
from io import TextIOWrapper

from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.db import transaction

from core.models import Organization

from .models import Group, Target

REQUIRED_COLUMNS = {"first_name", "last_name", "email"}


@dataclass
class ImportResult:
    created: int = 0
    updated: int = 0
    groups: int = 0
    errors: list[str] = field(default_factory=list)


def _clean(value) -> str:
    if isinstance(value, list):
        value = ",".join(value)
    return (value or "").strip()


def _too_long(value: str, limit: int) -> bool:
    return len(value) > limit


def import_targets_csv(uploaded_file) -> ImportResult:
    """Import targets from a CSV, reporting bad rows without aborting the file."""
    result = ImportResult()
    organization = Organization.load()

    uploaded_file.seek(0)
    stream = TextIOWrapper(uploaded_file.file, encoding="utf-8-sig", newline="")

    try:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None:
            result.errors.append("The file is empty.")
            return result

        headers = {name.strip() for name in reader.fieldnames if name}
        missing = REQUIRED_COLUMNS - headers
        if missing:
            result.errors.append("Missing required column(s): " + ", ".join(sorted(missing)) + ".")
            return result

        seen_emails: set[str] = set()

        for line_number, raw_row in enumerate(reader, start=2):
            row = {(key or "").strip(): _clean(value) for key, value in raw_row.items()}
            first_name = row.get("first_name", "")
            last_name = row.get("last_name", "")
            email = row.get("email", "").lower()
            department = row.get("department", "")
            group_names = [
                name.strip() for name in row.get("groups", "").split(";") if name.strip()
            ]

            if not first_name or not last_name or not email:
                result.errors.append(
                    f"Row {line_number}: first_name, last_name, and email are required."
                )
                continue
            if _too_long(first_name, 100) or _too_long(last_name, 100):
                result.errors.append(f"Row {line_number}: names must be 100 characters or fewer.")
                continue
            if _too_long(email, 254):
                result.errors.append(f"Row {line_number}: the email address is too long.")
                continue
            if _too_long(department, 100):
                result.errors.append(
                    f"Row {line_number}: the department must be 100 characters or fewer."
                )
                continue
            try:
                validate_email(email)
            except ValidationError:
                result.errors.append(f"Row {line_number}: '{email}' is not a valid email address.")
                continue
            if email in seen_emails:
                result.errors.append(f"Row {line_number}: duplicate email '{email}' in this file.")
                continue
            seen_emails.add(email)

            too_long_group = next((name for name in group_names if _too_long(name, 100)), None)
            if too_long_group is not None:
                result.errors.append(
                    f"Row {line_number}: group names must be 100 characters or fewer."
                )
                continue

            with transaction.atomic():
                target, created = Target.objects.update_or_create(
                    organization=organization,
                    email=email,
                    defaults={
                        "first_name": first_name,
                        "last_name": last_name,
                        "department": department,
                    },
                )
                for group_name in group_names:
                    group, group_created = Group.objects.get_or_create(
                        organization=organization, name=group_name
                    )
                    group.targets.add(target)
                    if group_created:
                        result.groups += 1

            if created:
                result.created += 1
            else:
                result.updated += 1

    except UnicodeDecodeError:
        result.errors.append("The file must be UTF-8 encoded.")
    except csv.Error as error:
        result.errors.append(f"Could not read the CSV: {error}")

    if result.created == 0 and result.updated == 0 and not result.errors:
        result.errors.append("No data rows found.")

    return result
