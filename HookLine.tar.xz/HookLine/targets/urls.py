from django.urls import path

from . import views

app_name = "targets"

urlpatterns = [
    path("", views.TargetListView.as_view(), name="list"),
    path("add/", views.TargetCreateView.as_view(), name="create"),
    path("import/", views.TargetImportView.as_view(), name="import"),
    path("<int:pk>/edit/", views.TargetUpdateView.as_view(), name="edit"),
    path("<int:pk>/exclusion/", views.TargetExclusionView.as_view(), name="exclusion"),
    path("groups/", views.GroupListView.as_view(), name="groups"),
    path("groups/add/", views.GroupCreateView.as_view(), name="group_create"),
    path("groups/<int:pk>/edit/", views.GroupUpdateView.as_view(), name="group_edit"),
    path(
        "groups/<int:pk>/delete/",
        views.GroupDeleteView.as_view(),
        name="group_delete",
    ),
]
