"""Views for targets, exclusions, CSV imports, and groups."""

from django.contrib import messages
from django.db.models import Count, Q
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.utils.http import url_has_allowed_host_and_scheme
from django.views import View
from django.views.generic import CreateView, DeleteView, FormView, ListView, UpdateView

from core.mixins import StaffRequiredMixin
from core.models import Organization

from .forms import CsvImportForm, GroupForm, TargetForm
from .models import Group, Target
from .services import import_targets_csv


class TargetListView(StaffRequiredMixin, ListView):
    model = Target
    template_name = "targets/list.html"
    context_object_name = "targets"
    paginate_by = 25

    def get_queryset(self):
        organization = Organization.load()
        queryset = (
            Target.objects.filter(organization=organization)
            .prefetch_related("groups")
            .order_by("last_name", "first_name")
        )

        search = self.request.GET.get("q", "").strip()
        if search:
            queryset = queryset.filter(
                Q(first_name__icontains=search)
                | Q(last_name__icontains=search)
                | Q(email__icontains=search)
            )

        department = self.request.GET.get("department", "").strip()
        if department:
            queryset = queryset.filter(department=department)

        status = self.request.GET.get("status", "").strip()
        if status == "excluded":
            queryset = queryset.filter(is_excluded=True)
        elif status == "active":
            queryset = queryset.filter(is_excluded=False)

        return queryset

    def get_template_names(self):
        if self.request.headers.get("HX-Request") == "true":
            return ["targets/_table.html"]
        return [self.template_name]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        organization = Organization.load()
        all_targets = Target.objects.filter(organization=organization)

        params = self.request.GET.copy()
        params.pop("page", None)

        context.update(
            {
                "departments": all_targets.exclude(department="")
                .values_list("department", flat=True)
                .distinct()
                .order_by("department"),
                "search_query": self.request.GET.get("q", "").strip(),
                "selected_department": self.request.GET.get("department", "").strip(),
                "selected_status": self.request.GET.get("status", "").strip(),
                "querystring": params.urlencode(),
                "total_count": all_targets.count(),
                "excluded_count": all_targets.filter(is_excluded=True).count(),
            }
        )
        return context


class TargetCreateView(StaffRequiredMixin, CreateView):
    model = Target
    form_class = TargetForm
    template_name = "targets/form.html"
    extra_context = {"page_title": "Add target"}

    def form_valid(self, form):
        form.instance.organization = Organization.load()
        response = super().form_valid(form)
        messages.success(self.request, f"Added {self.object.full_name}.")
        return response

    def get_success_url(self):
        return reverse("targets:list")


class TargetUpdateView(StaffRequiredMixin, UpdateView):
    model = Target
    form_class = TargetForm
    template_name = "targets/form.html"
    extra_context = {"page_title": "Edit target"}

    def get_queryset(self):
        return Target.objects.filter(organization=Organization.load())

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, f"Saved {self.object.full_name}.")
        return response

    def get_success_url(self):
        return reverse("targets:list")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["group_memberships"] = self.object.groups.order_by("name")
        return context


class TargetExclusionView(StaffRequiredMixin, View):
    """Exclude a target with a reason, or return it to the active list."""

    def post(self, request, pk):
        target = get_object_or_404(Target, pk=pk, organization=Organization.load())
        action = request.POST.get("action", "exclude")

        if action == "include":
            target.mark_included()
            messages.success(request, f"{target.full_name} is back on the active list.")
        else:
            reason = request.POST.get("reason", "").strip()
            if not reason:
                messages.error(request, "Add a reason before excluding a target.")
            else:
                target.mark_excluded(reason)
                messages.success(request, f"Excluded {target.full_name}.")

        next_url = request.POST.get("next", "")
        if next_url and url_has_allowed_host_and_scheme(
            next_url,
            allowed_hosts={request.get_host()},
            require_https=request.is_secure(),
        ):
            return HttpResponseRedirect(next_url)
        return redirect("targets:list")


class TargetImportView(StaffRequiredMixin, FormView):
    template_name = "targets/import.html"
    form_class = CsvImportForm

    def form_valid(self, form):
        result = import_targets_csv(form.cleaned_data["csv_file"])
        if result.errors:
            return self.render_to_response(self.get_context_data(form=form, result=result))

        messages.success(
            self.request,
            (
                f"Import complete: {result.created} added, "
                f"{result.updated} updated, {result.groups} new group(s)."
            ),
        )
        return redirect("targets:list")


class GroupListView(StaffRequiredMixin, ListView):
    model = Group
    template_name = "targets/group_list.html"
    context_object_name = "groups"

    def get_queryset(self):
        return (
            Group.objects.filter(organization=Organization.load())
            .annotate(member_count=Count("targets"))
            .prefetch_related("targets")
            .order_by("name")
        )


class GroupCreateView(StaffRequiredMixin, CreateView):
    model = Group
    form_class = GroupForm
    template_name = "targets/group_form.html"
    extra_context = {"page_title": "New group"}

    def form_valid(self, form):
        form.instance.organization = Organization.load()
        response = super().form_valid(form)
        messages.success(self.request, f"Created group {self.object.name}.")
        return response

    def get_success_url(self):
        return reverse("targets:groups")


class GroupUpdateView(StaffRequiredMixin, UpdateView):
    model = Group
    form_class = GroupForm
    template_name = "targets/group_form.html"
    extra_context = {"page_title": "Edit group"}

    def get_queryset(self):
        return Group.objects.filter(organization=Organization.load())

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, f"Saved group {self.object.name}.")
        return response

    def get_success_url(self):
        return reverse("targets:groups")


class GroupDeleteView(StaffRequiredMixin, DeleteView):
    model = Group
    template_name = "targets/group_confirm_delete.html"
    context_object_name = "group"

    def get_queryset(self):
        return Group.objects.filter(organization=Organization.load())

    def form_valid(self, form):
        name = self.object.name
        response = super().form_valid(form)
        messages.success(self.request, f"Deleted group {name}.")
        return response

    def get_success_url(self):
        return reverse("targets:groups")
