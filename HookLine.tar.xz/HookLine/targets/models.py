"""Target and group models."""

from django.core.exceptions import ValidationError
from django.db import models

from core.models import Organization


class Target(models.Model):
    """An employee who can receive a simulated phishing message."""

    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="targets")
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    department = models.CharField(max_length=100, blank=True)
    is_excluded = models.BooleanField(default=False)
    exclusion_reason = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["last_name", "first_name"]
        constraints = [
            models.UniqueConstraint(
                fields=["organization", "email"],
                name="unique_target_email_per_org",
            )
        ]
        indexes = [
            models.Index(
                fields=["organization", "department"],
                name="target_org_dept_idx",
            )
        ]

    def __str__(self) -> str:
        return f"{self.full_name} <{self.email}>"

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()

    def clean(self):
        super().clean()
        if not self.is_excluded:
            self.exclusion_reason = ""

    def save(self, *args, **kwargs):
        self.email = self.email.strip().lower()
        super().save(*args, **kwargs)

    def mark_excluded(self, reason: str = "") -> None:
        self.is_excluded = True
        self.exclusion_reason = reason
        self.save(update_fields=["is_excluded", "exclusion_reason", "updated_at"])

    def mark_included(self) -> None:
        self.is_excluded = False
        self.exclusion_reason = ""
        self.save(update_fields=["is_excluded", "exclusion_reason", "updated_at"])


class Group(models.Model):
    """A reusable selection aid. Campaign recipients are snapshotted separately."""

    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="groups")
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    targets = models.ManyToManyField(Target, blank=True, related_name="groups")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(
                fields=["organization", "name"],
                name="unique_group_name_per_org",
            )
        ]

    def __str__(self) -> str:
        return self.name

    def clean(self):
        super().clean()
        if self.pk and self.targets.exclude(organization_id=self.organization_id).exists():
            raise ValidationError("Every group member must belong to the group's organization.")
