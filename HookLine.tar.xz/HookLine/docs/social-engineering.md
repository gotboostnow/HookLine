# Social-engineering lure authoring guide

Hookline lures are short, fictional emails used to teach employees how phishing
works. A lure is successful when the recipient learns something, not when it
embarrasses them.

This guide is for whoever writes and reviews lure content. The same guidance is
available inside the app at **Lures → Authoring guide**. For the four T14 lures,
fill in `docs/lure-worksheet.md` and review the result with this checklist.

## Safety rules

These are product invariants, not style preferences.

1. **Click-only.** Never ask for a password, MFA code, recovery code, or any
   other credential. Hookline has no fake login page and stores no credential
   fields.
2. **Fictional details only.** Use invented brands, people, and domains.
   Sender addresses must end in `.example`. Never use a real company name, logo,
   domain, or executive.
3. **No attachments.** The simulated inbox renders HTML only.
4. **No external assets.** Images must be local (`/static/…`) or embedded
   (`data:`). No remote fonts, pixels, scripts, or tracking images.
5. **No real personal data.** Demo targets are synthetic. Imported data stays
   in the local database and is covered by the retention setting.
6. **Authorized campaigns only.** A campaign cannot launch until an authorizer,
   scope, and acknowledgment are recorded.
7. **Excluded targets are skipped.** A target on leave, on legal hold, or opted
   out must never receive a simulation.

If a request conflicts with these rules, stop and raise it with the owner.

## Start with one lesson

Each lure declares one or more social-engineering principles. The education page
explains every principle the lure used, so fewer is usually clearer.

| Principle | What it looks like | What the recipient should learn |
| --- | --- | --- |
| Authority | A manager, finance team, or IT asks for action. | Verify unusual requests through a known channel. |
| Urgency | A same-day deadline or account closure. | Slow down; urgency is a pressure tactic. |
| Fear | Loss of access, a penalty, or a missed payment. | Check the claim independently before acting. |
| Curiosity | A shared document, photo, or unexpected update. | Hover the link and confirm the sender. |
| Social proof | “Everyone has already completed this.” | Popularity is not proof of legitimacy. |
| Reciprocity | A small favor or free resource. | Check what is being asked in return. |
| Greed | A refund, bonus, or prize. | Be skeptical of unexpected money. |
| Trust | A familiar internal process or sender name. | Look at the address, not just the display name. |

Pick a scenario your audience sees in their real work: an invoice, a shared
file, an HR notice, a delivery update, or a calendar invitation.

## Anatomy of a lure

- **Sender name** — plausible and fictional, for example “Brightline Supplies
  Billing”.
- **Sender address** — on a reserved `.example` domain, for example
  `billing@brightline-supplies.example`.
- **Subject** — specific and short. Avoid ALL CAPS and multiple exclamation
  marks.
- **Body** — two or three sentences, one call to action, and a plain sign-off.
- **CTA** — a link whose href is `{{ cta_url }}` and whose label is
  `{{ cta_text }}`. Hookline replaces both per recipient.
- **Red flags** — plain-language observations the recipient could have made.
- **Principles** — the levers the message uses.
- **Difficulty** — how subtle the lure is. Easy lures have obvious mismatches;
  hard lures look close to a real internal process.

### Placeholders

The rendering context is fixed. No other variables are available.

```text
first_name, last_name, full_name, email, department, company_name, cta_url, cta_text
```

Use personalization sparingly. A message that knows the recipient's department
is plausible; a message that lists everything Hookline knows is unsettling and
teaches the wrong lesson.

### Example body

```html
<p>Hi {{ first_name }},</p>
<p>Invoice <strong>INV-4821</strong> is ready for review. Payment is due today
to avoid a late fee.</p>
<p><a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a></p>
<p>Thanks,<br>Brightline Accounts</p>
```

Red flags for this lure:

- The invoice is unexpected and has no purchase order the recipient recognizes.
- The sender domain is not the finance team's usual domain.
- The same-day deadline pressures the recipient.
- The payment link sits outside the normal procurement process.

## Allowed HTML

The body is sanitised on save and again after rendering. Anything outside this
list is removed.

| Element | Allowed |
| --- | --- |
| Tags | `p`, `br`, `strong`, `em`, `u`, `ul`, `ol`, `li`, `h1`–`h3`, `a`, `div`, `span`, `table`, `thead`, `tbody`, `tr`, `td`, `th`, `img` |
| Attributes | `href`, `title`, `alt`, `width`, `height`, `class`, `src` |
| Images | `src` must start with `/static/` or `data:`; external images are stripped |
| Links | Rendered with `rel="noopener noreferrer"`; no `target` |
| Styles | `style` attributes and `<style>` blocks are stripped |
| Scripts and forms | Removed with their content |

Use the `email-cta` class for the call-to-action link. Keep tables simple; the
inbox is responsive and wide tables may scroll.

## Review checklist

Before saving a lure:

- [ ] Does it ask for a click only, with no credential field?
- [ ] Are all brands, people, and domains fictional and on `.example`?
- [ ] Does the body include `{{ cta_url }}` exactly once as the CTA?
- [ ] Does the preview render without errors and look plausible?
- [ ] Is every red flag something a careful recipient could actually notice?
- [ ] Is the difficulty honest? Do not label a subtle lure “easy”.
- [ ] Does the education page explain the lesson without blaming the recipient?
- [ ] Is the campaign authorization recorded and scoped to the right audience?

## Tone

Write like a cautious colleague, not a prankster. The education page should
leave the recipient with a concrete habit: verify the sender, hover before
clicking, and report suspicious mail. Never use shame, fear of punishment, or
fake consequences in the reveal.
