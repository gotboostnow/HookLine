# Hookline — Specification

**Status:** Design settled; build not started
**Date:** 2026-11-24
**Owner:** ranas
**Project directory:** `/home/ranas/Documents/Projects/PhishingSimulator`
**Source:** Planning session, 2026-11-24

> **Hookline** — *hook, line, and awareness.*
> A phishing simulation and awareness platform for small teams.

---

## 1. Product summary

Hookline is a self-hosted phishing simulation and security-awareness platform for small and mid-sized organizations. An administrator imports employees, chooses a lure from a library of parameterized phishing templates, records authorization, and launches a campaign. Each recipient gets a private simulated inbox link. Clicking the email's call to action records a click and lands on a personalized education page that explains the exact red flags and social-engineering principles used. Recipients can also report the email; the report rate is a first-class metric.

The project is a **portfolio artifact** for cybersecurity hiring managers. It is built to demonstrate:

- Understanding of social engineering as an attack technique.
- Product thinking: the tool is a training product, not a gotcha machine.
- Full-stack Django craft: models, views, templates, HTMX, tests, security.
- Ethical and legal awareness: no credential capture, authorization records, data minimization, aggregate-first reporting.
- The ability to package and explain a product: demo video, business case, threat model, ADRs.

### Non-goals

- Real external email delivery by default.
- Credential harvesting of any kind.
- Multi-tenancy or MSP mode.
- Production-scale sending or a background queue.
- LLM generation at runtime.
- A full LMS or training-course assignment.
- Billing, SSO, or enterprise administration.
- Open-tracking pixels or attachment simulation.

---

## 2. Goals and success criteria

### Goals

1. A five-minute demo that an interviewer can understand without running anything.
2. A working local app that runs natively with Python and SQLite — no Docker.
3. A codebase that is small enough to read in an afternoon and structured enough to look professional.
4. A safety posture that a security reviewer would respect: click-only, no PII in logs, sanitized HTML, high-entropy tokens, explicit authorization.
5. Documentation that makes the thinking visible: glossary, ADRs, threat model, social-engineering playbook, business case.

### Definition of done for v1

- `make setup && make migrate && make seed && make run` works from a clean checkout.
- `make test` passes; `make lint` passes.
- The seeded demo org, campaign, inbox, education page, and dashboard all work end-to-end.
- The Mailpit path works when `make mailpit` has been run, but is not required for the demo.
- The six lures exist (two authored by the agent, four by the user, all reviewed).
- README, demo script, screenshots, recorded walkthrough, and business one-pager are in place.
- The repository is public-ready with a responsible-use notice and `SECURITY.md`.

---

## 3. Personas and demo organization

### Admin persona

An IT generalist at a 200-person company. No dedicated security team. Needs a lightweight way to run a phishing simulation, see which departments need training, and avoid creating a surveillance culture.

### Recipient persona

An employee at the fictional demo company. Receives a simulated phishing email in a private inbox view. Clicks the link or reports the email. Gets a short, personalized lesson either way.

### Interviewer persona

A cybersecurity hiring manager or technical interviewer. Opens the repository, reads the README, watches a three-to-five-minute walkthrough, and optionally runs the demo locally.

### Demo organization

| Field | Value |
| --- | --- |
| Name | Northwind Logistics |
| Domain | `northwind.example` |
| Size | 200 employees |
| Departments | Finance, HR, Sales, Operations, IT, Customer Support |
| Excluded targets | 3 (on leave, legal hold, opted out) |
| Completed campaign | Q3 Invoice Review — ~38% click rate, ~12% report rate |
| Draft campaign | October Password Reset — ready to launch |

All email addresses use `.example` domains (RFC 2606). No real brands, logos, or domains appear in lures.

---

## 4. Core flows

### 4.1 Admin: create and launch a campaign

1. Import targets via CSV or add them manually.
2. Create groups (for example, Finance, All Staff, Executives).
3. Pick a lure from the library, or create one.
4. Create a campaign: name, lure, target selection.
5. Complete the authorization record: authorized by, scope, acknowledgment.
6. Launch. Hookline snapshots the recipient list, generates tokens if needed, marks the campaign active, and hands the messages to the configured sender.
7. The campaign detail page shows live metrics.

### 4.2 Recipient: receive, click, learn

1. The recipient opens `/i/<token>/` — a simulated mail client showing one message.
2. The email body contains the lure's call to action, pointing at `/t/<token>/`.
3. Opening the inbox records nothing.
4. Clicking the CTA records a click event and redirects to `/education/<token>/`.
5. The education page reveals the simulation and explains the exact red flags and principles used.

### 4.3 Recipient: report

1. From the simulated inbox, the recipient clicks **Report phishing** (a POST form).
2. Hookline records the report and redirects to the education page with a positive confirmation.
3. The education page also offers a report CTA if the recipient clicked first.

### 4.4 Admin: review results

1. The dashboard shows campaign-level KPIs and a campaign table.
2. Campaign detail shows a funnel (sent → clicked → reported), department breakdown, timeline, and — in named mode — a recipient table.
3. Aggregate mode is the default; named mode is an explicit per-campaign choice.
4. The report includes a no-blame banner.

---

## 5. Domain model

### 5.1 Entity overview

| Entity | Purpose |
| --- | --- |
| `Organization` | Singleton org settings: name, domain, retention. |
| `Target` | An employee who can receive simulations. |
| `Group` | A reusable segment of targets. Selection aid only. |
| `LureTemplate` | A parameterized phishing email template. |
| `Campaign` | One simulation run with one lure and a snapshot of recipients. |
| `CampaignRecipient` | The through model: one target in one campaign, with token and timestamps. |
| `TrackingEvent` | The full click/report event log. |

### 5.2 Organization

Singleton in v1.

| Field | Type | Notes |
| --- | --- | --- |
| `name` | `CharField(200)` | Display name. |
| `domain` | `CharField(253)` | Fictional or real org domain; used for context only. |
| `retention_days` | `PositiveIntegerField` | Default 90. |
| `created_at` | `DateTimeField(auto_now_add)` | |
| `updated_at` | `DateTimeField(auto_now)` | |

### 5.3 Target

| Field | Type | Notes |
| --- | --- | --- |
| `organization` | FK → Organization | |
| `first_name` | `CharField(100)` | Used in personalization. |
| `last_name` | `CharField(100)` | |
| `email` | `EmailField` | Unique per organization. |
| `department` | `CharField(100)` | Free text; drives the breakdown. |
| `is_excluded` | `BooleanField(default=False)` | Do-not-contact flag. |
| `exclusion_reason` | `CharField(200, blank=True)` | On leave, legal hold, opted out, etc. |
| `created_at` | `DateTimeField(auto_now_add)` | |
| `updated_at` | `DateTimeField(auto_now)` | |

Constraints:

- `UniqueConstraint(organization, email)`.
- `full_name` property returns `f"{first_name} {last_name}".strip()`.

### 5.4 Group

| Field | Type | Notes |
| --- | --- | --- |
| `organization` | FK → Organization | |
| `name` | `CharField(100)` | Unique per organization. |
| `description` | `TextField(blank=True)` | |
| `targets` | M2M → Target | |
| `created_at` | `DateTimeField(auto_now_add)` | |

Groups are a selection aid. A campaign's recipients are the snapshot in `CampaignRecipient`, not the group membership at view time.

### 5.5 LureTemplate

| Field | Type | Notes |
| --- | --- | --- |
| `organization` | FK → Organization | |
| `name` | `CharField(150)` | Internal name. |
| `description` | `TextField(blank=True)` | Internal note: when to use it. |
| `principles` | `JSONField(default=list)` | List of principle keys. |
| `difficulty` | `CharField` choices: `easy`, `medium`, `hard` | |
| `sender_name` | `CharField(150)` | Display name. |
| `sender_email` | `EmailField` | Fictional address on the org's `.example` domain. |
| `subject` | `CharField(255)` | |
| `body_html` | `TextField` | Constrained HTML + Django template variables. |
| `cta_text` | `CharField(100)` | Text of the tracking link. |
| `red_flags` | `JSONField(default=list)` | List of plain-language strings. |
| `is_active` | `BooleanField(default=True)` | |
| `created_at` | `DateTimeField(auto_now_add)` | |
| `updated_at` | `DateTimeField(auto_now)` | |

Rendering context (fixed, no arbitrary objects):

```text
first_name, last_name, full_name, email, department, company_name, cta_url, cta_text
```

Rules:

- `body_html` is rendered with Django's template engine using the fixed context.
- Rendered HTML is sanitized with `nh3` before storage or display.
- Allowed tags: `p`, `br`, `strong`, `em`, `u`, `ul`, `ol`, `li`, `h1`–`h3`, `a`, `div`, `span`, `table`, `thead`, `tbody`, `tr`, `td`, `th`, `img`.
- Allowed attributes: `href`, `title`, `alt`, `width`, `height`, `class`, `src`.
- No `style` attributes. Use the predefined email CSS classes.
- No scripts, event handlers, iframes, forms, or external assets.
- `img[src]` must start with `/static/` or `data:`. External images are stripped.
- Links get `rel="noopener noreferrer"` and open in the same tab.

### 5.6 Campaign

| Field | Type | Notes |
| --- | --- | --- |
| `organization` | FK → Organization | |
| `name` | `CharField(200)` | |
| `lure` | FK → LureTemplate (`PROTECT`) | |
| `status` | `CharField` choices: `draft`, `active`, `closed` | |
| `reporting_mode` | `CharField` choices: `aggregate`, `named` | Default `aggregate`. |
| `authorized_by` | `CharField(200)` | Name/role of the authorizer. |
| `authorization_scope` | `TextField` | Who, what, when. |
| `authorization_acknowledged` | `BooleanField(default=False)` | Launch gate. |
| `authorized_at` | `DateTimeField(null=True, blank=True)` | Set when acknowledged. |
| `created_by` | FK → User (`PROTECT`) | |
| `launched_at` | `DateTimeField(null=True, blank=True)` | |
| `closed_at` | `DateTimeField(null=True, blank=True)` | |
| `created_at` | `DateTimeField(auto_now_add)` | |
| `updated_at` | `DateTimeField(auto_now)` | |

Rules:

- Draft campaigns are editable: name, lure, recipients, authorization.
- Launch requires: status `draft`, at least one recipient, lure active, authorization acknowledged, non-empty authorizer and scope.
- After launch: lure, recipients, reporting mode, and authorization are immutable. Only status changes (close) are allowed.
- Closing freezes metrics and stops new tracking events.

### 5.7 CampaignRecipient

| Field | Type | Notes |
| --- | --- | --- |
| `campaign` | FK → Campaign (`CASCADE`) | |
| `target` | FK → Target (`PROTECT`) | |
| `token` | `CharField(64, unique=True)` | `secrets.token_urlsafe(32)`. |
| `sent_at` | `DateTimeField(null=True, blank=True)` | Set on launch. |
| `clicked_at` | `DateTimeField(null=True, blank=True)` | First click only. |
| `reported_at` | `DateTimeField(null=True, blank=True)` | First report only. |
| `created_at` | `DateTimeField(auto_now_add)` | |

Constraints:

- `UniqueConstraint(campaign, target)`.
- Token generated on row creation; routes 404 until the campaign is active.

### 5.8 TrackingEvent

| Field | Type | Notes |
| --- | --- | --- |
| `recipient` | FK → CampaignRecipient (`CASCADE`) | |
| `event_type` | `CharField` choices: `click`, `report` | |
| `occurred_at` | `DateTimeField(auto_now_add)` | |
| `metadata` | `JSONField(default=dict, blank=True)` | Reserved; no PII in v1. |

Indexes:

- `(recipient, event_type, occurred_at)`.

Rules:

- First click/report sets the timestamp on `CampaignRecipient`.
- Every click/report creates an event, even if the timestamp is already set.
- Metrics use unique timestamps, not raw event counts.

### 5.9 Invariants

1. No credential capture, ever. There is no login form in the recipient flow.
2. Tokens are high-entropy capabilities; no sequential IDs in recipient URLs.
3. Excluded targets are never included in a campaign's recipient snapshot.
4. A campaign's recipient snapshot is fixed at launch.
5. A lure used by a campaign cannot be deleted (`PROTECT`).
6. Named reporting requires an explicit per-campaign choice; aggregate is the default.
7. No IP address, user agent, geolocation, or device fingerprint is stored.
8. No real brand names, logos, or domains in lures.
9. No external network requests from recipient pages.
10. Every campaign has an authorization record before launch.

---

## 6. Campaign lifecycle

```text
draft ──launch──▶ active ──close──▶ closed
```

| State | Editable | Inbox route | Tracking | Metrics |
| --- | --- | --- | --- | --- |
| `draft` | Yes | 404 | 404 | Hidden |
| `active` | No | Works | Records | Live |
| `closed` | No | 404 | Education still renders; no new events | Frozen |

Launch steps:

1. Validate authorization and recipient count.
2. Filter out excluded targets.
3. Set `sent_at` on all recipients.
4. Set `status = active`, `launched_at = now`.
5. Call the configured sender adapter.
6. Redirect to campaign detail with a success message.

Close steps:

1. Set `status = closed`, `closed_at = now`.
2. Redirect to campaign detail.

---

## 7. Tracking mechanics

| Route | Method | Behavior |
| --- | --- | --- |
| `/i/<token>/` | GET | Simulated inbox. Requires active campaign. Records nothing. |
| `/t/<token>/` | GET | Records a click (first timestamp + event), redirects to `/education/<token>/`. |
| `/t/<token>/report/` | POST | Records a report (first timestamp + event), redirects to `/education/<token>/`. CSRF required. |
| `/education/<token>/` | GET | Personalized education page. Renders for active or closed campaigns; 404 for draft/invalid. |

Details:

- Invalid token → 404, no information leakage.
- Closed campaign click/report → redirect to education without recording.
- Education page view → no tracking event.
- `Referrer-Policy: no-referrer` and `X-Robots-Tag: noindex` on all recipient routes.
- No IP or user-agent storage.
- Log redaction: recipient paths containing tokens must not be written to application logs.

---

## 8. Recipient experience

### 8.1 Simulated inbox

A simple, fictional mail client called **Northwind Mail**:

- Top bar: provider name, search field (decorative), account avatar.
- Left sidebar: Inbox, Starred, Sent, Trash (decorative), with Inbox selected.
- Message list: one message, selected.
- Reading pane: sender name and address, subject, date, body, and a toolbar with **Report phishing**.
- The body is sanitized HTML with the app's email CSS classes.
- No real logos, no third-party assets.
- Desktop-first; stacks on mobile.
- Light and dark themes follow the same preference as the rest of the app.

### 8.2 Education page

Sections:

1. **Reveal banner** — "This was a simulated phishing email. No data was captured."
2. **Outcome** — "You clicked the link" or "You reported this email — nice work."
3. **The email** — a compact preview with the red flags highlighted.
4. **Red flags** — one card per flag, plain language.
5. **The principle** — what social-engineering lever was used and why it works.
6. **What to do next** — a short checklist: verify the sender, hover before clicking, report suspicious mail, use the reporting button.
7. **CTA** — "Report this email" if not reported; positive confirmation if reported.
8. **Back to inbox** — a link for the demo.

Tone: reassuring, educational, never punitive. No quiz in v1.

### 8.3 Report flow

- Report button in the inbox and on the education page.
- POST with CSRF.
- First report sets `reported_at`; every report creates an event.
- Confirmation reuses the education page with a positive banner.
- Report rate is a first-class metric.

---

## 9. Admin experience

### 9.1 App shell and theme

- Left sidebar: Dashboard, Campaigns, Lures, Targets, Groups, Settings.
- Top bar: page title, theme toggle, user menu, logout.
- Login/logout via Django auth; staff-only.
- Django admin at `/django-admin/` for back-office inspection.
- Theme toggle: light / dark / system; persisted in a cookie; applied before paint to avoid flash.
- Responsive: sidebar collapses on narrow screens.

### 9.2 Dashboard

- KPI cards: campaigns, targets, average click rate, average report rate.
- Campaign table: name, status, lure, recipients, click rate, report rate, launched date.
- Recent activity: latest campaigns or events.
- Empty state: a friendly prompt to run `seed_demo` or create a campaign.

### 9.3 Campaigns

- List with status filter (HTMX).
- Create/edit draft: name, lure, target picker.
- Target picker: filter by group, search by name/email, select all, excluded targets shown but disabled with a reason.
- Authorization panel: authorizer, scope, acknowledgment checkbox, warning copy.
- Launch and close actions with confirmation.
- Detail: status badge, funnel, department breakdown, timeline, recipient table (named only), event log, no-blame banner.

### 9.4 Lures

- Card grid: name, principles, difficulty, sender, subject, active badge.
- Create/edit form with a live preview.
- Preview uses sample context: Alex Chen, Finance, Northwind Logistics.
- Inline help for principles, red flags, and allowed HTML.
- Link to the authoring guide.

### 9.5 Targets and groups

- Target table: name, email, department, groups, excluded badge.
- Search and department filter (HTMX).
- Add/edit target.
- CSV import: `first_name,last_name,email,department,groups`; groups semicolon-separated.
- Import behavior: create new, update existing by email, preserve `is_excluded`, add group memberships.
- Exclude/unexclude with a reason.
- Group CRUD and target assignment.

### 9.6 Settings

- Organization name, domain, retention days.
- Demo mode indicator.
- Sender configuration summary (read-only).
- Link to Django admin for user management.
- Retention note and `purge_events` command documentation.

---

## 10. Lure library

### 10.1 Schema

See `LureTemplate` in section 5.5. The authoring guide lives in `docs/social-engineering.md`.

### 10.2 Principles

| Key | Label | What it exploits |
| --- | --- | --- |
| `authority` | Authority | People comply with perceived authority. |
| `urgency` | Urgency | Time pressure short-circuits verification. |
| `fear` | Fear | Threat of loss or consequences. |
| `curiosity` | Curiosity | An information gap demands closure. |
| `social_proof` | Social proof | "Everyone else already did this." |
| `reciprocity` | Reciprocity | A small favor creates obligation. |
| `greed` | Greed | An unexpected benefit or reward. |
| `trust` | Trust | Familiarity, routine, and known names. |

A lure may use one or more principles. Each lure must declare at least one.

### 10.3 Red flags

A red flag is a concrete, observable detail the recipient could have noticed:

- Sender display name does not match the address.
- Domain is not the organization's domain.
- Unexpected request for payment or credentials.
- Urgency or threats with a deadline.
- Generic greeting.
- Link text and destination disagree.
- Unexpected attachment.
- Request to bypass a normal process.
- Unusual sender for the role.

Avoid "poor grammar" as a primary red flag; modern phishing is often well written.

### 10.4 Difficulty

| Level | Meaning |
| --- | --- |
| `easy` | Obvious mismatch, generic greeting, blatant urgency. |
| `medium` | Plausible sender, one or two subtle flags. |
| `hard` | Well-researched pretext, realistic context, no obvious errors. |

### 10.5 Authoring process

1. Agent writes `docs/social-engineering.md`: taxonomy, red-flag checklist, difficulty rubric, schema, safety constraints.
2. Agent writes two worked examples to set the quality bar.
3. User writes four lures, one per remaining principle, using the guide.
4. Agent reviews all six for realism, safety, and consistency.
5. Lures are added as fixtures or seed data and referenced in the demo.

Six lures, one per principle (the two worked examples plus four user-authored):

| # | Pretext | Principles | Difficulty | Author |
| --- | --- | --- | --- | --- |
| 1 | Fake invoice from a supplier | authority, urgency | medium | Agent |
| 2 | Password expiry notice | fear, urgency | easy | Agent |
| 3 | HR policy update | authority, curiosity | medium | User |
| 4 | CEO gift-card request | authority, greed | medium | User |
| 5 | Shared document notification | curiosity, social_proof | hard | User |
| 6 | Delivery notification | curiosity, urgency | easy | User |

---

## 11. UI and UX

### 11.1 Visual direction

- Clean SaaS admin: dark slate sidebar, light content, teal accent, amber warnings, green success.
- Cards, badges, tables, and simple forms. No modal-heavy flows.
- CSS funnel bars and an SVG sparkline; no chart library.
- Inline SVG icons; no icon library.
- System font stack; no external fonts.
- The inbox looks like a mail client; the education page feels calm and supportive.

### 11.2 Light and dark mode

- CSS custom properties on `:root` and `[data-theme="dark"]`.
- Default follows `prefers-color-scheme`.
- Manual toggle cycles light → dark → system.
- Preference stored in a cookie (`hookline_theme`) so the server can render the right theme without a flash.
- A tiny inline script in `<head>` applies the theme before paint.
- Recipient pages respect the same preference.
- Contrast checked in both themes.

### 11.3 Accessibility

- Semantic HTML and landmarks.
- Labels for every form control.
- Visible focus states.
- Skip link.
- Color is never the only signal.
- Reduced-motion friendly.
- Tables have captions/headers.
- Target WCAG 2.1 AA contrast.

### 11.4 Responsive behavior

- Admin: sidebar becomes a top navigation on small screens; tables scroll horizontally.
- Inbox: two-pane on desktop, stacked on mobile.
- Education: single column, readable line length.

---

## 12. Stack and architecture

### 12.1 Stack

| Layer | Choice |
| --- | --- |
| Language | Python 3.12+ (use the latest Django-compatible version available) |
| Framework | Django (latest LTS-compatible release) |
| Interactivity | HTMX |
| Database | SQLite |
| Styling | Plain CSS with custom properties; no Node, no Tailwind CDN |
| Email inspection | Mailpit, optional standalone binary |
| Testing | pytest, pytest-django, factory_boy |
| Lint/format | ruff |
| Security audit | pip-audit |
| CI | GitHub Actions |

### 12.2 Project layout

```text
PhishingSimulator/
├── AGENTS.md
├── Makefile
├── README.md
├── manage.py
├── pyproject.toml
├── requirements.txt
├── requirements-dev.txt
├── .editorconfig
├── .gitignore
├── config/
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
├── core/
│   ├── models.py          # Organization
│   ├── views.py           # dashboard, settings, health
│   ├── management/commands/seed_demo.py
│   └── ...
├── targets/
│   ├── models.py          # Target, Group
│   ├── forms.py
│   ├── views.py
│   └── ...
├── lures/
│   ├── models.py          # LureTemplate
│   ├── sanitizer.py
│   ├── views.py
│   └── ...
├── campaigns/
│   ├── models.py          # Campaign, CampaignRecipient
│   ├── senders.py         # Sender protocol, simulated, SMTP
│   ├── views.py
│   └── ...
├── tracking/
│   ├── models.py          # TrackingEvent
│   ├── views.py           # inbox, click, report, education
│   └── ...
├── templates/
├── static/
│   ├── css/
│   ├── js/
│   └── img/
└── docs/
    ├── GLOSSARY.md
    ├── DEMO.md
    ├── social-engineering.md
    ├── threat-model.md
    ├── business-case.md
    ├── spec.md
    ├── tickets.md
    └── adr/
```

### 12.3 Local development (native, no Docker)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```

Make targets:

| Target | Purpose |
| --- | --- |
| `make setup` | Create venv and install dependencies. |
| `make migrate` | Apply migrations. |
| `make seed` | Run `seed_demo`. |
| `make run` | Run the development server. |
| `make test` | Run pytest. |
| `make lint` | Run ruff. |
| `make mailpit` | Download the Mailpit binary into `.tools/`. |
| `make mailpit-run` | Run Mailpit. |
| `make demo` | setup + migrate + seed + run. |

Every target is documented as a plain command in the README so it works without `make`.

### 12.4 Mailpit

- Optional. The simulated inbox is the default path and needs no mail server.
- `make mailpit` downloads the standalone binary to `.tools/mailpit` (no Docker, no system install).
- `make mailpit-run` starts it on SMTP `127.0.0.1:1025`, web UI `127.0.0.1:8025`.
- The SMTP sender adapter points at Mailpit in development.
- The demo can show a real message in Mailpit to prove the adapter works.
- If Mailpit is not installed, the demo still works via the simulated inbox.

### 12.5 Settings and environment

`.env.example`:

```text
DJANGO_SECRET_KEY=change-me
DJANGO_DEBUG=1
DJANGO_ALLOWED_HOSTS=127.0.0.1,localhost
DEMO_MODE=1
EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend
EMAIL_HOST=127.0.0.1
EMAIL_PORT=1025
EMAIL_USE_TLS=0
ALLOWED_RECIPIENT_DOMAINS=
```

Rules:

- `DEMO_MODE=1` by default. External SMTP is refused unless `DEMO_MODE=0` and the recipient domain is in `ALLOWED_RECIPIENT_DOMAINS`.
- `DJANGO_SECRET_KEY` must be set in production.
- `DEBUG` off in production.
- SQLite file `db.sqlite3`, gitignored.

### 12.6 HTMX usage

Use HTMX where it removes a full page reload without hiding the server-rendered model:

- Target search/filter.
- Campaign status filter.
- Recipient table pagination.
- Inline exclude toggle.

Do not use HTMX for the report button; a normal POST + redirect is simpler and more robust.

---

## 13. Security and privacy

### 13.1 Safety invariants

These are non-negotiable and must be checked in code review:

1. No credential capture, no fake login page, no password field anywhere in the recipient flow.
2. No real brand names, logos, or domains in lures.
3. No attachments.
4. No external SMTP by default; demo-mode gate plus domain allowlist.
5. No IP address, user agent, geolocation, or device fingerprint storage.
6. No PII or raw tokens in application logs.
7. No third-party requests from recipient pages.
8. Aggregate reporting is the default; named reporting is a per-campaign opt-in.
9. Every campaign requires an authorization record before launch.
10. Excluded targets are skipped.

### 13.2 Authorization and consent

- Campaign form requires `authorized_by`, `authorization_scope`, and `authorization_acknowledged`.
- The UI shows a responsible-use warning: "Use only with written authorization from the organization. This tool is for security-awareness training."
- The threat model documents GDPR/works-council considerations and recommends legal review before real deployment.
- A first-run banner in the admin reminds the operator of authorized use.

### 13.3 Data minimization

Stored: name, email, department, group membership, campaign membership, event timestamps.

Not stored: IP address, user agent, geolocation, device fingerprint, raw email content beyond the template, credentials (never).

Retention:

- `Organization.retention_days` default 90.
- `python manage.py purge_events` deletes `TrackingEvent` rows older than the retention window.
- Recipient timestamps remain for aggregate metrics in v1; full anonymization is future work and must be documented as a limitation.

### 13.4 HTML sanitization

- Render lure templates with the fixed context.
- Sanitize with `nh3` using the allowlist in section 5.5.
- Strip scripts, event handlers, iframes, forms, `style` attributes, and external assets.
- Allow images only from `/static/` or `data:`.
- Add `rel="noopener noreferrer"` to links.
- Test with XSS payloads: `<script>`, `onerror`, `javascript:` URLs, external images, `style` with `url()`.

### 13.5 Tokens and routes

- `secrets.token_urlsafe(32)` (256 bits).
- Unique index; no sequential IDs in recipient URLs.
- `Referrer-Policy: no-referrer` on recipient routes.
- `X-Robots-Tag: noindex` on recipient routes.
- Log redaction for `/i/`, `/t/`, and `/education/` paths.
- No token in analytics, error pages, or referrers.

### 13.6 App security

- Django auth; staff-only admin views.
- CSRF on all POSTs, including the report endpoint.
- Session cookies `HttpOnly`, `SameSite=Lax`, `Secure` in production.
- Security headers: `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy`.
- Rate-limit report POSTs per token (simple cache-based throttle) if time permits; otherwise document as future work.
- `pip-audit` in CI.
- Dependency pinning.
- `python manage.py check --deploy` documented for production.

### 13.7 Logging

- Do not log request paths containing recipient tokens.
- Do not log email addresses or names at INFO level.
- Log campaign launches, sender failures, and administrative actions with campaign IDs, not recipient PII.
- Configure a logging filter to redact recipient routes.

### 13.8 Known limitations

- Real mail scanners prefetch links and can inflate click rates; production deployments need scanner handling.
- Aggregate mode is a reporting policy, not full anonymization; recipient rows still link tokens to targets.
- SQLite is demo-scale; production would use Postgres.
- Launch sends synchronously; a production queue is future work.
- No multi-tenancy, SSO, billing, or background jobs.
- No open tracking, attachments, or credential capture.

---

## 14. Demo package

### 14.1 Seed data

`python manage.py seed_demo` creates:

- Northwind Logistics, `northwind.example`, retention 90.
- 200 targets across six departments, using a fixed seed for reproducibility.
- Groups: Finance, All Staff, Executives.
- 3 excluded targets with reasons.
- 2 lures: fake invoice, password expiry.
- 1 completed campaign: Q3 Invoice Review, ~38% clicked, ~12% reported, named reporting.
- 1 draft campaign: October Password Reset.
- Sample inbox URLs printed to the console.

Flags:

- `--reset` wipes demo data and recreates it.
- `--with-admin` creates a superuser with a generated password printed once.

### 14.2 Demo script

`docs/DEMO.md` covers a five-minute walkthrough:

1. Start the app.
2. Log in.
3. Dashboard: seeded campaign metrics.
4. Open the completed campaign: funnel, department breakdown, named drill-down, no-blame banner.
5. Open the draft campaign: review the lure, authorization record, launch.
6. Open a sample inbox: see the email, click the CTA.
7. Education page: red flags, principle, "no data captured."
8. Report another email from the inbox: positive confirmation.
9. Dashboard updates.
10. Optional: Mailpit path — `make mailpit`, switch sender, show the real message.

### 14.3 Video and screenshots

- The user records a 3–5 minute walkthrough; the agent writes the script and storyboard.
- The user captures screenshots for the README: dashboard, campaign detail, inbox, education page, lure library.
- Placeholders in the README until captured.

### 14.4 Business one-pager

`docs/business-case.md` covers:

- ICP: SMB 50–500 employees, IT generalist, no dedicated security team, compliance pressure.
- Problem: phishing is the top vector; enterprise tools are expensive and cloud-only; SMBs need lightweight, self-hosted, privacy-first training.
- Solution: Hookline — self-hosted, click-only, aggregate-first, transparent pricing, no AI dependency.
- Competitors: KnowBe4, Proofpoint, Hoxhunt, GoPhish.
- Positioning: GoPhish is free but raw; KnowBe4 is enterprise and cloud-only; Hookline is the privacy-first SMB option.
- Pricing sketch: flat annual license or per-seat; numbers are illustrative.
- Go-to-market: MSP partnerships, cyber-insurance referrals, content marketing.
- Risks: crowded market, deliverability, legal/works councils, AI commoditizing content.
- Disclaimer: portfolio document, not a real business plan.

---

## 15. Documentation deliverables

| File | Purpose |
| --- | --- |
| `README.md` | What it is, screenshots, demo video, features, safety, quickstart, architecture, tests, license. |
| `AGENTS.md` | Handoff and progress log for the next agent. |
| `docs/GLOSSARY.md` | Domain vocabulary. |
| `docs/adr/` | 6 decision records. |
| `docs/threat-model.md` | Assets, actors, threats, mitigations, legal notes. |
| `docs/social-engineering.md` | Principles, red flags, difficulty rubric, authoring guide, two worked examples. |
| `docs/DEMO.md` | Five-minute demo script and storyboard. |
| `docs/business-case.md` | Business one-pager. |
| `SECURITY.md` | Vulnerability reporting and responsible-use notice. |
| `LICENSE` | MIT. |

### ADRs

1. **ADR-001: Click-only, no credential capture.** The product records clicks and reports; it never renders a login form or accepts credentials.
2. **ADR-002: Simulated inbox by default; Mailpit optional; real SMTP gated.** The demo must work offline; real delivery is an adapter behind a demo-mode gate and allowlist.
3. **ADR-003: Library-first lure generator with an LLM seam.** The generator is a protocol; the library is the v1 implementation. No runtime LLM dependency.
4. **ADR-004: Aggregate-first reporting with per-campaign named opt-in.** The default protects recipients; named reporting is a deliberate choice.
5. **ADR-005: Django + HTMX + SQLite, native local run.** No Docker; the stack matches the owner's experience and keeps the demo portable.
6. **ADR-006: Snapshot recipients at launch; tokens are capabilities.** Live campaigns are stable; recipient URLs are unguessable and not sequential.

---

## 16. Testing and CI

### Test areas

- Models: token generation, unique constraints, campaign launch validation, exclusion filtering, status transitions.
- Views: auth required for admin routes; recipient routes public; invalid tokens 404; inbox records nothing; click/report idempotency; education context.
- Security: XSS sanitization, CSRF on report, token enumeration, header presence, log redaction.
- Metrics: click rate, report rate, department breakdown, aggregate vs. named.
- Seed command: idempotency, counts, sample URLs.

### Tooling

- `pytest`, `pytest-django`, `factory_boy`.
- `ruff check` and `ruff format --check`.
- `pip-audit`.
- GitHub Actions: install, lint, test, audit.
- Coverage report via `pytest-cov`; aim for meaningful coverage of core flows, not a vanity percentage.

---

## 17. Build milestones

| Milestone | Tickets | Outcome |
| --- | --- | --- |
| M0 | T0 | Repo, handoff docs, spec in repo. |
| M1 | T1–T3 | Django scaffold, models, seed demo. |
| M2 | T4–T6 | App shell, targets/groups, lure library. |
| M3 | T7–T8 | Campaigns, authorization, launch, sender adapters. |
| M4 | T9–T10 | Inbox, tracking, education, report. |
| M5 | T11 | Dashboard and reporting. |
| M6 | T12 | Security hardening and threat model. |
| M7 | T13 | Docs and demo package. |
| M8 | T14–T16 | Lures, video, final QA. |

---

## 18. Out of scope for v1

- Real external SMTP by default.
- LLM runtime generation.
- Multi-tenancy/MSP mode.
- Scheduling and background jobs.
- A/B variants.
- PDF/CSV export (CSV export is a possible stretch).
- Longitudinal risk scoring.
- Training-course assignment/LMS.
- Open tracking pixels.
- Attachments.
- Quizzes.
- Hosted demo.
- Billing, SSO, enterprise admin.
- Postgres, Redis, Celery.

---

## 19. Future work

- LLM-assisted lure drafting with human review.
- Multi-tenant/MSP mode.
- Background sending queue.
- Open tracking with explicit privacy trade-offs.
- CSV/PDF export.
- Risk scoring over time.
- Training assignment and LMS integration.
- Hosted read-only demo.
- Postgres and production deployment guide.
- SSO.
- More lures, localization, and industry packs.
- Scanner-aware click filtering.
- Full anonymization mode.

---

## 20. Decision log

| Date | Decision | Rationale |
| --- | --- | --- |
| 2026-11-24 | Portfolio artifact, not a commercial product | Optimize for demo quality and depth, not scale or sales. |
| 2026-11-24 | Click-only | Removes credential-capture risk and a class of legal problems. |
| 2026-11-24 | Library-first, LLM seam | Domain credibility and reproducibility without runtime weight. |
| 2026-11-24 | Django + HTMX + SQLite | Owner experience, batteries included, fast to a polished demo. |
| 2026-11-24 | Simulated inbox default, Mailpit optional | Offline-safe demo; real delivery is an adapter. |
| 2026-11-24 | SMB demo org | Matches the buyer who would use a lightweight self-hosted tool. |
| 2026-11-24 | Aggregate-first reporting | Ethical default; named reporting is a deliberate per-campaign choice. |
| 2026-11-24 | Native local run, no Docker | Owner's preference; fewer moving parts. |
| 2026-11-24 | Name: Hookline | Short, professional, memorable; pun lives in the tagline. |
| 2026-11-24 | Light and dark mode | Owner request; implemented with CSS variables and a cookie. |
| 2026-11-24 | Co-authored lures | Learning goal and authentic portfolio content. |
| 2026-11-24 | Exclusion list | Real-world ethical requirement; cheap to implement. |
