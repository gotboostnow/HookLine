# ADR-001: Click-only, no credential capture

- **Status:** Accepted
- **Date:** 2026-11-24

## Context

Phishing simulators that reproduce login pages are effective at collecting
credentials, but that turns a training exercise into a real security incident.
It also creates legal and ethical exposure and makes the tool indistinguishable
from a phishing kit.

## Decision

Hookline records only clicks and reports. There is no fake login page, no
password field, no MFA prompt, and no credential storage anywhere in the
recipient flow. The CTA leads to a tracking redirect and then an education page.

## Consequences

- The product is safe to demo and explain to a hiring manager.
- Metrics are less granular than credential-capture tools, but they measure the
  useful behaviour: did the recipient click or report?
- Any future feature must be checked against this invariant; requests for fake
  forms are refused.
