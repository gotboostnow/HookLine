# ADR-006: Snapshot recipients at launch; tokens are capabilities

- **Status:** Accepted
- **Date:** 2026-11-24

## Context

A campaign's audience should not change after launch, and recipient URLs must
not be guessable or enumerable. Editing targets later should not rewrite the
results of a running exercise.

## Decision

Draft saves sync `CampaignRecipient` rows. Launch freezes the snapshot, sets
`sent_at`, and generates one 256-bit `secrets.token_urlsafe(32)` token per
recipient. The token is unique and is the only credential needed for the
recipient routes.

## Consequences

- Results stay stable and attributable to the launched audience.
- No sequential IDs appear in recipient URLs.
- Tokens are redacted from logs and given `no-referrer` / `noindex` headers.
- Losing a token means losing access to that inbox; there is no recipient login.
