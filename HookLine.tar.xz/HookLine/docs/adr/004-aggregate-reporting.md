# ADR-004: Aggregate-first reporting with per-campaign named opt-in

- **Status:** Accepted
- **Date:** 2026-11-24

## Context

Detailed results are useful for training, but linking every click to a named
person encourages blame and turns a learning exercise into surveillance.

## Decision

Campaigns default to `aggregate` reporting. The detail page shows funnels,
department breakdowns, timelines, and event types without names. `named` mode
is an explicit per-campaign choice and shows names, emails, and timestamps.

## Consequences

- The safe default is visible in the UI and in the seed data.
- Aggregate mode is a display policy only; recipient rows still link tokens to
  targets and must be treated as personal data.
- Named mode is available for justified, authorized exercises.
