# ADR-003: Library-first lure generator with an LLM seam

- **Status:** Accepted
- **Date:** 2026-11-24

## Context

Lures need to be consistent, safe, and reviewable. Generating them live with a
model would add a runtime dependency, unpredictable content, and a review
burden that a portfolio demo does not need.

## Decision

The v1 library is hand-authored and reviewed. Lure content is parameterized
with a fixed eight-field context and sanitized on save and after rendering. A
generator seam is reserved for future work as a protocol; no runtime LLM
dependency is added.

## Consequences

- The six demo lures are deterministic and safe to show.
- Adding generation later does not require changing rendering or education
  paths.
- Every lure still needs human review against the authoring guide.
