# ADR-005: Django + HTMX + SQLite, native local run

- **Status:** Accepted
- **Date:** 2026-11-24

## Context

The owner wants a portfolio artifact that runs locally without infrastructure.
The stack should show Django craft and be easy for an interviewer to inspect.

## Decision

Use Django with server-rendered templates, small HTMX partials, plain CSS with
custom properties, and SQLite. Run natively with a virtualenv and Makefile; no
Docker, Node, Tailwind CDN, or external fonts.

## Consequences

- A clean checkout runs with two commands and no containers.
- HTMX adds interactivity without a build step.
- SQLite is demo-scale; production would use PostgreSQL and a task queue.
