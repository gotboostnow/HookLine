# ADR-002: Simulated inbox by default; Mailpit optional; real SMTP gated

- **Status:** Accepted
- **Date:** 2026-11-24

## Context

The demo must run offline on a laptop. At the same time, showing that a real
delivery adapter exists is valuable for the portfolio story. Sending mail
carelessly would violate the project's safety posture.

## Decision

`SimulatedInboxSender` is the default and needs no service. `SmtpSender` is an
optional adapter selected from the configured mailer backend. External delivery
requires `DEMO_MODE=0`, a non-empty `ALLOWED_RECIPIENT_DOMAINS`, and every
recipient domain must be in that allowlist. Mailpit is fetched as a standalone
binary into `.tools/` and is never required.

## Consequences

- `make demo` works without network access.
- The SMTP path can be shown in five minutes when Mailpit is installed.
- Misconfiguration fails closed rather than sending mail to real people.
