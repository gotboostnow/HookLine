# Hookline threat model

Hookline is an authorized security-awareness simulator. It is intentionally a
single-tenant, demo-first application: it teaches recipients without capturing
credentials and gives administrators enough measurement to improve processes.
This document records what we protect, who we assume might attack it, and where
the remaining risk sits.

## Assets

| Asset | Why it matters |
| --- | --- |
| Capability tokens (`/i/`, `/t/`, `/education/`) | A token is the only credential needed to reach one recipient's inbox and education page. |
| Recipient identities and group membership | Names, emails, departments, and groups are personal data. |
| Lure templates | Sanitized content plus red flags and principles; unsafe HTML would become an XSS vector. |
| Campaign authorization records | Evidence that an exercise was approved and scoped. |
| Click and report events | Sensitive behavioural data; useful for teaching, harmful if used for blame. |
| Admin sessions | Staff access can launch campaigns and view results. |
| SMTP configuration | A misconfiguration could send mail outside the demo boundary. |

## Actors

- **Administrator/operator** — trusted to run authorized exercises, but can make mistakes (overbroad scope, unintended SMTP configuration).
- **Recipient** — receives a simulated message; may click, report, or share the link.
- **Curious third party** — tries to enumerate tokens or probe recipient routes.
- **Malicious lure author** — supplies HTML that tries to break out of the sanitizer (insider or compromised admin account).
- **Mail scanner / link prefetcher** — automated fetch that can inflate click counts.
- **Hosting environment** — filesystem and process-level access; out of scope beyond local/demo deployment.

## Trust boundaries

1. **Staff/admin → application**: protected by Django authentication, `StaffRequiredMixin`, and CSRF on every POST.
2. **Recipient → application**: protected by unguessable capability tokens, not by login.
3. **Lure author HTML → rendered page**: protected by `nh3` sanitization on save and again after rendering.
4. **Application → email system**: protected by the demo-mode gate and recipient-domain allowlist.
5. **Application → logs**: protected by a filter that redacts recipient routes.

## Threats and mitigations

| Threat | Mitigation |
| --- | --- |
| Token guessing or enumeration | `secrets.token_urlsafe(32)` gives 256 bits of entropy; a unique index prevents collisions. Tokens never appear in sequential URLs. |
| Token leakage via referrers or indexes | `Referrer-Policy: no-referrer` and `X-Robots-Tag: noindex` on all recipient routes; admin pages use `no-referrer` globally. |
| Token leakage via logs | Logging filter rewrites `/i/`, `/t/`, and `/education/` token segments to `<redacted>`; application logs use campaign IDs, not recipient identities. |
| XSS from lure HTML | `nh3` allowlist on save and after rendering; scripts, styles, forms, iframes, event handlers, `javascript:` URLs, and external images are removed; links gain `rel="noopener noreferrer"`. |
| Unauthorized campaign launch | `authorized_by`, `authorization_scope`, and an acknowledgment are required; launch validates again and refuses drafts missing any gate. |
| Excluded recipient contacted | Exclusion flag is checked by the picker, launch validation, and a final filter that removes excluded rows before delivery. |
| Accidental external email | Default backend is the console; `DEMO_MODE=1` blocks SMTP; SMTP additionally requires a non-empty recipient-domain allowlist and every recipient domain must match. |
| CSRF on admin or report actions | Django's `CsrfViewMiddleware` applies to all POSTs; the report view also uses `csrf_protect` explicitly. |
| Clickjacking | `X-Frame-Options: DENY`; `X-Content-Type-Options: nosniff`; `Permissions-Policy` disables camera, microphone, geolocation, payment, and USB. |
| Credential phishing by the simulator | No fake login page, password field, attachment, or credential storage exists anywhere in the recipient flow. Click-only. |
| Oversharing of results | Aggregate reporting is the default. Named reporting is a per-campaign opt-in and the detail page hides names completely in aggregate mode. |
| Excessive report spam | A simple cache-based throttle allows 10 reports per token per minute. |
| Indefinite event retention | `Organization.retention_days` defaults to 90; `python manage.py purge_events` deletes old tracking events. |
| Third-party tracking from recipient pages | No external fonts, images, analytics, CDNs, or scripts; only local static assets are loaded. |

## Legal and ethical notes

- Only run simulations with written authorization that names the audience, the
  timeframe, and the person approving the exercise. Hookline records this, but
  a form field is not a substitute for real permission.
- Works councils, GDPR/data-protection officers, and local employment law may
  require notice, consultation, or a data-protection assessment before a real
  campaign. Obtain legal review before deployment outside the demo.
- Aggregate mode is a reporting policy, not anonymization. Recipient rows still
  link tokens to targets, so treat the database as personal data.
- Tell recipients what happened on the education page and keep the tone
  supportive. The goal is learning, not punishment.
- The fictional Northwind Logistics dataset uses `.example` addresses and must
  never be replaced with real employee data in a public demo.

## Dependency audit

`pip-audit -r requirements.txt` reported no known vulnerabilities on
2026-11-25. The audit runs in CI on every push and pull request.

## Known limitations

- Link prefetchers and mail scanners can inflate click rates; production would
  need scanner detection or a two-step click.
- Aggregate reporting hides names in the UI but does not anonymize storage.
- SQLite is demo-scale; a real deployment would use PostgreSQL and a queue for
  delivery.
- Delivery is synchronous; SMTP failures can partially deliver a campaign.
- The per-token report throttle uses the local in-memory cache and is not shared
  across processes.
- There is no SSO, multi-tenancy, billing, background jobs, or full anonymization.
- Production deployments should run `python manage.py check --deploy` and set
  `DJANGO_DEBUG=0`, a real `DJANGO_SECRET_KEY`, HTTPS, and secure cookies.

## Reporting issues

See [SECURITY.md](../SECURITY.md) for responsible disclosure and the
responsible-use notice.
