# Glossary

Shared vocabulary for Hookline. If a term here changes, update the code, the
spec, and this file together.

**Aggregate reporting** — the default reporting mode. Results are shown as
counts and rates; recipient names are never rendered. It is a display policy,
not anonymization of stored data.

**Authorization record** — the `authorized_by`, `authorization_scope`, and
`authorization_acknowledged` fields on a campaign. Launch is blocked until all
three are complete.

**Campaign** — one simulation run with one lure, a status (`draft`, `active`,
`closed`), a reporting mode, and a fixed recipient snapshot.

**CampaignRecipient** — a target's row inside a campaign. It holds the
capability token, send/click/report timestamps, and links to events.

**Capability token** — a 256-bit URL-safe secret that grants access to one
recipient's inbox, click route, report route, and education page. It is not a
login credential.

**Click event** — a `TrackingEvent` with type `click`, created every time the
CTA is opened. Only the first click sets `clicked_at`.

**Closed campaign** — a campaign whose results are frozen. Inbox and tracking
routes stop; the education page still renders.

**Demo mode** — the default setting (`DEMO_MODE=1`) that refuses all external
SMTP delivery.

**Department breakdown** — per-department delivered, clicked, and reported
counts on a campaign detail page.

**Education page** — the personalized reveal and lesson at `/education/<token>/`.
It explains what happened without blame.

**Excluded target** — a target flagged `is_excluded` with a reason. Excluded
targets are visible in the picker but disabled and are never delivered to.

**Funnel** — delivered → clicked → reported counts for a campaign.

**Group** — a reusable segment of targets used only to make selection easier.
It is not a campaign snapshot.

**Lure** — a parameterized phishing email template with a sender, subject,
sanitized HTML body, CTA text, principles, red flags, and difficulty.

**Named reporting** — an opt-in mode that links outcomes to individual
recipients on the detail page. Requires a deliberate choice when the draft is
created.

**Northwind Mail** — the fictional mail client used by the simulated inbox.

**Organization** — the enforced singleton that owns all demo data and the
retention window.

**Principle** — a social-engineering lever such as authority, urgency, or
trust. Lures declare at least one; the education page explains each.

**Red flag** — a concrete, observable detail the recipient could have noticed.
Lures declare at least one.

**Recipient** — a person in a campaign, represented by a `CampaignRecipient`.

**Report event** — a `TrackingEvent` with type `report`. Only the first report
sets `reported_at`; every report creates an event.

**Retention window** — `Organization.retention_days` (default 90).
`purge_events` deletes older `TrackingEvent` rows.

**Sender adapter** — `SimulatedInboxSender` (default) or `SmtpSender`
(Mailpit/allowlisted SMTP), selected from the mailer backend.

**Simulated inbox** — the private `/i/<token>/` page. Opening it records no
event.

**Target** — an imported person with name, email, department, and optional
exclusion. Targets belong to a group through a many-to-many relation.

**TrackingEvent** — an append-only click or report row. It stores no IP,
user-agent, or other request metadata.
