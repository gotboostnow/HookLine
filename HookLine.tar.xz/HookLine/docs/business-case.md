# Hookline business case (portfolio one-pager)

> This is a portfolio document illustrating product thinking, not a real
> business plan or investment solicitation. Figures are illustrative.

## Ideal customer profile

Small and mid-sized organizations with **50–500 employees** and an IT generalist
who owns security part-time. No dedicated security team, no SSO budget, and
growing pressure from cyber-insurance questionnaires, customer security reviews,
and basic compliance frameworks. They need to run an awareness exercise without
buying an enterprise platform or sending employee data to a third-party cloud.

## Problem

Phishing remains a top initial-access vector. Enterprise awareness suites are
expensive, cloud-only, and often feel like surveillance. Free open-source tools
such as Gophish are powerful but raw: they assume a security operator, offer
little teaching content, and have a steep setup story. SMBs need something
lightweight, self-hosted, privacy-first, and explainable to non-specialists.

## Solution

Hookline is a self-hosted simulator with a safety-first design:

- **Click-only** — no credential capture and no fake login page.
- **Aggregate-first** — named reporting is a deliberate per-campaign opt-in.
- **Simulated inbox default** — the demo works offline; optional Mailpit proves
  real delivery without requiring it.
- **Explicit authorization** — no campaign launches without a recorded scope.
- **Teaching built in** — every click or report ends on a personalized lesson
  with the exact red flags and social-engineering principle.
- **Transparent stack** — Django, HTMX, SQLite, plain CSS; no Docker and no
  runtime AI dependency.

## Competitors and positioning

| Tool | Strength | Gap Hookline addresses |
| --- | --- | --- |
| KnowBe4 | Mature content library and integrations | Enterprise pricing and cloud delivery; heavier than an SMB needs |
| Proofpoint | Strong email security and awareness | Security-enterprise focus, not a self-hosted teacher's tool |
| Hoxhunt | Engaging, gamified training | SaaS-first and data leaves the organization |
| Gophish | Free, widely known, flexible | Raw operator UX, no structured education loop, safety posture is the admin's job |

**Positioning:** "the privacy-first, self-hosted phishing awareness teacher for
SMBs." Hookline is not trying to beat enterprise suites on content volume; it
wins on safety, transparency, and a five-minute understandable demo.

## Pricing sketch (illustrative)

- **Community:** free, self-hosted, up to 50 targets, single organization,
  community support.
- **Team:** flat **$1,200/year** per organization, up to 500 targets, offline
  updates, authorization exports, and email support.
- **MSP:** **$3,600/year**, ten managed organizations, shared branding, and a
  partner dashboard.

Flat pricing avoids punishing training frequency. Per-seat pricing is rejected
because it discourages including everyone.

## Go-to-market

- **MSP partnerships** — managed service providers already sell security
  packages to SMBs and need a story that does not add cloud risk.
- **Cyber-insurance referrals** — insurers increasingly want proof of
  awareness training; a self-hosted, no-blame program is easy to recommend.
- **Content marketing** — publish the threat model, lure authoring guide, and
  no-blame reporting playbook; let the transparency do the selling.
- **Local meetups and open-source demos** — a five-minute walkthrough is the
  primary conversion asset.

## Risks

- **Crowded market** — differentiation must stay on privacy, safety, and
  simplicity rather than content volume.
- **Deliverability** — real SMTP is optional and gated; Mailpit covers the
  demo, and production would require SPF/DKIM/DMARC planning.
- **Legal and works-council review** — real deployments may need notice and
  consultation; the threat model documents this clearly.
- **AI commoditizing content** — lure text becomes cheap, so the durable value
  is the teaching loop, the safety gates, and the reporting model.
- **Single-tenant scope** — multi-tenancy, SSO, and a task queue are explicit
  future work, not hidden promises.

## Success metrics for the product

- Time from clean checkout to first simulated campaign: under ten minutes.
- Demo length: under five minutes.
- Recipient report rate trending up across campaigns while click rate trends
  down.
- Zero credential fields, zero external assets on recipient pages, and a clean
  security audit on every release.
