# Lure worksheet — T14

This worksheet is for the four lures you write yourself. Fill in one block per
scenario, then either paste the fields into **Lures → New lure** in the app or
hand the filled blocks back for entry into the seed data.

The two lures already in `seed_demo` ("Supplier invoice overdue" and "Password
expiry notice") are the worked examples; see `docs/social-engineering.md` for
the full guide and review checklist.

## Ground rules

- **Click only.** No password, MFA, recovery code, attachment, or login page.
- **Fictional only.** Invented brands, people, and domains. Sender addresses
  must end in `.example`. No real company, logo, or executive.
- **Body is HTML.** Put the tracked link in the Body HTML box as
  `<a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a>`.
  The **Cta text** box is only the button label (e.g. "Review document"), not a URL.
- **Available placeholders:** `first_name`, `last_name`, `full_name`, `email`,
  `department`, `company_name`, `cta_url`, `cta_text`. Nothing else resolves.
- **Allowed tags:** `p`, `br`, `strong`, `em`, `u`, `ul`, `ol`, `li`, `h1`–`h3`,
  `a`, `div`, `span`, `table`, `thead`, `tbody`, `tr`, `td`, `th`, `img`.
  No styles, scripts, forms, or external images.
- **Red flags:** one plain-language observation per line, from the recipient's
  point of view — something a careful person could actually notice.
- **Difficulty:** honest. "Easy" has an obvious mismatch; "hard" closely mimics
  a real internal process.
- **Tone:** a cautious colleague, not a prankster. No shame or fake consequences.

---

## 1. HR policy update

**Lesson:** verify an unexpected policy/process change through a known channel.
**Suggested levers:** authority, trust. **Difficulty:** medium.

- **Name** (internal, short): ______________________________
- **Description** (one line): ______________________________
- **Principles** (pick keys from: authority, urgency, fear, curiosity,
  social_proof, reciprocity, greed, trust): ______________________________
- **Difficulty** (easy / medium / hard): ______________________________
- **Sender name** (fictional): ______________________________
- **Sender email** (`…@….example`): ______________________________
- **Subject**: ______________________________
- **Body HTML** (2–3 sentences + one CTA link):

  ```html
  <p>Hi {{ first_name }},</p>
  <p>...</p>
  <p><a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a></p>
  <p>...<br>...</p>
  ```

- **Cta text** (label only, e.g. "Read the update"): ______________________________
- **Red flags** (one per line):
  1. ______________________________
  2. ______________________________
  3. ______________________________

---

## 2. CEO gift-card request

**Lesson:** verify unusual requests from senior people through a second channel.
**Suggested levers:** authority, urgency. **Difficulty:** easy or medium.

- **Name** (internal, short): ______________________________
- **Description** (one line): ______________________________
- **Principles** (pick keys): ______________________________
- **Difficulty**: ______________________________
- **Sender name** (fictional executive): ______________________________
- **Sender email** (`…@….example`): ______________________________
- **Subject**: ______________________________
- **Body HTML**:

  ```html
  <p>Hi {{ first_name }},</p>
  <p>...</p>
  <p><a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a></p>
  <p>...<br>...</p>
  ```

- **Cta text**: ______________________________
- **Red flags** (one per line):
  1. ______________________________
  2. ______________________________
  3. ______________________________

---

## 3. Shared document

**Lesson:** confirm an unexpected share with the supposed sender before opening.
**Suggested levers:** curiosity, trust. **Difficulty:** medium.

- **Name** (internal, short): ______________________________
- **Description** (one line): ______________________________
- **Principles** (pick keys): ______________________________
- **Difficulty**: ______________________________
- **Sender name** (fictional colleague or service): ______________________________
- **Sender email** (`…@….example`): ______________________________
- **Subject**: ______________________________
- **Body HTML**:

  ```html
  <p>Hi {{ first_name }},</p>
  <p>...</p>
  <p><a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a></p>
  <p>...<br>...</p>
  ```

- **Cta text**: ______________________________
- **Red flags** (one per line):
  1. ______________________________
  2. ______________________________
  3. ______________________________

---

## 4. Delivery notification

**Lesson:** check the carrier and tracking details independently of the email.
**Suggested levers:** curiosity, urgency. **Difficulty:** easy.

- **Name** (internal, short): ______________________________
- **Description** (one line): ______________________________
- **Principles** (pick keys): ______________________________
- **Difficulty**: ______________________________
- **Sender name** (fictional courier): ______________________________
- **Sender email** (`…@….example`): ______________________________
- **Subject**: ______________________________
- **Body HTML**:

  ```html
  <p>Hi {{ first_name }},</p>
  <p>...</p>
  <p><a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a></p>
  <p>...<br>...</p>
  ```

- **Cta text**: ______________________________
- **Red flags** (one per line):
  1. ______________________________
  2. ______________________________
  3. ______________________________

---

## Before you hand it back

- [ ] Six lures total once these four are added (two already seeded).
- [ ] Every sender address ends in `.example`; no real brands or people.
- [ ] No credential request, attachment, or external asset.
- [ ] Each Body HTML contains `{{ cta_url }}` exactly once, in the link's href.
- [ ] Each Cta text is just a label, with no URL or placeholder text.
- [ ] At least one red flag per lure, all specific and observable.
- [ ] Difficulty and principles match how subtle the message really is.
