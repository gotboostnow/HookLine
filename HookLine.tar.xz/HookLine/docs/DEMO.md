# Five-minute demo script

This script is written for a hiring manager watching a recorded walkthrough or
following along locally. It should take about five minutes. Run
`python manage.py seed_demo --with-admin` first; the command prints the admin
password and three sample inbox links. Use those links instead of the
`<token>` placeholders below.

## Before recording

```bash
make demo
```

The browser should be at `http://127.0.0.1:8000/`. Use a 1440×900 window for
the admin screens and a narrower window for the mobile inbox shot. Close tabs
and notifications before starting.

## Walkthrough

### 0:00–0:30 — Frame the problem

Log in as `demo-admin`. Say: "This is Hookline, a self-hosted phishing
simulator. It is click-only: no fake login page and no credential capture. The
goal is to teach, not to embarrass." Mention the written-authorization gate.

### 0:30–1:00 — Dashboard

Point at the KPI cards: campaign count, target count, average click rate,
average report rate. Explain that rates are unique clicks and reports divided
by delivered recipients, and that aggregate reporting is the default.

### 1:00–1:45 — Campaign detail

Open **Q3 Invoice Review** from the campaign table. Show the no-blame banner,
the funnel (delivered → clicked → reported), the department breakdown, the
activity timeline, and the event log. This campaign is named-reporting mode, so
show the recipient table with timestamps, then note that a new campaign would
default to aggregate and hide those names.

### 1:45–2:30 — Draft and authorization

Open **October Password Reset**. Show the target picker, the excluded targets
disabled with their reasons, the lure selection, and the authorization panel.
Explain that launch is blocked until the authorizer, scope, and acknowledgment
are recorded.

### 2:30–3:15 — Recipient inbox

Open the **no action** sample link:

```text
http://127.0.0.1:8000/i/<token>/
```

Show the Northwind Mail provider bar, folder list, selected message, and
**Report phishing** button. Resize the window to show the stacked mobile
layout. Say that opening this page records nothing.

### 3:15–3:50 — Click and education

Click the CTA in the message body. The redirect lands on
`/education/<token>/`. Show the reveal banner — "This was a simulated phishing
email. No data was captured" — the outcome, the email preview, numbered red
flags, the principle explanation, and the next-steps checklist.

### 3:50–4:20 — Report flow

Open the **reported** sample link, then press **Report phishing**. Show the
positive confirmation on the education page and explain that every report
creates an event but only the first sets `reported_at`.

### 4:20–4:45 — Results update

Return to the dashboard and show the campaign table rates. Mention that
aggregates update immediately and that names are hidden unless a campaign
explicitly opts into named reporting.

### 4:45–5:00 — Optional Mailpit proof

If time allows: "With Mailpit installed, switching `EMAIL_BACKEND` to SMTP and
setting `DEMO_MODE=0` plus an allowlist sends a real message to the local mail
UI. The same gate refuses external delivery by default." Do not actually
change settings during the recording.

## Storyboard

| Time | Shot | Narration focus |
| --- | --- | --- |
| 0:00 | Title card: Hookline — hook, line, and awareness | Portfolio artifact, authorized use |
| 0:30 | Dashboard KPI cards | Safety-first metrics |
| 1:00 | Campaign detail funnel | No-blame reporting and teaching signal |
| 1:45 | Draft editor with picker and authorization | Exclusions and launch gates |
| 2:30 | Simulated inbox, desktop then mobile | Convincing client, no event on open |
| 3:15 | Education page | Personalized lesson, no data captured |
| 3:50 | Report confirmation | Reporting is the win |
| 4:20 | Dashboard refresh | Aggregate-by-default results |
| 4:45 | Settings summary or Mailpit note | Delivery adapter gate |

## Capture checklist for T15

- Dashboard with seeded metrics.
- Campaign detail with funnel and named table.
- Simulated inbox at desktop and mobile widths.
- Education page with red flags visible.
- Lure library card grid.
- Recorded walkthrough, 3–5 minutes, no real personal data in the frame.
