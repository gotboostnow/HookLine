# Hookline — Ticket Breakdown

**Status:** Planning complete; build not started
**Date:** 2026-11-24
**Spec:** `hookline-spec.md` (copy into `docs/spec.md` at T0)
**Convention:** Work tickets in dependency order. A ticket is done only when its acceptance criteria are met and its tests pass.

## Status table

| ID | Title | Status | Blocked by |
| --- | --- | --- | --- |
| T0 | Project bootstrap & handoff | done | — |
| T1 | Django scaffold & tooling | done | T0 |
| T2 | Core data model | done | T1 |
| T3 | Seed demo command | done | T2 |
| T4 | Auth & app shell | done | T1 |
| T5 | Targets & groups | done | T2, T4 |
| T6 | Lure library | done | T2, T4 |
| T7 | Campaign draft & authorization | done | T5, T6 |
| T8 | Launch & sender adapters | done | T7 |
| T9 | Recipient inbox | done | T8 |
| T10 | Tracking, education, report | done | T9 |
| T11 | Dashboard & reporting | done | T10 |
| T12 | Security hardening | done | T10 |
| T13 | Docs & demo package | done | T11, T12 |
| T14 | Content pass: four lures (human) | in_progress | T6, T13 |
| T15 | Demo video & screenshots (human) | todo | T13 |
| T16 | Final QA & release | todo | T13, T14, T15 |

Status values: `todo`, `in_progress`, `blocked`, `done`.

---

## T0 — Project bootstrap & handoff

**Goal:** Create the repository, bring the planning documents into it, and leave a handoff file that lets another agent resume.

**Tasks**

- Create a fresh git repository inside `/home/ranas/Documents/Projects/PhishingSimulator`. The home directory is itself a git repository; do not touch the outer repo.
- Add `.gitignore`: `.venv/`, `db.sqlite3`, `.env`, `.tools/`, `__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `staticfiles/`, `media/`, `*.log`.
- Add `.editorconfig` (4 spaces for Python/HTML, 2 for CSS/JS, UTF-8, LF).
- Add `LICENSE` (MIT) and a responsible-use notice.
- Copy `hookline-spec.md` to `docs/spec.md` and this file to `docs/tickets.md`.
- Create `AGENTS.md` from the draft, with the current status and a pointer to `docs/spec.md` and `docs/tickets.md`.
- Create `README.md` stub.
- Initial commit.

**Acceptance criteria**

- `git status` is clean after the initial commit.
- `docs/spec.md`, `docs/tickets.md`, and `AGENTS.md` exist.
- No Docker files are added.
- `AGENTS.md` contains the safety invariants and the resume procedure.

---

## T1 — Django scaffold & tooling

**Goal:** A runnable Django project with the app structure, settings, Makefile, and CI.

**Tasks**

- Create `.venv` and install Django (latest release compatible with the installed Python; prefer an LTS).
- `django-admin startproject config .`.
- Create apps: `core`, `targets`, `lures`, `campaigns`, `tracking`.
- Configure settings: SQLite, `templates/`, `static/`, auth redirects, `TIME_ZONE="UTC"`, `USE_TZ=True`, env loading.
- Add `.env.example` with the keys from the spec.
- Add `config/urls.py` with a health route and the app URL includes.
- Add `requirements.txt` and `requirements-dev.txt`.
- Add `pyproject.toml` with ruff and pytest configuration.
- Add `Makefile`: `setup`, `migrate`, `seed`, `run`, `test`, `lint`, `mailpit`, `mailpit-run`, `demo`.
- Add GitHub Actions workflow: install, ruff, pytest, pip-audit.
- Add `templates/base.html` placeholder and `static/css/app.css`.

**Acceptance criteria**

- `make setup && make migrate && make run` works from a clean checkout.
- `make test` runs (even with no tests yet).
- `ruff check` passes.
- CI is green.
- No Node, no Docker.

---

## T2 — Core data model

**Goal:** All domain models, migrations, admin registrations, factories, and model tests.

**Tasks**

- `core.Organization` singleton.
- `targets.Target` and `targets.Group`.
- `lures.LureTemplate`.
- `campaigns.Campaign` and `campaigns.CampaignRecipient`.
- `tracking.TrackingEvent`.
- Token generation helper using `secrets.token_urlsafe(32)`.
- Constraints and indexes from the spec.
- Admin registrations for back-office inspection.
- `factory_boy` factories.
- Model tests: uniqueness, token length/entropy, campaign validation helpers, exclusion filtering.

**Acceptance criteria**

- `python manage.py makemigrations --check` reports no changes.
- Migrations apply cleanly.
- Tests cover the constraints and token generation.
- Django admin loads without errors.

---

## T3 — Seed demo command

**Goal:** One command creates the fictional demo organization and a demo-ready dataset.

**Tasks**

- `core/management/commands/seed_demo.py`.
- `--reset` wipes demo data and recreates it.
- `--with-admin` creates a superuser with a generated password printed once.
- Create Northwind Logistics, `northwind.example`, retention 90.
- Create 200 targets across Finance, HR, Sales, Operations, IT, Customer Support. Use a fixed seed (Faker or a static list) for reproducibility.
- Create groups: Finance, All Staff, Executives.
- Create 3 excluded targets with reasons.
- Create 2 lures: fake invoice (agent), password expiry (agent).
- Create a completed campaign "Q3 Invoice Review": ~38% clicked, ~12% reported, named reporting, events spread over five days.
- Create a draft campaign "October Password Reset".
- Print three sample inbox URLs.
- Tests: idempotency, counts, sample URLs, `--reset`.

**Acceptance criteria**

- Running the command twice does not duplicate data.
- Counts match the spec.
- Sample inbox URLs resolve after the completed campaign is active.
- `--reset` produces a clean dataset.

---

## T4 — Auth & app shell

**Goal:** Staff-only admin shell with the design system, navigation, and light/dark theme.

**Tasks**

- Login/logout templates using Django auth.
- `StaffRequiredMixin` for all admin views.
- Base template: sidebar (Dashboard, Campaigns, Lures, Targets, Groups, Settings), top bar, messages, theme toggle, user menu.
- CSS design system: custom properties, light/dark themes, buttons, cards, badges, tables, forms, empty states.
- Theme cookie `hookline_theme` (`light`, `dark`, `system`) with an inline pre-paint script.
- 403 and 404 pages.
- Dashboard placeholder.
- Tests: auth redirect, login, theme cookie.

**Acceptance criteria**

- Unauthenticated admin requests redirect to login.
- Staff users can log in and out.
- Theme choice persists and applies without a flash.
- Basic keyboard navigation and focus states work.
- No external fonts or assets.

---

## T5 — Targets & groups

**Goal:** Manage targets, exclusions, imports, and groups.

**Tasks**

- Target list with search and department filter (HTMX).
- Add/edit target form.
- Exclude/unexclude with a reason.
- CSV import: `first_name,last_name,email,department,groups`; groups semicolon-separated.
- Import behavior: create new, update existing by email, preserve `is_excluded`, add group memberships.
- Group CRUD and target assignment.
- Tests: import validation, duplicate handling, exclusion, auth.

**Acceptance criteria**

- Invalid CSV rows produce clear errors and do not crash the import.
- Existing targets are updated, not duplicated.
- Excluded targets show a badge and reason.
- HTMX search/filter works without a full page reload.
- Admin routes require staff login.

---

## T6 — Lure library

**Goal:** Manage lures and render them safely.

**Tasks**

- Lure card grid: name, principles, difficulty, sender, subject, active badge.
- Create/edit form with a live preview.
- `lures/sanitizer.py` using `nh3` with the allowlist from the spec.
- Fixed rendering context: `first_name`, `last_name`, `full_name`, `email`, `department`, `company_name`, `cta_url`, `cta_text`.
- Preview with sample context: Alex Chen, Finance, Northwind Logistics.
- Active toggle.
- Principles, difficulty, and red-flags UI.
- Two worked example lures (content).
- `docs/social-engineering.md` authoring guide.
- Tests: XSS payloads, external images, `style` attributes, script tags.

**Acceptance criteria**

- XSS payloads are stripped or neutralized.
- External images and scripts do not render.
- Preview shows the rendered lure with sample data.
- Campaigns can reference active lures.
- Admin routes require staff login.

---

## T7 — Campaign draft & authorization

**Goal:** Create and edit draft campaigns with recipients and an authorization record.

**Tasks**

- Campaign list with status filter (HTMX).
- Create/edit draft: name, lure, target picker.
- Target picker: filter by group, search, select all, excluded targets disabled with a reason.
- Authorization panel: authorizer, scope, acknowledgment, warning copy.
- Create `CampaignRecipient` rows for selected targets; remove unselected rows in draft; generate tokens.
- Validation: name, lure, at least one recipient, authorization before launch.
- Tests: draft editing, exclusion filtering, token generation, launch validation errors.

**Acceptance criteria**

- Draft campaigns can be edited freely.
- Excluded targets cannot be added.
- Every recipient row has a unique token.
- Launch is blocked with clear errors until authorization is complete.
- Admin routes require staff login.

---

## T8 — Launch & sender adapters

**Goal:** Launch campaigns and deliver via the simulated inbox or Mailpit.

**Tasks**

- `campaigns/senders.py`: `Sender` protocol, `SimulatedInboxSender`, `SmtpSender`.
- Demo-mode gate: external SMTP refused unless `DEMO_MODE=0` and the recipient domain is in `ALLOWED_RECIPIENT_DOMAINS`.
- Launch action: validate, filter excluded, set `sent_at`, set `status=active`, call sender.
- Close action: `status=closed`, `closed_at`.
- Sender configuration via environment.
- Tests with a fake sender; gate tests; close tests.

**Acceptance criteria**

- Launch transitions the campaign to active and sets `sent_at`.
- Simulated sender requires no external service.
- External SMTP is refused in demo mode.
- Close freezes the campaign.
- Sender failures are logged without recipient PII.

---

## T9 — Recipient inbox

**Goal:** A convincing per-recipient simulated inbox.

**Tasks**

- `/i/<token>/` view.
- Mail client layout: provider bar, folder sidebar, message list, reading pane, report button.
- Render the sanitized lure body and CTA link.
- 404 for invalid tokens and non-active campaigns.
- No click event on inbox view.
- Responsive layout.
- Tests: active-only, invalid token, no event, report button present.

**Acceptance criteria**

- The inbox renders only for active campaigns.
- Opening the inbox creates no tracking event.
- The CTA points at `/t/<token>/`.
- The report button posts to `/t/<token>/report/` with CSRF.
- Mobile layout is usable.

---

## T10 — Tracking, education, report

**Goal:** Record clicks and reports, and teach the recipient.

**Tasks**

- `/t/<token>/` click: first timestamp, event, redirect to education.
- `/t/<token>/report/` POST: first timestamp, event, redirect to education.
- `/education/<token>/` personalized page: reveal banner, outcome, red flags, principle, next steps, report CTA.
- Reported variant.
- Closed campaign behavior: education renders, no new events.
- `Referrer-Policy: no-referrer` and `X-Robots-Tag: noindex` on recipient routes.
- Tests: click/report events, idempotency, education context, closed campaign, invalid token, CSRF.

**Acceptance criteria**

- First click/report timestamps are set once.
- Every click/report creates an event.
- Education page shows the lure's red flags and principles.
- Closed campaigns do not record new events.
- CSRF is enforced on report POST.
- No IP or user agent is stored.

---

## T11 — Dashboard & reporting

**Goal:** Make the results legible.

**Tasks**

- Dashboard KPI cards: campaigns, targets, average click rate, average report rate.
- Campaign table with status, lure, recipients, click rate, report rate, launched date.
- Campaign detail: funnel, department breakdown, timeline, recipient table (named only), event log, no-blame banner.
- Aggregate mode hides names; named mode shows them.
- HTMX filters and pagination.
- Tests: metric calculations, aggregate vs. named, auth.

**Acceptance criteria**

- Click rate = unique clicked / delivered.
- Report rate = unique reported / delivered.
- Aggregate mode never renders recipient names.
- Named mode renders names and timestamps.
- The no-blame banner appears on reports.
- Admin routes require staff login.

---

## T12 — Security hardening

**Goal:** Make the simulator's own security part of the portfolio story.

**Tasks**

- Sanitization audit across all lure rendering paths.
- Security headers: `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`.
- `Referrer-Policy: no-referrer` and `X-Robots-Tag: noindex` on recipient routes.
- Log redaction filter for `/i/`, `/t/`, `/education/` paths.
- Token entropy check and unique index verification.
- CSRF tests for all POSTs.
- Rate-limit report POST per token (optional, simple cache-based).
- `pip-audit` in CI.
- `docs/threat-model.md`: assets, actors, trust boundaries, threats, mitigations, legal notes, known limitations.
- Security tests: XSS payloads, token enumeration, CSRF, headers, log redaction.

**Acceptance criteria**

- Security tests pass.
- No token appears in application logs.
- Recipient routes send the correct headers.
- Threat model is complete and linked from the README.
- `pip-audit` is clean or documented.

---

## T13 — Docs & demo package

**Goal:** Everything an interviewer needs to understand and run the project.

**Tasks**

- README: what it is, screenshots (placeholders until T15), demo video (placeholder until T15), features, safety, quickstart, architecture (Mermaid), tests, docs links, license.
- `docs/GLOSSARY.md`.
- `docs/adr/` with the six ADRs.
- `docs/threat-model.md` (from T12).
- `docs/social-engineering.md` (from T6).
- `docs/DEMO.md`: five-minute script and storyboard.
- `docs/business-case.md`.
- `SECURITY.md`.
- `LICENSE` and responsible-use notice.
- Update `AGENTS.md` with progress.
- Seed demo polish and sample URLs.

**Acceptance criteria**

- README quickstart works from a clean checkout.
- All internal links resolve.
- Demo script runs end-to-end.
- Business case covers ICP, competitors, positioning, pricing sketch, risks.
- AGENTS.md reflects the current status.

---

## T14 — Content pass: four lures (human-in-the-loop)

**Goal:** Six lures total, co-authored and reviewed.

**Tasks**

- Agent provides the authoring guide and two worked examples (T6).
- Agent prepared `docs/lure-worksheet.md`; user fills it in with four lures: HR policy update, CEO gift-card request, shared document, delivery notification.
- Agent reviews for realism, safety, and consistency.
- Add the lures to fixtures or seed data.
- Update `docs/social-engineering.md` with the final set.

**Acceptance criteria**

- Six lures exist.
- Each declares principles, difficulty, sender, subject, body, CTA, and red flags.
- No real brands, logos, or domains.
- No credential capture or attachments.
- Review notes are addressed.

**Note:** Human task; the agent provides structure and review.

---

## T15 — Demo video & screenshots (human-in-the-loop)

**Goal:** A recorded walkthrough and README visuals.

**Tasks**

- Agent writes the script and storyboard (T13).
- User records a 3–5 minute walkthrough.
- User captures screenshots: dashboard, campaign detail, inbox, education page, lure library.
- Agent embeds the video link and screenshots in the README.

**Acceptance criteria**

- Video link works and covers the five-minute flow.
- Screenshots are present and legible.
- README is polished.

**Note:** Human task; the agent provides the script and layout.

---

## T16 — Final QA & release

**Goal:** Ship v0.1.0.

**Tasks**

- Run `make test`, `make lint`, `pip-audit`, `python manage.py check`.
- Verify the demo flow end-to-end.
- Verify the Mailpit path.
- Verify the seeded data and sample URLs.
- Update `AGENTS.md` with the final status.
- Tag `v0.1.0`.

**Acceptance criteria**

- All checks pass.
- The demo works from a clean checkout.
- The repo is public-ready with a responsible-use notice.
- `AGENTS.md` is current.

---

## Handoff notes

- The spec is the source of truth. If a ticket and the spec disagree, stop and resolve the spec first.
- Update the status table and `AGENTS.md` when a ticket moves to `in_progress` or `done`.
- Keep the safety invariants in `AGENTS.md` visible at all times.
- Do not add Docker, external SMTP, credential capture, real-brand impersonation, attachments, or runtime LLM calls without an explicit decision from the owner.
- Prefer small commits scoped to one ticket; reference the ticket ID in the commit message.
- If the build is interrupted, the next agent should read `docs/spec.md`, `docs/tickets.md`, and `AGENTS.md`, then resume at the first `todo` ticket whose blockers are `done`.
