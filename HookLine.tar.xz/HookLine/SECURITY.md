# Security policy

## Responsible use

Hookline is a security-awareness training tool. Use it only with written
authorization from the organization being tested. It never captures
credentials, renders fake login pages, uses real brands or domains, or sends
external email by default. Do not use it to impersonate real services or to
target people without approval.

## Reporting a vulnerability

If you find a security issue, please open a private report with the repository
owner rather than filing a public issue. Include:

- a short description and impact,
- the affected version or commit,
- reproduction steps, and
- a suggested fix if you have one.

Please give the maintainer a reasonable window to respond before disclosing
publicly. Do not include real personal data in your report.

## Production note

This is a portfolio/demo artifact. Before any real deployment, review
[the threat model](docs/threat-model.md), run
`python manage.py check --deploy`, disable debug mode, set a strong secret key,
enable HTTPS and secure cookies, and obtain appropriate legal and organizational
approval.
