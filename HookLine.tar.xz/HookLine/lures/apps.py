from django.apps import AppConfig


class LuresConfig(AppConfig):
    name = "lures"
