"""Admin registration for lures."""

from django.contrib import admin

from .models import LureTemplate


@admin.register(LureTemplate)
class LureTemplateAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "difficulty",
        "sender_name",
        "subject",
        "is_active",
    )
    list_filter = ("difficulty", "is_active")
    search_fields = ("name", "subject", "sender_name", "sender_email")
