"""Sanitisation and rendering for lure bodies.

Lure HTML is untrusted author input. It is sanitised before storage and again
after Django template rendering, so neither stored markup nor substituted
context can introduce scripts, event handlers, styles, or external assets.
"""

from __future__ import annotations

import re

import nh3
from django.template import Context, Template

ALLOWED_TAGS = {
    "a",
    "br",
    "div",
    "em",
    "h1",
    "h2",
    "h3",
    "img",
    "li",
    "ol",
    "p",
    "span",
    "strong",
    "table",
    "tbody",
    "td",
    "th",
    "thead",
    "tr",
    "u",
    "ul",
}

ALLOWED_ATTRIBUTES = {
    "*": {"class", "title"},
    "a": {"href"},
    "img": {"alt", "height", "src", "width"},
}

ALLOWED_URL_SCHEMES = {"http", "https", "mailto", "data"}

FIXED_CONTEXT_KEYS = {
    "first_name",
    "last_name",
    "full_name",
    "email",
    "department",
    "company_name",
    "cta_url",
    "cta_text",
}

SAMPLE_CONTEXT = {
    "first_name": "Alex",
    "last_name": "Chen",
    "full_name": "Alex Chen",
    "email": "alex.chen@northwind.example",
    "department": "Finance",
    "company_name": "Northwind Logistics",
    "cta_url": "#preview",
    "cta_text": "Review invoice",
}

_IMG_TAG = re.compile(r"<img\b[^>]*>", re.IGNORECASE)
_SRC_ATTRIBUTE = re.compile(r"""\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))""", re.IGNORECASE)


def _is_allowed_image_source(value: str) -> bool:
    lowered = value.strip().lower()
    return lowered.startswith("/static/") or lowered.startswith("data:")


def _attribute_filter(tag: str, attribute: str, value: str) -> str | None:
    if tag == "a" and attribute == "href":
        lowered = value.strip().lower()
        if lowered.startswith(("javascript:", "vbscript:", "data:")):
            return None
    if tag == "img" and attribute == "src" and not _is_allowed_image_source(value):
        return None
    return value


def _drop_images_without_src(html: str) -> str:
    """Remove images whose src was stripped, so no broken remote requests remain."""

    def replace(match: re.Match[str]) -> str:
        if _SRC_ATTRIBUTE.search(match.group(0)):
            return match.group(0)
        return ""

    return _IMG_TAG.sub(replace, html)


def sanitize_html(html: str) -> str:
    """Return the allowlisted subset of an HTML fragment."""
    cleaned = nh3.clean(
        html or "",
        tags=ALLOWED_TAGS,
        attributes=ALLOWED_ATTRIBUTES,
        url_schemes=ALLOWED_URL_SCHEMES,
        attribute_filter=_attribute_filter,
        link_rel="noopener noreferrer",
        clean_content_tags={"script", "style"},
        strip_comments=True,
    )
    return _drop_images_without_src(cleaned)


def render_lure(body_html: str, context: dict | None = None) -> str:
    """Render a lure with the fixed recipient context, then sanitise the result.

    Only keys in ``FIXED_CONTEXT_KEYS`` are accepted, so callers cannot pass
    arbitrary objects into the template. ``TemplateSyntaxError`` is left for the
    caller to report.
    """
    values = dict(SAMPLE_CONTEXT)
    if context:
        values.update({key: value for key, value in context.items() if key in FIXED_CONTEXT_KEYS})

    rendered = Template(body_html or "").render(Context(values, autoescape=True))
    return sanitize_html(rendered)
