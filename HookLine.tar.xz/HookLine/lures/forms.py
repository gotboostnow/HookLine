"""Forms for the lure library."""

import re

from django import forms
from django.template import Template, TemplateSyntaxError

from core.models import Organization

from .models import LureTemplate

CTA_PLACEHOLDER = re.compile(r"{{\s*cta_url\s*}}")


class LureTemplateForm(forms.ModelForm):
    principles = forms.MultipleChoiceField(
        choices=LureTemplate.Principle.choices,
        widget=forms.CheckboxSelectMultiple(attrs={"class": "checkbox-grid"}),
        help_text=(
            "Choose every lever the message uses. The education page explains "
            "each one to the recipient."
        ),
    )
    red_flags_text = forms.CharField(
        label="Red flags",
        widget=forms.Textarea(attrs={"rows": 5}),
        help_text=(
            "One plain-language red flag per line. These appear on the recipient's education page."
        ),
    )

    class Meta:
        model = LureTemplate
        fields = [
            "name",
            "description",
            "principles",
            "difficulty",
            "sender_name",
            "sender_email",
            "subject",
            "body_html",
            "cta_text",
            "is_active",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
            "body_html": forms.Textarea(
                attrs={
                    "rows": 16,
                    "class": "code-input",
                    "aria-describedby": "body-html-help",
                }
            ),
        }
        help_texts = {
            "name": "A short internal name. Recipients never see it.",
            "sender_name": "The display name in the simulated inbox.",
            "sender_email": "Must use a reserved .example domain.",
            "subject": "The line recipients see before opening the message.",
            "body_html": (
                "Put {{ cta_url }} in the link's href here, e.g. "
                '<a href="{{ cta_url }}">{{ cta_text }}</a>. Hookline replaces it '
                "with the recipient's private tracking URL. Allowed tags: p, br, "
                "strong, em, u, ul, ol, li, h1–h3, a, div, span, table, img. No "
                "styles, scripts, forms, or external images."
            ),
            "cta_text": (
                "Just the button label, e.g. 'Review invoice'. The tracked URL "
                "goes in the Body HTML field as {{ cta_url }}."
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        instance = self.instance
        if instance and instance.pk:
            self.fields["red_flags_text"].initial = "\n".join(instance.red_flags or [])

    def clean_body_html(self):
        body_html = self.cleaned_data["body_html"]

        try:
            Template(body_html)
        except TemplateSyntaxError as error:
            raise forms.ValidationError(f"The body has a template syntax error: {error}") from error

        if not CTA_PLACEHOLDER.search(body_html):
            raise forms.ValidationError(
                "Add {{ cta_url }} to the Body HTML field (inside the link's href), "
                "not to the Cta text field."
            )
        return body_html

    def clean_red_flags_text(self):
        flags = [
            line.strip()
            for line in self.cleaned_data["red_flags_text"].splitlines()
            if line.strip()
        ]
        if not flags:
            raise forms.ValidationError("Add at least one red flag.")
        if any(len(flag) > 500 for flag in flags):
            raise forms.ValidationError("Keep each red flag under 500 characters.")
        return flags

    def _post_clean(self):
        # The model stores a list, while the form edits one flag per line.
        if "red_flags_text" in self.cleaned_data:
            self.instance.red_flags = self.cleaned_data["red_flags_text"]
        super()._post_clean()

    def clean_name(self):
        name = self.cleaned_data["name"].strip()
        duplicates = LureTemplate.objects.filter(organization=Organization.load(), name=name)
        if self.instance.pk:
            duplicates = duplicates.exclude(pk=self.instance.pk)
        if duplicates.exists():
            raise forms.ValidationError("A lure with this name already exists.")
        return name
