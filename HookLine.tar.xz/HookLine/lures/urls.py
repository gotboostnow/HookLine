from django.urls import path

from . import views

app_name = "lures"

urlpatterns = [
    path("", views.LureListView.as_view(), name="list"),
    path("add/", views.LureCreateView.as_view(), name="create"),
    path("preview/", views.LurePreviewView.as_view(), name="preview"),
    path("guide/", views.LureGuideView.as_view(), name="guide"),
    path("<int:pk>/edit/", views.LureUpdateView.as_view(), name="edit"),
    path("<int:pk>/toggle/", views.LureToggleActiveView.as_view(), name="toggle"),
]
