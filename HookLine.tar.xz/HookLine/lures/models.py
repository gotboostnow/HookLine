"""Phishing lure templates."""

from django.core.exceptions import ValidationError
from django.db import models

from core.models import Organization

from .principles import details_for
from .sanitizer import sanitize_html


class LureTemplate(models.Model):
    """A parameterized phishing email used in simulations."""

    class Principle(models.TextChoices):
        AUTHORITY = "authority", "Authority"
        URGENCY = "urgency", "Urgency"
        FEAR = "fear", "Fear"
        CURIOSITY = "curiosity", "Curiosity"
        SOCIAL_PROOF = "social_proof", "Social proof"
        RECIPROCITY = "reciprocity", "Reciprocity"
        GREED = "greed", "Greed"
        TRUST = "trust", "Trust"

    class Difficulty(models.TextChoices):
        EASY = "easy", "Easy"
        MEDIUM = "medium", "Medium"
        HARD = "hard", "Hard"

    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="lures")
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    principles = models.JSONField(default=list)
    difficulty = models.CharField(
        max_length=20, choices=Difficulty.choices, default=Difficulty.MEDIUM
    )
    sender_name = models.CharField(max_length=150)
    sender_email = models.EmailField()
    subject = models.CharField(max_length=255)
    body_html = models.TextField()
    cta_text = models.CharField(max_length=100)
    red_flags = models.JSONField(default=list)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name

    def clean(self):
        super().clean()

        principles = self.principles or []
        if not isinstance(principles, list) or not principles:
            raise ValidationError(
                {"principles": "Choose at least one social-engineering principle."}
            )
        if not all(isinstance(key, str) for key in principles):
            raise ValidationError({"principles": "Principles must be a list of keys."})

        unknown = sorted(set(principles) - set(self.Principle.values))
        if unknown:
            raise ValidationError({"principles": f"Unknown principle(s): {', '.join(unknown)}."})

        red_flags = self.red_flags or []
        if not isinstance(red_flags, list) or not all(isinstance(flag, str) for flag in red_flags):
            raise ValidationError("Red flags must be a list of strings.")
        if not red_flags:
            raise ValidationError("Add at least one red flag for the education page.")

        sender_domain = self.sender_email.rsplit("@", 1)[-1].lower()
        if not sender_domain.endswith(".example"):
            raise ValidationError(
                {
                    "sender_email": (
                        "Sender addresses must use a reserved .example domain. "
                        "Never impersonate a real brand or domain."
                    )
                }
            )

    @property
    def principle_labels(self) -> list[str]:
        return [detail["label"] for detail in self.principle_details]

    @property
    def principle_details(self) -> list[dict[str, str]]:
        return details_for(self.principles or [])

    def save(self, *args, **kwargs):
        self.body_html = sanitize_html(self.body_html)
        super().save(*args, **kwargs)
