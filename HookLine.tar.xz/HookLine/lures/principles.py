"""Social-engineering principle vocabulary shared by authoring and education."""

PRINCIPLES = {
    "authority": {
        "label": "Authority",
        "exploit": "People comply with perceived authority.",
        "lesson": "Verify the request through a known channel before acting.",
    },
    "urgency": {
        "label": "Urgency",
        "exploit": "Time pressure short-circuits verification.",
        "lesson": "Slow down. Urgency is a common pressure tactic.",
    },
    "fear": {
        "label": "Fear",
        "exploit": "The threat of loss or consequences pushes quick action.",
        "lesson": "Check the claim independently before reacting.",
    },
    "curiosity": {
        "label": "Curiosity",
        "exploit": "An information gap demands closure.",
        "lesson": "Hover the link and confirm the sender before opening it.",
    },
    "social_proof": {
        "label": "Social proof",
        "exploit": "“Everyone else already did this” feels safe.",
        "lesson": "Popularity is not proof of legitimacy.",
    },
    "reciprocity": {
        "label": "Reciprocity",
        "exploit": "A small favor creates a sense of obligation.",
        "lesson": "Check what is being asked in return.",
    },
    "greed": {
        "label": "Greed",
        "exploit": "An unexpected benefit or reward lowers scrutiny.",
        "lesson": "Be skeptical of unexpected money or prizes.",
    },
    "trust": {
        "label": "Trust",
        "exploit": "Familiarity, routine, and known names feel safe.",
        "lesson": "Look at the address, not just the display name.",
    },
}


def details_for(keys: list[str]) -> list[dict[str, str]]:
    """Return label, exploit, and lesson for each principle key."""
    details = []
    for key in keys or []:
        entry = PRINCIPLES.get(key)
        if entry is None:
            details.append(
                {
                    "key": key,
                    "label": key.replace("_", " ").title(),
                    "exploit": "",
                    "lesson": "",
                }
            )
        else:
            details.append({"key": key, **entry})
    return details
