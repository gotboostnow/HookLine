"""Views for the lure library."""

from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.template import TemplateSyntaxError
from django.urls import reverse
from django.views import View
from django.views.generic import CreateView, ListView, TemplateView, UpdateView

from core.mixins import StaffRequiredMixin
from core.models import Organization

from .forms import LureTemplateForm
from .models import LureTemplate
from .sanitizer import render_lure


def build_preview(lure: LureTemplate | None, data: dict | None = None) -> dict:
    """Render a lure preview from a model instance or raw form data."""
    source = data or {}
    body_html = source.get("body_html", lure.body_html if lure else "")
    cta_text = source.get("cta_text", lure.cta_text if lure else "Review invoice")
    sender_name = source.get("sender_name", lure.sender_name if lure else "Northwind Accounts")
    sender_email = source.get(
        "sender_email", lure.sender_email if lure else "accounts@northwind.example"
    )
    subject = source.get("subject", lure.subject if lure else "Invoice awaiting review")

    rendered_body = ""
    preview_error = ""
    if body_html.strip():
        try:
            rendered_body = render_lure(
                body_html,
                {
                    "company_name": Organization.load().name,
                    "cta_text": cta_text or "Review invoice",
                },
            )
        except TemplateSyntaxError as error:
            preview_error = f"Template syntax error: {error}"

    return {
        "rendered_body": rendered_body,
        "preview_error": preview_error,
        "preview_sender_name": sender_name or "Northwind Accounts",
        "preview_sender_email": sender_email or "accounts@northwind.example",
        "preview_subject": subject or "Invoice awaiting review",
        "company_name": Organization.load().name,
    }


class LureListView(StaffRequiredMixin, ListView):
    model = LureTemplate
    template_name = "lures/list.html"
    context_object_name = "lures"

    def get_queryset(self):
        queryset = LureTemplate.objects.filter(organization=Organization.load())
        status = self.request.GET.get("status", "").strip()
        if status == "active":
            queryset = queryset.filter(is_active=True)
        elif status == "inactive":
            queryset = queryset.filter(is_active=False)
        return queryset.order_by("name")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        all_lures = LureTemplate.objects.filter(organization=Organization.load())
        context.update(
            {
                "total_count": all_lures.count(),
                "active_count": all_lures.filter(is_active=True).count(),
                "selected_status": self.request.GET.get("status", "").strip(),
            }
        )
        return context


class LureCreateView(StaffRequiredMixin, CreateView):
    model = LureTemplate
    form_class = LureTemplateForm
    template_name = "lures/form.html"
    extra_context = {"page_title": "New lure"}

    def form_valid(self, form):
        form.instance.organization = Organization.load()
        response = super().form_valid(form)
        messages.success(self.request, f"Created lure {self.object.name}.")
        return response

    def get_success_url(self):
        return reverse("lures:list")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(build_preview(None))
        return context


class LureUpdateView(StaffRequiredMixin, UpdateView):
    model = LureTemplate
    form_class = LureTemplateForm
    template_name = "lures/form.html"
    extra_context = {"page_title": "Edit lure"}

    def get_queryset(self):
        return LureTemplate.objects.filter(organization=Organization.load())

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, f"Saved lure {self.object.name}.")
        return response

    def get_success_url(self):
        return reverse("lures:list")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(build_preview(self.object))
        return context


class LurePreviewView(StaffRequiredMixin, View):
    """Return a sanitised preview for the live form panel."""

    def post(self, request):
        return render(request, "lures/_preview.html", build_preview(None, request.POST))


class LureToggleActiveView(StaffRequiredMixin, View):
    def post(self, request, pk):
        lure = get_object_or_404(LureTemplate, pk=pk, organization=Organization.load())
        lure.is_active = not lure.is_active
        lure.save(update_fields=["is_active", "updated_at"])
        state = "active" if lure.is_active else "inactive"
        messages.success(request, f"{lure.name} is now {state}.")
        return redirect("lures:list")


class LureGuideView(StaffRequiredMixin, TemplateView):
    template_name = "lures/guide.html"
    extra_context = {
        "cta_url_placeholder": "{{ cta_url }}",
        "cta_text_placeholder": "{{ cta_text }}",
        "first_name_placeholder": "{{ first_name }}",
        "last_name_placeholder": "{{ last_name }}",
        "full_name_placeholder": "{{ full_name }}",
        "email_placeholder": "{{ email }}",
        "department_placeholder": "{{ department }}",
        "company_name_placeholder": "{{ company_name }}",
    }
