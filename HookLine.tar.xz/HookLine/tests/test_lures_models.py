"""Tests for lure templates."""

import pytest
from django.core.exceptions import ValidationError

from tests.factories import LureTemplateFactory

pytestmark = pytest.mark.django_db


def test_principle_labels():
    lure = LureTemplateFactory(principles=["authority", "urgency"])

    assert lure.principle_labels == ["Authority", "Urgency"]


def test_clean_accepts_a_valid_lure():
    lure = LureTemplateFactory()

    lure.full_clean()


def test_clean_requires_at_least_one_principle():
    lure = LureTemplateFactory(principles=[])

    with pytest.raises(ValidationError) as error:
        lure.full_clean()

    assert "principles" in error.value.message_dict


def test_clean_rejects_unknown_principles():
    lure = LureTemplateFactory(principles=["authority", "mind_control"])

    with pytest.raises(ValidationError) as error:
        lure.full_clean()

    assert "mind_control" in error.value.message_dict["principles"][0]


def test_clean_requires_a_reserved_sender_domain():
    lure = LureTemplateFactory(sender_email="billing@real-company.com")

    with pytest.raises(ValidationError) as error:
        lure.full_clean()

    assert "sender_email" in error.value.message_dict
