"""Tests for targets and groups."""

import pytest
from django.db import IntegrityError

from tests.factories import GroupFactory, TargetFactory

pytestmark = pytest.mark.django_db


def test_full_name():
    target = TargetFactory(first_name="Alex", last_name="Chen")

    assert target.full_name == "Alex Chen"


def test_email_is_normalized_on_save():
    target = TargetFactory(email="Alex.Chen@Northwind.EXAMPLE")

    assert target.email == "alex.chen@northwind.example"


def test_email_is_unique_per_organization():
    TargetFactory(email="alex@northwind.example")

    with pytest.raises(IntegrityError):
        TargetFactory(email="alex@northwind.example")


def test_mark_excluded_and_included():
    target = TargetFactory()

    target.mark_excluded("On parental leave")
    target.refresh_from_db()

    assert target.is_excluded is True
    assert target.exclusion_reason == "On parental leave"

    target.mark_included()
    target.refresh_from_db()

    assert target.is_excluded is False
    assert target.exclusion_reason == ""


def test_group_membership():
    group = GroupFactory()
    target = TargetFactory()

    group.targets.add(target)

    assert list(group.targets.all()) == [target]
