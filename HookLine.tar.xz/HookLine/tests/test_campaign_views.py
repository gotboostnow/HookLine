"""Tests for campaign drafts, recipient selection, and authorization."""

import pytest
from django.urls import reverse

from campaigns.models import Campaign
from tests.factories import (
    CampaignFactory,
    CampaignRecipientFactory,
    LureTemplateFactory,
    OrganizationFactory,
    TargetFactory,
    UserFactory,
)

pytestmark = pytest.mark.django_db


def login(client):
    user = UserFactory()
    client.force_login(user)
    return user


def payload(lure, targets, **overrides):
    data = {
        "name": "Q4 Invoice Review",
        "lure": lure.pk,
        "reporting_mode": Campaign.ReportingMode.AGGREGATE,
        "authorized_by": "Dana Ruiz, IT Manager",
        "authorization_scope": "All staff, Q4 2026 awareness exercise.",
        "authorization_acknowledged": "on",
        "targets": [target.pk for target in targets],
    }
    data.update(overrides)
    return data


def test_list_shows_campaigns_and_filters_by_status(client):
    OrganizationFactory()
    login(client)
    CampaignFactory(name="Draft campaign", status=Campaign.Status.DRAFT)
    CampaignFactory(name="Active campaign", status=Campaign.Status.ACTIVE)
    CampaignFactory(name="Closed campaign", status=Campaign.Status.CLOSED)

    response = client.get(reverse("campaigns:list"))
    content = response.content.decode()
    assert "Draft campaign" in content
    assert "Active campaign" in content
    assert "Closed campaign" in content

    response = client.get(reverse("campaigns:list"), {"status": "draft"})
    content = response.content.decode()
    assert "Draft campaign" in content
    assert "Active campaign" not in content
    assert "Closed campaign" not in content


def test_list_htmx_returns_the_panel_without_a_page(client):
    OrganizationFactory()
    login(client)
    CampaignFactory(name="Draft campaign")

    response = client.get(reverse("campaigns:list"), {"status": "draft"}, HTTP_HX_REQUEST="true")
    content = response.content.decode()

    assert response.status_code == 200
    assert "<!doctype html>" not in content
    assert 'id="campaign-panel"' in content
    assert "Draft campaign" in content


def test_create_campaign_with_recipients_and_authorization(client):
    organization = OrganizationFactory()
    user = login(client)
    lure = LureTemplateFactory()
    targets = [TargetFactory(), TargetFactory()]

    response = client.post(reverse("campaigns:create"), payload(lure, targets))

    assert response.status_code == 302
    campaign = Campaign.objects.get(name="Q4 Invoice Review")
    assert campaign.organization == organization
    assert campaign.created_by == user
    assert campaign.status == Campaign.Status.DRAFT
    assert campaign.authorization_complete is True
    assert campaign.authorized_at is not None
    assert campaign.recipients.count() == 2

    tokens = list(campaign.recipients.values_list("token", flat=True))
    assert all(tokens)
    assert len(set(tokens)) == 2


def test_create_campaign_requires_a_name_and_lure(client):
    OrganizationFactory()
    login(client)
    lure = LureTemplateFactory()
    target = TargetFactory()

    response = client.post(
        reverse("campaigns:create"),
        payload(lure, [target], name="") | {"lure": ""},
    )

    assert response.status_code == 200
    assert "This field is required." in response.content.decode()
    assert Campaign.objects.count() == 0


def test_create_campaign_requires_a_recipient(client):
    OrganizationFactory()
    login(client)
    lure = LureTemplateFactory()

    response = client.post(reverse("campaigns:create"), payload(lure, []))

    assert response.status_code == 200
    assert "Select at least one recipient." in response.content.decode()
    assert Campaign.objects.count() == 0


def test_create_campaign_rejects_excluded_targets(client):
    OrganizationFactory()
    login(client)
    lure = LureTemplateFactory()
    excluded = TargetFactory(is_excluded=True, exclusion_reason="On parental leave")

    response = client.post(reverse("campaigns:create"), payload(lure, [excluded]))

    assert response.status_code == 200
    assert "Excluded targets cannot be added" in response.content.decode()
    assert Campaign.objects.count() == 0


def test_create_campaign_without_acknowledgment_is_blocked_but_saved(client):
    OrganizationFactory()
    login(client)
    lure = LureTemplateFactory()
    target = TargetFactory()

    response = client.post(
        reverse("campaigns:create"),
        payload(
            lure,
            [target],
            authorization_acknowledged="",
            authorized_by="",
            authorization_scope="",
        ),
    )

    assert response.status_code == 302
    campaign = Campaign.objects.get(name="Q4 Invoice Review")
    assert campaign.authorized_at is None
    assert "Acknowledge the authorization before launching." in campaign.launch_blockers()


def test_edit_draft_syncs_recipients_and_preserves_tokens(client):
    OrganizationFactory()
    login(client)
    campaign = CampaignFactory(name="Old name")
    kept_target = TargetFactory()
    removed_target = TargetFactory()
    new_target = TargetFactory()
    kept = CampaignRecipientFactory(campaign=campaign, target=kept_target)
    CampaignRecipientFactory(campaign=campaign, target=removed_target)

    response = client.post(
        reverse("campaigns:edit", args=[campaign.pk]),
        payload(
            campaign.lure,
            [kept_target, new_target],
            name="New name",
        ),
    )

    assert response.status_code == 302
    campaign.refresh_from_db()
    assert campaign.name == "New name"
    assert set(campaign.recipients.values_list("target_id", flat=True)) == {
        kept_target.pk,
        new_target.pk,
    }
    kept.refresh_from_db()
    assert kept.token
    assert campaign.recipients.get(target=new_target).token


def test_non_draft_campaigns_cannot_be_edited(client):
    OrganizationFactory()
    login(client)
    campaign = CampaignFactory(status=Campaign.Status.ACTIVE)

    response = client.get(reverse("campaigns:edit", args=[campaign.pk]))

    assert response.status_code == 404


def test_editing_authorization_sets_and_clears_authorized_at(client):
    OrganizationFactory()
    login(client)
    campaign = CampaignFactory(
        authorized_by="",
        authorization_scope="",
        authorization_acknowledged=False,
    )
    target = TargetFactory()
    CampaignRecipientFactory(campaign=campaign, target=target)

    client.post(
        reverse("campaigns:edit", args=[campaign.pk]),
        payload(campaign.lure, [target]),
    )
    campaign.refresh_from_db()
    assert campaign.authorized_at is not None

    client.post(
        reverse("campaigns:edit", args=[campaign.pk]),
        payload(
            campaign.lure,
            [target],
            authorization_acknowledged="",
        ),
    )
    campaign.refresh_from_db()
    assert campaign.authorized_at is None


def test_picker_disables_excluded_targets_and_marks_selected(client):
    OrganizationFactory()
    login(client)
    campaign = CampaignFactory()
    selected = TargetFactory(first_name="Alex", last_name="Chen")
    excluded = TargetFactory(
        first_name="Priya",
        last_name="Patel",
        email="priya@northwind.example",
        is_excluded=True,
        exclusion_reason="Legal hold",
    )
    CampaignRecipientFactory(campaign=campaign, target=selected)

    response = client.get(reverse("campaigns:edit", args=[campaign.pk]))
    content = response.content.decode()

    assert "Legal hold" in content
    assert "Excluded" in content
    assert f'value="{excluded.pk}"' in content
    assert f'value="{selected.pk}"' in content
    assert "checked" in content
    assert "data-picker-search" in content
    assert "data-picker-select-all" in content


def test_edit_page_lists_launch_blockers(client):
    OrganizationFactory()
    login(client)
    campaign = CampaignFactory(
        authorized_by="",
        authorization_scope="",
        authorization_acknowledged=False,
    )

    response = client.get(reverse("campaigns:edit", args=[campaign.pk]))
    content = response.content.decode()

    assert "Add at least one recipient." in content
    assert "Record who authorized this campaign." in content
    assert "Acknowledge the authorization before launching." in content


def test_create_page_renders_the_picker(client):
    OrganizationFactory()
    login(client)
    LureTemplateFactory(name="Invoice lure")
    target = TargetFactory(first_name="Alex", last_name="Chen")

    response = client.get(reverse("campaigns:create"))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Invoice lure" in content
    assert "Alex Chen" in content
    assert f'value="{target.pk}"' in content
    assert "Select all visible" in content


def test_create_requires_staff_login(client):
    response = client.get(reverse("campaigns:create"))

    assert response.status_code == 302
    assert response.url.startswith(reverse("login"))


def test_edit_rejects_signed_in_non_staff(client):
    OrganizationFactory()
    campaign = CampaignFactory()
    user = UserFactory(is_staff=False)
    client.force_login(user)

    response = client.get(reverse("campaigns:edit", args=[campaign.pk]))

    assert response.status_code == 403
