"""Tests for campaigns and campaign recipients."""

import re

import pytest
from django.db import IntegrityError

from campaigns.models import Campaign
from campaigns.tokens import generate_token
from tests.factories import (
    CampaignFactory,
    CampaignRecipientFactory,
    LureTemplateFactory,
    TargetFactory,
)

pytestmark = pytest.mark.django_db


def test_token_generation_is_urlsafe_and_long():
    token = generate_token()

    assert len(token) >= 43
    assert re.fullmatch(r"[A-Za-z0-9_-]+", token)
    assert generate_token() != token


def test_recipient_token_is_generated_on_save():
    recipient = CampaignRecipientFactory()

    assert len(recipient.token) >= 43


def test_recipient_tokens_are_unique():
    first = CampaignRecipientFactory()
    second = CampaignRecipientFactory()

    assert first.token != second.token


def test_explicit_recipient_token_is_preserved():
    recipient = CampaignRecipientFactory(token="fixed-token")

    assert recipient.token == "fixed-token"


def test_target_cannot_appear_twice_in_a_campaign():
    first = CampaignRecipientFactory()

    with pytest.raises(IntegrityError):
        CampaignRecipientFactory(campaign=first.campaign, target=first.target)


def test_campaign_defaults():
    campaign = CampaignFactory()

    assert campaign.status == Campaign.Status.DRAFT
    assert campaign.reporting_mode == Campaign.ReportingMode.AGGREGATE
    assert campaign.is_editable is True


def test_valid_campaign_can_launch():
    campaign = CampaignFactory()
    CampaignRecipientFactory(campaign=campaign)

    assert campaign.launch_blockers() == []
    assert campaign.can_launch is True


def test_launch_blockers_report_missing_authorization_and_recipients():
    campaign = CampaignFactory(
        authorized_by="",
        authorization_scope="",
        authorization_acknowledged=False,
    )

    blockers = campaign.launch_blockers()

    assert "Add at least one recipient." in blockers
    assert "Record who authorized this campaign." in blockers
    assert "Describe the authorization scope." in blockers
    assert "Acknowledge the authorization before launching." in blockers


def test_inactive_lure_blocks_launch():
    lure = LureTemplateFactory(is_active=False)
    campaign = CampaignFactory(lure=lure)
    CampaignRecipientFactory(campaign=campaign)

    assert "The selected lure is inactive." in campaign.launch_blockers()


def test_excluded_target_blocks_launch():
    target = TargetFactory(is_excluded=True, exclusion_reason="Legal hold")
    campaign = CampaignFactory()
    CampaignRecipientFactory(campaign=campaign, target=target)

    assert "Remove excluded targets before launching." in campaign.launch_blockers()


def test_launched_campaign_is_not_editable():
    campaign = CampaignFactory(status=Campaign.Status.ACTIVE)

    assert campaign.is_editable is False
    assert "Only draft campaigns can be launched." in campaign.launch_blockers()
