"""Tests for dashboard KPIs, campaign metrics, and privacy-aware reporting."""

import re

import pytest
from django.urls import reverse
from django.utils import timezone

from campaigns.models import Campaign
from campaigns.reporting import (
    campaign_metrics,
    dashboard_stats,
    department_breakdown,
    event_timeline,
)
from tests.factories import (
    CampaignFactory,
    CampaignRecipientFactory,
    OrganizationFactory,
    TargetFactory,
    TrackingEventFactory,
    UserFactory,
)
from tracking.models import TrackingEvent

pytestmark = pytest.mark.django_db


def make_campaign(
    status=Campaign.Status.ACTIVE,
    reporting_mode=Campaign.ReportingMode.AGGREGATE,
    clicked=0,
    reported=0,
    departments=None,
    name=None,
):
    OrganizationFactory()
    campaign = CampaignFactory(
        status=status,
        reporting_mode=reporting_mode,
        launched_at=timezone.now() if status != Campaign.Status.DRAFT else None,
        **({"name": name} if name else {}),
    )
    now = timezone.now()
    departments = departments or ["Finance", "Finance", "Operations"]
    recipients = []
    for index, department in enumerate(departments):
        target = TargetFactory(
            first_name="Priya",
            last_name="Patel",
            department=department,
        )
        fields = {}
        if status != Campaign.Status.DRAFT:
            fields["sent_at"] = now
            if index < clicked:
                fields["clicked_at"] = now
            if index < reported:
                fields["reported_at"] = now
        recipient = CampaignRecipientFactory(campaign=campaign, target=target, **fields)
        if index < clicked and status != Campaign.Status.DRAFT:
            TrackingEventFactory(recipient=recipient, event_type=TrackingEvent.EventType.CLICK)
        if index < reported and status != Campaign.Status.DRAFT:
            TrackingEventFactory(recipient=recipient, event_type=TrackingEvent.EventType.REPORT)
        recipients.append(recipient)
    return campaign, recipients


def login(client):
    client.force_login(UserFactory())


def test_campaign_metrics_count_unique_clicks_and_reports():
    campaign, _ = make_campaign(clicked=2, reported=1)

    metrics = campaign_metrics(campaign)

    assert metrics["delivered"] == 3
    assert metrics["clicked"] == 2
    assert metrics["reported"] == 1
    assert metrics["click_rate"] == pytest.approx(2 / 3)
    assert metrics["report_rate"] == pytest.approx(1 / 3)


def test_campaign_metrics_are_zero_without_deliveries():
    campaign, _ = make_campaign(status=Campaign.Status.DRAFT)

    metrics = campaign_metrics(campaign)

    assert metrics["delivered"] == 0
    assert metrics["click_rate"] == 0
    assert metrics["report_rate"] == 0


def test_department_breakdown_groups_delivered_recipients():
    campaign, _ = make_campaign(
        clicked=2,
        reported=1,
        departments=["Finance", "Finance", "Operations"],
    )

    rows = {row["department"]: row for row in department_breakdown(campaign)}

    assert rows["Finance"]["delivered"] == 2
    assert rows["Finance"]["clicked"] == 2
    assert rows["Finance"]["report_rate"] == 0.5
    assert rows["Operations"]["delivered"] == 1
    assert rows["Operations"]["clicked"] == 0


def test_event_timeline_counts_events_by_day():
    campaign, recipients = make_campaign(clicked=1, reported=1)

    timeline = event_timeline(campaign)

    assert len(timeline) == 1
    assert timeline[0]["clicks"] == 1
    assert timeline[0]["reports"] == 1


def test_dashboard_stats_averages_rates_across_launched_campaigns():
    make_campaign(name="First", clicked=1, reported=0, departments=["A", "B"])
    make_campaign(name="Second", clicked=1, reported=1, departments=["A", "B"])

    stats = dashboard_stats()

    assert stats["campaign_count"] == 2
    assert stats["active_count"] == 2
    assert stats["target_count"] == 4
    assert stats["average_click_rate"] == pytest.approx(0.5)
    assert stats["average_report_rate"] == pytest.approx(0.25)


def test_dashboard_shows_kpis_and_campaign_table(client):
    campaign, _ = make_campaign(name="Quarterly check", clicked=2, reported=1)
    login(client)

    response = client.get(reverse("dashboard"))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Quarterly check" in content
    assert reverse("campaigns:detail", args=[campaign.pk]) in content
    assert "Average click rate" in content
    assert "67%" in content
    assert "33%" in content
    assert "No-blame reporting" in content


def test_dashboard_htmx_returns_only_the_campaign_panel(client):
    make_campaign(name="Quarterly check")
    login(client)

    response = client.get(reverse("dashboard"), HTTP_HX_REQUEST="true")
    content = response.content.decode()

    assert response.status_code == 200
    assert "<!doctype html>" not in content
    assert 'id="dashboard-campaigns"' in content
    assert "Quarterly check" in content


def test_dashboard_filters_and_paginates_campaigns(client):
    for index in range(12):
        make_campaign(
            status=Campaign.Status.DRAFT,
            name=f"Draft {index:02d}",
            clicked=0,
            reported=0,
        )
    make_campaign(name="Active campaign")
    login(client)

    response = client.get(reverse("dashboard"), {"status": "draft", "page": "2"})
    content = response.content.decode()

    assert response.status_code == 200
    assert "Page 2 of 2" in content
    assert len(re.findall(r"Draft \d{2}", content)) == 2
    assert "Active campaign" not in content


def test_dashboard_requires_staff_login(client):
    response = client.get(reverse("dashboard"))

    assert response.status_code == 302
    assert response.url.startswith(reverse("login"))


def test_dashboard_rejects_non_staff(client):
    client.force_login(UserFactory(is_staff=False))

    response = client.get(reverse("dashboard"))

    assert response.status_code == 403


def test_campaign_detail_shows_funnel_and_no_blame_banner(client):
    campaign, _ = make_campaign(name="Quarterly check", clicked=2, reported=1)
    login(client)

    response = client.get(reverse("campaigns:detail", args=[campaign.pk]))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Quarterly check" in content
    assert "No-blame reporting" in content
    assert "Department breakdown" in content
    assert "Activity timeline" in content
    assert "Event log" in content


def test_aggregate_detail_never_renders_recipient_names(client):
    campaign, _ = make_campaign(clicked=1, reported=1)

    login(client)
    response = client.get(reverse("campaigns:detail", args=[campaign.pk]))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Priya Patel" not in content
    assert "Names are hidden" in content
    assert "Click" in content
    assert "Report" in content


def test_named_detail_renders_names_and_timestamps(client):
    campaign, recipients = make_campaign(
        reporting_mode=Campaign.ReportingMode.NAMED,
        clicked=1,
        reported=1,
    )
    login(client)

    response = client.get(reverse("campaigns:detail", args=[campaign.pk]))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Priya Patel" in content
    assert recipients[0].target.email in content
    assert str(recipients[0].clicked_at.year) in content
    assert "Named reporting" in content


def test_campaign_detail_requires_staff_login(client):
    campaign, _ = make_campaign()

    response = client.get(reverse("campaigns:detail", args=[campaign.pk]))

    assert response.status_code == 302
    assert response.url.startswith(reverse("login"))


def test_campaign_list_shows_click_and_report_rates(client):
    make_campaign(name="Quarterly check", clicked=2, reported=1)
    login(client)

    response = client.get(reverse("campaigns:list"))
    content = response.content.decode()

    assert "67%" in content
    assert "33%" in content
