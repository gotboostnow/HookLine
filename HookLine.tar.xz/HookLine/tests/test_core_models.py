"""Tests for the organization singleton."""

import pytest

from core.models import Organization

pytestmark = pytest.mark.django_db


def test_load_creates_and_reuses_singleton():
    first = Organization.load()
    second = Organization.load()

    assert first.pk == 1
    assert second.pk == first.pk
    assert Organization.objects.count() == 1


def test_save_forces_a_single_row():
    organization = Organization.objects.create(
        pk=99,
        name="Another Organization",
        domain="another.example",
    )

    assert organization.pk == 1
    assert list(Organization.objects.values_list("pk", flat=True)) == [1]


def test_load_defaults_use_a_reserved_domain():
    organization = Organization.load()

    assert organization.domain.endswith(".example")
    assert organization.retention_days == 90
