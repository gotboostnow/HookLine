"""Tests for lure sanitisation, forms, preview, and the library."""

import pytest
from django.template import TemplateSyntaxError
from django.urls import reverse

from lures.models import LureTemplate
from lures.sanitizer import render_lure, sanitize_html
from tests.factories import LureTemplateFactory, OrganizationFactory, UserFactory

pytestmark = pytest.mark.django_db

VALID_LURE = {
    "name": "Supplier invoice overdue",
    "description": "A fictional supplier invoice.",
    "principles": ["authority", "urgency"],
    "difficulty": "medium",
    "sender_name": "Brightline Supplies Billing",
    "sender_email": "billing@brightline-supplies.example",
    "subject": "Invoice INV-4821 is due today",
    "body_html": (
        "<p>Hi {{ first_name }},</p>"
        "<p>Invoice <strong>INV-4821</strong> is due today.</p>"
        '<p><a class="email-cta" href="{{ cta_url }}">{{ cta_text }}</a></p>'
    ),
    "cta_text": "Review invoice",
    "red_flags_text": "The invoice is unexpected.\nThe sender domain is unfamiliar.",
    "is_active": "on",
}


def login(client):
    user = UserFactory()
    client.force_login(user)
    return user


# Sanitizer


def test_scripts_styles_and_event_handlers_are_removed():
    cleaned = sanitize_html(
        '<p onclick="alert(1)" style="color:red">Hello</p>'
        "<script>alert('xss')</script>"
        "<style>body{display:none}</style>"
    )

    assert cleaned == "<p>Hello</p>"


def test_iframes_and_forms_are_removed():
    cleaned = sanitize_html(
        '<iframe src="https://evil.example"></iframe>'
        '<form action="https://evil.example"><input name="password"></form>'
        "<p>Safe</p>"
    )

    assert "iframe" not in cleaned
    assert "form" not in cleaned
    assert "input" not in cleaned
    assert "evil.example" not in cleaned
    assert "<p>Safe</p>" in cleaned


def test_external_images_are_removed_and_local_images_kept():
    cleaned = sanitize_html(
        '<img src="https://evil.example/pixel.png" alt="tracker">'
        '<img src="/static/img/logo.png" alt="logo">'
        '<img src="data:image/png;base64,abc" alt="inline">'
    )

    assert "evil.example" not in cleaned
    assert 'src="/static/img/logo.png"' in cleaned
    assert 'src="data:image/png;base64,abc"' in cleaned
    assert cleaned.count("<img") == 2


def test_links_are_restricted_and_get_safe_rel():
    cleaned = sanitize_html(
        '<a href="javascript:alert(1)">bad</a><a href="https://northwind.example/help">good</a>'
    )

    assert "javascript:" not in cleaned
    assert 'href="https://northwind.example/help"' in cleaned
    assert 'rel="noopener noreferrer"' in cleaned


def test_allowed_formatting_and_classes_survive():
    cleaned = sanitize_html(
        '<p class="email-note"><strong>Bold</strong> <em>italic</em> '
        "<u>under</u></p><ul><li>One</li></ul>"
    )

    assert cleaned == (
        '<p class="email-note"><strong>Bold</strong> <em>italic</em> '
        "<u>under</u></p><ul><li>One</li></ul>"
    )


def test_render_lure_uses_context_and_escapes_it():
    rendered = render_lure(
        "<p>Hi {{ first_name }} {{ last_name }} in {{ department }}.</p>",
        {
            "first_name": "<script>alert(1)</script>",
            "last_name": "Chen",
            "department": "Finance",
        },
    )

    assert "<script>" not in rendered
    assert "&lt;script&gt;" in rendered
    assert "Chen in Finance" in rendered


def test_render_lure_ignores_unknown_context_keys():
    rendered = render_lure("<p>{{ secret }}</p>", {"secret": "leaked"})

    assert "leaked" not in rendered
    assert "<p></p>" in rendered


def test_render_lure_reports_template_syntax_errors():
    with pytest.raises(TemplateSyntaxError):
        render_lure("<p>{% if first_name %}</p>")


# Model


def test_saving_a_lure_sanitises_its_body():
    lure = LureTemplateFactory(body_html='<p onclick="alert(1)">Hi</p><script>alert(1)</script>')
    lure.refresh_from_db()

    assert "onclick" not in lure.body_html
    assert "script" not in lure.body_html
    assert "<p>Hi</p>" in lure.body_html


# Library views


def test_list_shows_cards_with_principles_and_status(client):
    OrganizationFactory()
    login(client)
    LureTemplateFactory(
        name="Invoice lure",
        principles=["authority"],
        difficulty="easy",
        sender_name="Brightline Billing",
        subject="Invoice due today",
    )
    LureTemplateFactory(name="Paused lure", is_active=False)

    response = client.get(reverse("lures:list"))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Invoice lure" in content
    assert "Authority" in content
    assert "Easy" in content
    assert "Brightline Billing" in content
    assert "Invoice due today" in content
    assert "Inactive" in content


def test_list_filters_by_active_status(client):
    OrganizationFactory()
    login(client)
    LureTemplateFactory(name="Active lure", is_active=True)
    LureTemplateFactory(name="Paused lure", is_active=False)

    response = client.get(reverse("lures:list"), {"status": "active"})
    content = response.content.decode()

    assert "Active lure" in content
    assert "Paused lure" not in content


def test_create_lure_stores_lists_and_sanitises(client):
    OrganizationFactory()
    login(client)

    response = client.post(reverse("lures:create"), VALID_LURE)

    assert response.status_code == 302
    lure = LureTemplate.objects.get(name="Supplier invoice overdue")
    assert lure.principles == ["authority", "urgency"]
    assert lure.red_flags == [
        "The invoice is unexpected.",
        "The sender domain is unfamiliar.",
    ]
    assert lure.is_active is True
    assert "onclick" not in lure.body_html


def test_create_lure_requires_a_cta_placeholder(client):
    OrganizationFactory()
    login(client)
    payload = dict(VALID_LURE)
    payload["body_html"] = "<p>No link here.</p>"

    response = client.post(reverse("lures:create"), payload)

    assert response.status_code == 200
    assert "Add {{ cta_url }}" in response.content.decode()
    assert LureTemplate.objects.count() == 0


def test_missing_cta_placeholder_error_points_to_the_body_field(client):
    OrganizationFactory()
    login(client)
    payload = dict(VALID_LURE)
    payload["body_html"] = "<p>No link here.</p>"
    payload["cta_text"] = "{{ cta_url }}"

    response = client.post(reverse("lures:create"), payload)

    content = response.content.decode()
    assert "Body HTML field" in content
    assert "Add {{ cta_url }}" in content
    assert LureTemplate.objects.count() == 0


def test_create_lure_reports_template_syntax_errors(client):
    OrganizationFactory()
    login(client)
    payload = dict(VALID_LURE)
    payload["body_html"] = '<p>{% if first_name %}</p><a href="{{ cta_url }}">x</a>'

    response = client.post(reverse("lures:create"), payload)

    assert response.status_code == 200
    assert "template syntax error" in response.content.decode().lower()
    assert LureTemplate.objects.count() == 0


def test_create_lure_rejects_non_example_sender_domains(client):
    OrganizationFactory()
    login(client)
    payload = dict(VALID_LURE)
    payload["sender_email"] = "billing@gmail.com"

    response = client.post(reverse("lures:create"), payload)

    assert response.status_code == 200
    assert ".example" in response.content.decode()
    assert LureTemplate.objects.count() == 0


def test_create_lure_requires_a_red_flag(client):
    OrganizationFactory()
    login(client)
    payload = dict(VALID_LURE)
    payload["red_flags_text"] = "  \n "

    response = client.post(reverse("lures:create"), payload)

    assert response.status_code == 200
    assert "at least one red flag" in response.content.decode()
    assert LureTemplate.objects.count() == 0


def test_edit_lure_updates_fields(client):
    OrganizationFactory()
    login(client)
    lure = LureTemplateFactory(
        body_html='<p><a href="{{ cta_url }}">Go</a></p>',
        red_flags=["One"],
    )
    payload = dict(VALID_LURE)
    payload["name"] = "Updated lure"
    payload["subject"] = "Updated subject"

    response = client.post(reverse("lures:edit", args=[lure.pk]), payload)

    assert response.status_code == 302
    lure.refresh_from_db()
    assert lure.name == "Updated lure"
    assert lure.subject == "Updated subject"
    assert lure.red_flags == [
        "The invoice is unexpected.",
        "The sender domain is unfamiliar.",
    ]


def test_toggle_active_flips_the_lure(client):
    OrganizationFactory()
    login(client)
    lure = LureTemplateFactory(is_active=True)

    response = client.post(reverse("lures:toggle", args=[lure.pk]))

    assert response.status_code == 302
    lure.refresh_from_db()
    assert lure.is_active is False


def test_preview_renders_sample_context_and_strips_attacks(client):
    OrganizationFactory()
    login(client)

    response = client.post(
        reverse("lures:preview"),
        {
            "sender_name": "Brightline Billing",
            "sender_email": "billing@brightline.example",
            "subject": "Invoice due",
            "cta_text": "Review invoice",
            "body_html": (
                "<p>Hi {{ first_name }},</p>"
                '<p onclick="alert(1)">Invoice due.</p>'
                '<img src="https://evil.example/pixel.png">'
                '<a href="javascript:alert(1)">Bad</a>'
                '<a href="{{ cta_url }}">Good</a>'
            ),
        },
    )
    content = response.content.decode()

    assert response.status_code == 200
    assert "<!doctype html>" not in content
    assert "Alex Chen" in content
    assert "Brightline Billing" in content
    assert "Invoice due" in content
    assert "onclick" not in content
    assert "javascript:" not in content
    assert "evil.example" not in content


def test_preview_reports_template_errors(client):
    OrganizationFactory()
    login(client)

    response = client.post(
        reverse("lures:preview"),
        {"body_html": "<p>{% if first_name %}</p>"},
    )

    assert response.status_code == 200
    assert "Template syntax error" in response.content.decode()


def test_preview_requires_staff_login(client):
    response = client.post(reverse("lures:preview"), {"body_html": "<p>x</p>"})

    assert response.status_code == 302
    assert response.url.startswith(reverse("login"))


def test_guide_page_is_staff_only_and_shows_placeholders(client):
    response = client.get(reverse("lures:guide"))
    assert response.status_code == 302

    login(client)
    response = client.get(reverse("lures:guide"))
    content = response.content.decode()

    assert response.status_code == 200
    assert "{{ cta_url }}" in content
    assert "Click-only" in content


def test_form_links_to_the_guide_and_live_preview(client):
    OrganizationFactory()
    login(client)

    response = client.get(reverse("lures:create"))
    content = response.content.decode()

    assert response.status_code == 200
    assert reverse("lures:guide") in content
    assert reverse("lures:preview") in content
    assert "hx-post" in content
