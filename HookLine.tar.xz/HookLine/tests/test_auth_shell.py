"""Tests for staff auth, navigation, and the app shell."""

import pytest
from django.template.loader import render_to_string
from django.test import Client, override_settings
from django.urls import reverse

from tests.factories import OrganizationFactory, UserFactory

pytestmark = pytest.mark.django_db

STAFF_ROUTES = [
    "dashboard",
    "settings",
    "campaigns:list",
    "campaigns:create",
    "lures:list",
    "lures:create",
    "lures:guide",
    "targets:list",
    "targets:create",
    "targets:import",
    "targets:groups",
    "targets:group_create",
]


@pytest.mark.parametrize("route", STAFF_ROUTES)
def test_staff_routes_redirect_anonymous_users(client, route):
    response = client.get(reverse(route))

    assert response.status_code == 302
    assert response.url.startswith(reverse("login"))


@pytest.mark.parametrize("route", STAFF_ROUTES)
def test_staff_routes_reject_signed_in_non_staff_users(client, route):
    user = UserFactory(is_staff=False)
    client.force_login(user)

    response = client.get(reverse(route))

    assert response.status_code == 403


@pytest.mark.parametrize("route", STAFF_ROUTES)
def test_staff_users_can_open_every_section(client, route):
    user = UserFactory()
    client.force_login(user)

    response = client.get(reverse(route))

    assert response.status_code == 200


@override_settings(DEBUG=True)
def test_login_allows_null_origin_in_local_development():
    UserFactory(username="staff", password="correct-horse-battery")
    client = Client(enforce_csrf_checks=True)
    client.get(reverse("login"))
    token = client.cookies["csrftoken"].value

    response = client.post(
        reverse("login"),
        {
            "username": "staff",
            "password": "correct-horse-battery",
            "csrfmiddlewaretoken": token,
        },
        HTTP_ORIGIN="null",
    )

    assert response.status_code == 302
    assert response.url == reverse("dashboard")


@override_settings(DEBUG=False)
def test_login_rejects_null_origin_when_debug_is_off():
    UserFactory(username="staff", password="correct-horse-battery")
    client = Client(enforce_csrf_checks=True)
    client.get(reverse("login"))
    token = client.cookies["csrftoken"].value

    response = client.post(
        reverse("login"),
        {
            "username": "staff",
            "password": "correct-horse-battery",
            "csrfmiddlewaretoken": token,
        },
        HTTP_ORIGIN="null",
    )

    assert response.status_code == 403


def test_csrf_trusted_origins_cover_local_dev():
    from django.conf import settings

    assert "http://127.0.0.1:8000" in settings.CSRF_TRUSTED_ORIGINS
    assert "http://localhost:8000" in settings.CSRF_TRUSTED_ORIGINS


def test_login_accepts_a_matching_origin_header(client):
    UserFactory(username="staff", password="correct-horse-battery")

    response = client.post(
        reverse("login"),
        {"username": "staff", "password": "correct-horse-battery"},
        HTTP_ORIGIN="http://testserver",
    )

    assert response.status_code == 302
    assert response.url == reverse("dashboard")


def test_login_page_omits_the_empty_sidebar_column(client):
    content = client.get(reverse("login")).content.decode()

    assert 'class="app-shell app-shell--auth"' in content
    assert 'class="sidebar"' not in content


def test_authenticated_pages_keep_the_sidebar_layout(client):
    user = UserFactory()
    client.force_login(user)

    content = client.get(reverse("dashboard")).content.decode()

    assert 'class="app-shell"' in content
    assert "app-shell--auth" not in content
    assert 'class="sidebar"' in content


def test_staff_user_can_log_in_and_out(client):
    UserFactory(username="staff", password="correct-horse-battery")

    response = client.post(
        reverse("login"),
        {"username": "staff", "password": "correct-horse-battery"},
    )
    assert response.status_code == 302
    assert response.url == reverse("dashboard")

    response = client.post(reverse("logout"))
    assert response.status_code == 302
    assert response.url == reverse("login")

    assert client.get(reverse("dashboard")).status_code == 302


def test_dark_theme_cookie_is_rendered_server_side(client):
    user = UserFactory()
    client.force_login(user)
    client.cookies["hookline_theme"] = "dark"

    response = client.get(reverse("dashboard"))
    content = response.content.decode()

    assert 'data-theme="dark"' in content
    assert 'data-theme-preference="dark"' in content
    assert "hookline_theme" in content


def test_invalid_theme_cookie_falls_back_to_system(client):
    user = UserFactory()
    client.force_login(user)
    client.cookies["hookline_theme"] = "neon"

    response = client.get(reverse("dashboard"))
    content = response.content.decode()

    assert 'data-theme-preference="system"' in content
    assert "js/theme.js" in content


def test_active_navigation_section_is_marked(client):
    user = UserFactory()
    client.force_login(user)
    campaigns_url = reverse("campaigns:list")

    response = client.get(campaigns_url)
    content = response.content.decode()

    assert f'href="{campaigns_url}"' in content
    assert 'aria-current="page"' in content


def test_settings_shows_organization_and_delivery_summary(client):
    OrganizationFactory(name="Northwind Logistics")
    user = UserFactory()
    client.force_login(user)

    response = client.get(reverse("settings"))
    content = response.content.decode()

    assert "Northwind Logistics" in content
    assert "Simulated inbox" in content
    assert "90 days" in content


def test_error_templates_render():
    assert "Access denied" in render_to_string("403.html")
    assert "Page not found" in render_to_string("404.html")


def test_shell_has_landmarks_and_no_external_assets(client):
    user = UserFactory()
    client.force_login(user)

    content = client.get(reverse("dashboard")).content.decode()

    assert 'class="skip-link"' in content
    assert 'aria-label="Main navigation"' in content
    assert 'id="main"' in content
    assert "http://" not in content
    assert "https://" not in content
