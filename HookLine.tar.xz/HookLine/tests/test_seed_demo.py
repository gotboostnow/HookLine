"""Tests for the seed_demo command."""

import io
import re
from datetime import timedelta

import pytest
from django.contrib.auth import get_user_model
from django.core.management import call_command

from campaigns.models import Campaign, CampaignRecipient
from core.models import Organization
from lures.models import LureTemplate
from targets.models import Group, Target
from tests.factories import TargetFactory
from tracking.models import TrackingEvent

pytestmark = pytest.mark.django_db

Q3 = "Q3 Invoice Review"
DRAFT = "October Password Reset"


def run_seed(*args) -> str:
    output = io.StringIO()
    call_command("seed_demo", *args, stdout=output)
    return output.getvalue()


def test_seed_creates_the_demo_dataset():
    output = run_seed()

    organization = Organization.objects.get()
    assert organization.name == "Northwind Logistics"
    assert organization.domain == "northwind.example"
    assert organization.retention_days == 90

    assert Target.objects.count() == 200
    assert Target.objects.filter(is_excluded=True).count() == 3
    assert set(Group.objects.values_list("name", flat=True)) == {
        "Finance",
        "All Staff",
        "Executives",
    }
    assert LureTemplate.objects.count() == 2
    assert Campaign.objects.count() == 2
    assert "Hookline demo data ready." in output


def test_seed_is_idempotent():
    run_seed()
    run_seed()

    assert Target.objects.count() == 200
    assert Group.objects.count() == 3
    assert LureTemplate.objects.count() == 2
    assert Campaign.objects.count() == 2
    assert CampaignRecipient.objects.count() == 394
    assert TrackingEvent.objects.count() == 99


def test_active_campaign_has_the_demo_metrics():
    run_seed()

    campaign = Campaign.objects.get(name=Q3)
    delivered = campaign.recipients.count()
    clicked = campaign.recipients.filter(clicked_at__isnull=False).count()
    reported = campaign.recipients.filter(reported_at__isnull=False).count()

    assert campaign.status == Campaign.Status.ACTIVE
    assert campaign.reporting_mode == Campaign.ReportingMode.NAMED
    assert delivered == 197
    assert clicked == 75
    assert reported == 24
    assert round(clicked / delivered * 100) == 38
    assert round(reported / delivered * 100) == 12


def test_excluded_targets_are_not_in_any_campaign():
    run_seed()

    assert CampaignRecipient.objects.filter(target__is_excluded=True).count() == 0


def test_events_span_the_campaign_window():
    run_seed()

    times = list(
        TrackingEvent.objects.filter(recipient__campaign__name=Q3).values_list(
            "occurred_at", flat=True
        )
    )

    assert len(times) == 99
    assert max(times) - min(times) >= timedelta(days=4)


def test_sample_urls_point_to_active_recipients():
    output = run_seed()

    tokens = re.findall(r"/i/([A-Za-z0-9_-]+)/", output)
    education_tokens = re.findall(r"/education/([A-Za-z0-9_-]+)/", output)

    assert len(tokens) == 3
    assert len(education_tokens) == 1
    for token in tokens:
        recipient = CampaignRecipient.objects.get(token=token)
        assert recipient.campaign.status == Campaign.Status.ACTIVE


def test_reset_removes_extra_data():
    run_seed()
    TargetFactory(email="extra@northwind.example")
    assert Target.objects.count() == 201

    run_seed("--reset")

    assert Target.objects.count() == 200
    assert not Target.objects.filter(email="extra@northwind.example").exists()
    assert Campaign.objects.count() == 2


def test_with_admin_creates_a_superuser():
    output = run_seed("--with-admin")

    user = get_user_model().objects.get(username="admin")
    assert user.is_superuser is True
    assert user.is_staff is True

    match = re.search(r"Admin password: (\S+)", output)
    assert match is not None
    assert user.check_password(match.group(1))


def test_draft_campaign_is_ready_but_blocked_on_authorization():
    run_seed()

    campaign = Campaign.objects.get(name=DRAFT)

    assert campaign.status == Campaign.Status.DRAFT
    assert campaign.recipients.count() == 197
    assert "Acknowledge the authorization before launching." in campaign.launch_blockers()
