"""Smoke tests for the Django admin registrations."""

import pytest
from django.urls import reverse

from tests.factories import (
    CampaignRecipientFactory,
    GroupFactory,
    LureTemplateFactory,
    OrganizationFactory,
    TargetFactory,
    TrackingEventFactory,
    UserFactory,
)

pytestmark = pytest.mark.django_db

CHANGELISTS = [
    "core_organization_changelist",
    "targets_target_changelist",
    "targets_group_changelist",
    "lures_luretemplate_changelist",
    "campaigns_campaign_changelist",
    "campaigns_campaignrecipient_changelist",
    "tracking_trackingevent_changelist",
]


def test_admin_changelists_load(client):
    admin_user = UserFactory(is_superuser=True)
    OrganizationFactory()
    target = TargetFactory()
    group = GroupFactory()
    group.targets.add(target)
    lure = LureTemplateFactory()
    recipient = CampaignRecipientFactory(campaign__lure=lure, target=target)
    TrackingEventFactory(recipient=recipient)

    client.force_login(admin_user)

    for route_name in CHANGELISTS:
        response = client.get(reverse(f"admin:{route_name}"))
        assert response.status_code == 200, route_name
