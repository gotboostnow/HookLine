"""Tests for the recipient's simulated inbox."""

import pytest
from django.urls import reverse
from django.utils import timezone

from campaigns.models import Campaign
from tests.factories import (
    CampaignFactory,
    CampaignRecipientFactory,
    LureTemplateFactory,
    OrganizationFactory,
    TargetFactory,
    TrackingEventFactory,
)

pytestmark = pytest.mark.django_db


def make_recipient(status=Campaign.Status.ACTIVE, body_html=None, **campaign_kwargs):
    OrganizationFactory()
    lure_kwargs = {}
    if body_html is not None:
        lure_kwargs["body_html"] = body_html
    lure = LureTemplateFactory(**lure_kwargs)
    campaign = CampaignFactory(
        status=status,
        lure=lure,
        launched_at=timezone.now(),
        **campaign_kwargs,
    )
    target = TargetFactory(first_name="Priya", last_name="Patel")
    recipient = CampaignRecipientFactory(
        campaign=campaign,
        target=target,
        sent_at=timezone.now(),
    )
    return recipient, lure, target


def test_inbox_renders_the_lure_and_cta_for_an_active_recipient(client):
    recipient, lure, target = make_recipient(
        body_html=(
            "<p>Hi {{ first_name }}, review the invoice.</p>"
            '<p><a href="{{ cta_url }}">{{ cta_text }}</a></p>'
        )
    )

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Northwind Mail" in content
    assert lure.subject in content
    assert lure.sender_name in content
    assert lure.sender_email in content
    assert "Hi Priya" in content
    assert f'href="/t/{recipient.token}/"' in content
    assert "Review invoice" in content
    assert target.email in content


def test_inbox_report_button_posts_to_the_report_route_with_csrf(client):
    recipient, _, _ = make_recipient()

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))
    content = response.content.decode()

    assert f'action="/t/{recipient.token}/report/"' in content
    assert 'method="post"' in content
    assert 'name="csrfmiddlewaretoken"' in content
    assert "Report phishing" in content


def test_inbox_adds_a_cta_when_the_body_has_no_placeholder(client):
    recipient, lure, _ = make_recipient(body_html="<p>Hello {{ first_name }}.</p>")

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))
    content = response.content.decode()

    assert 'class="email-cta"' in content
    assert f'href="/t/{recipient.token}/"' in content
    assert lure.cta_text in content


def test_inbox_strips_unsafe_markup_from_the_lure(client):
    recipient, _, _ = make_recipient(
        body_html=(
            "<p>Hello {{ first_name }}.</p>"
            "<script>alert(1)</script>"
            '<img src="https://tracker.example/pixel.gif">'
        )
    )

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))
    content = response.content.decode()

    assert "alert(1)" not in content
    assert "tracker.example" not in content
    assert "Hello Priya" in content


def test_inbox_is_public_and_does_not_record_an_event(client):
    recipient, _, _ = make_recipient()
    TrackingEventFactory(recipient=recipient)

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))

    assert response.status_code == 200
    assert recipient.events.count() == 1


def test_inbox_returns_404_for_an_unknown_token(client):
    response = client.get(reverse("tracking:inbox", args=["not-a-real-token"]))

    assert response.status_code == 404


@pytest.mark.parametrize("status", [Campaign.Status.DRAFT, Campaign.Status.CLOSED])
def test_inbox_returns_404_for_non_active_campaigns(client, status):
    recipient, _, _ = make_recipient(status=status)

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))

    assert response.status_code == 404


def test_inbox_sets_privacy_headers(client):
    recipient, _, _ = make_recipient()

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))

    assert response["Referrer-Policy"] == "no-referrer"
    assert response["X-Robots-Tag"] == "noindex"
    assert 'name="robots" content="noindex, nofollow"' in response.content.decode()


def test_privacy_headers_also_apply_to_unknown_tokens(client):
    response = client.get(reverse("tracking:inbox", args=["missing"]))

    assert response.status_code == 404
    assert response["Referrer-Policy"] == "no-referrer"
    assert response["X-Robots-Tag"] == "noindex"


def test_inbox_follows_the_theme_cookie(client):
    recipient, _, _ = make_recipient()
    client.cookies["hookline_theme"] = "dark"

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))
    content = response.content.decode()

    assert 'data-theme="dark"' in content
    assert 'data-theme-preference="dark"' in content


def test_inbox_has_no_external_assets(client):
    recipient, _, _ = make_recipient()

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))
    content = response.content.decode()

    assert "http://" not in content
    assert "https://" not in content
    assert 'href="/static/css/recipient.css"' in content
