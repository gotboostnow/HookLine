"""Tests for campaign launch, close, and sender adapters."""

import logging

import pytest
from django.core import mail
from django.test import override_settings
from django.urls import reverse

from campaigns.models import Campaign
from campaigns.senders import (
    ExternalDeliveryBlocked,
    SimulatedInboxSender,
    SmtpSender,
    build_messages,
    get_sender,
)
from campaigns.services import (
    CampaignLaunchError,
    CampaignStateError,
    close_campaign,
    launch_campaign,
)
from tests.factories import (
    CampaignFactory,
    CampaignRecipientFactory,
    LureTemplateFactory,
    OrganizationFactory,
    TargetFactory,
    UserFactory,
)

pytestmark = pytest.mark.django_db


class RecordingSender:
    name = "recording"

    def __init__(self):
        self.calls = []

    def send(self, campaign, messages):
        self.calls.append((campaign, messages))


class FailingSender:
    name = "failing"

    def send(self, campaign, messages):
        raise RuntimeError("SMTP rejected alex.chen@northwind.example")


def login(client):
    user = UserFactory()
    client.force_login(user)
    return user


def make_campaign(**kwargs):
    OrganizationFactory()
    campaign = CampaignFactory(**kwargs)
    targets = [TargetFactory(), TargetFactory()]
    for target in targets:
        CampaignRecipientFactory(campaign=campaign, target=target)
    return campaign, targets


def test_launch_activates_campaign_and_marks_recipients_sent(client, monkeypatch):
    campaign, targets = make_campaign()
    login(client)
    sender = RecordingSender()
    monkeypatch.setattr("campaigns.views.get_sender", lambda: sender)

    response = client.post(reverse("campaigns:launch", args=[campaign.pk]))

    assert response.status_code == 302
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.ACTIVE
    assert campaign.launched_at is not None
    assert all(
        sent_at is not None for sent_at in campaign.recipients.values_list("sent_at", flat=True)
    )

    assert len(sender.calls) == 1
    sent_campaign, messages = sender.calls[0]
    assert sent_campaign.pk == campaign.pk
    assert len(messages) == 2
    assert {message.recipient.target_id for message in messages} == {
        target.pk for target in targets
    }
    assert all(f"/t/{message.recipient.token}/" in message.cta_url for message in messages)


def test_launch_uses_the_simulated_sender_by_default(client, monkeypatch):
    campaign, _ = make_campaign()
    login(client)
    monkeypatch.setattr("campaigns.views.get_sender", lambda: SimulatedInboxSender())

    response = client.post(reverse("campaigns:launch", args=[campaign.pk]))

    assert response.status_code == 302
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.ACTIVE


def test_edit_page_links_to_launch_when_ready(client):
    campaign, _ = make_campaign()
    login(client)

    response = client.get(reverse("campaigns:edit", args=[campaign.pk]))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Ready to launch" in content
    assert reverse("campaigns:launch", args=[campaign.pk]) in content


def test_launch_confirmation_lists_blockers(client):
    campaign, _ = make_campaign(
        authorized_by="",
        authorization_scope="",
        authorization_acknowledged=False,
    )
    login(client)

    response = client.get(reverse("campaigns:launch", args=[campaign.pk]))
    content = response.content.decode()

    assert response.status_code == 200
    assert "This campaign cannot launch yet." in content
    assert "Record who authorized this campaign." in content
    assert '<button class="btn btn-primary" type="submit">Launch campaign</button>' not in content


def test_launch_with_incomplete_authorization_is_rejected(client, monkeypatch):
    campaign, _ = make_campaign(
        authorized_by="",
        authorization_scope="",
        authorization_acknowledged=False,
    )
    login(client)
    sender = RecordingSender()
    monkeypatch.setattr("campaigns.views.get_sender", lambda: sender)

    response = client.post(reverse("campaigns:launch", args=[campaign.pk]), follow=True)
    content = response.content.decode()

    assert response.status_code == 200
    assert "Record who authorized this campaign." in content
    assert sender.calls == []
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.DRAFT
    assert campaign.launched_at is None
    assert not campaign.recipients.exclude(sent_at=None).exists()


def test_launch_skips_and_removes_excluded_recipients(client, monkeypatch):
    campaign, targets = make_campaign()
    excluded = TargetFactory(
        is_excluded=True,
        exclusion_reason="On parental leave",
    )
    CampaignRecipientFactory(campaign=campaign, target=excluded)
    login(client)
    sender = RecordingSender()
    monkeypatch.setattr("campaigns.views.get_sender", lambda: sender)

    response = client.post(reverse("campaigns:launch", args=[campaign.pk]))

    assert response.status_code == 302
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.ACTIVE
    assert not campaign.recipients.filter(target=excluded).exists()
    assert len(sender.calls[0][1]) == 2
    assert {message.recipient.target_id for message in sender.calls[0][1]} == {
        target.pk for target in targets
    }


def test_launch_rolls_back_when_the_sender_fails(client, monkeypatch, caplog):
    campaign, _ = make_campaign()
    login(client)
    monkeypatch.setattr("campaigns.views.get_sender", lambda: FailingSender())
    caplog.set_level(logging.ERROR, logger="campaigns.views")

    response = client.post(reverse("campaigns:launch", args=[campaign.pk]), follow=True)

    assert response.status_code == 200
    assert "the campaign was not launched" in response.content.decode()
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.DRAFT
    assert campaign.launched_at is None
    assert not campaign.recipients.exclude(sent_at=None).exists()

    logged = caplog.text
    assert str(campaign.pk) in logged
    assert "RuntimeError" in logged
    assert "alex.chen@northwind.example" not in logged


def test_launch_requires_staff_login(client):
    campaign, _ = make_campaign()

    response = client.get(reverse("campaigns:launch", args=[campaign.pk]))

    assert response.status_code == 302
    assert response.url.startswith(reverse("login"))


def test_launch_post_requires_staff_login(client):
    campaign, _ = make_campaign()

    response = client.post(reverse("campaigns:launch", args=[campaign.pk]))

    assert response.status_code == 302
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.DRAFT


def test_close_freezes_an_active_campaign(client):
    campaign, _ = make_campaign(status=Campaign.Status.ACTIVE)
    login(client)

    response = client.post(reverse("campaigns:close", args=[campaign.pk]))

    assert response.status_code == 302
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.CLOSED
    assert campaign.closed_at is not None


def test_close_rejects_a_draft_campaign(client):
    campaign, _ = make_campaign()
    login(client)

    response = client.post(reverse("campaigns:close", args=[campaign.pk]), follow=True)

    assert response.status_code == 200
    assert "Only active campaigns can be closed." in response.content.decode()
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.DRAFT
    assert campaign.closed_at is None


def test_close_confirmation_page_explains_the_effect(client):
    campaign, _ = make_campaign(status=Campaign.Status.ACTIVE)
    login(client)

    response = client.get(reverse("campaigns:close", args=[campaign.pk]))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Close “" in content
    assert "Closing stops new clicks" in content
    assert "Close campaign" in content


def test_launch_service_raises_blockers_instead_of_mutating():
    campaign, _ = make_campaign(
        authorized_by="",
        authorization_scope="",
        authorization_acknowledged=False,
    )

    with pytest.raises(CampaignLaunchError) as excinfo:
        launch_campaign(
            campaign,
            sender=RecordingSender(),
            base_url="http://testserver",
        )

    assert "Record who authorized this campaign." in excinfo.value.blockers
    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.DRAFT


def test_close_service_rejects_non_active_campaigns():
    campaign, _ = make_campaign()

    with pytest.raises(CampaignStateError):
        close_campaign(campaign)

    campaign.refresh_from_db()
    assert campaign.status == Campaign.Status.DRAFT


def test_build_messages_renders_recipient_context_and_tracking_url():
    OrganizationFactory()
    lure = LureTemplateFactory(
        body_html=(
            "<p>Hi {{ first_name }}, open the invoice.</p>"
            '<p><a href="{{ cta_url }}">{{ cta_text }}</a></p>'
            "<script>alert(1)</script>"
        ),
        cta_text="Review invoice",
    )
    campaign = CampaignFactory(lure=lure)
    target = TargetFactory(first_name="Priya", last_name="Patel")
    recipient = CampaignRecipientFactory(campaign=campaign, target=target)

    messages = build_messages(campaign, "http://testserver/")

    assert len(messages) == 1
    message = messages[0]
    assert message.subject == lure.subject
    assert "Hi Priya" in message.body_html
    assert f'href="http://testserver/t/{recipient.token}/"' in message.body_html
    assert "Review invoice" in message.body_html
    assert "<script>" not in message.body_html


@override_settings(
    MAILERS={
        "default": {
            "BACKEND": "django.core.mail.backends.smtp.EmailBackend",
            "OPTIONS": {},
        }
    }
)
def test_get_sender_returns_smtp_for_the_smtp_backend():
    assert isinstance(get_sender(), SmtpSender)


def test_get_sender_returns_simulated_for_the_console_backend():
    assert isinstance(get_sender(), SimulatedInboxSender)


@override_settings(
    DEMO_MODE=False,
    ALLOWED_RECIPIENT_DOMAINS=["northwind.example"],
    MAILERS={
        "default": {
            "BACKEND": "django.core.mail.backends.smtp.EmailBackend",
            "OPTIONS": {},
        }
    },
)
def test_settings_summarises_the_smtp_sender_and_allowlist(client):
    OrganizationFactory()
    login(client)

    response = client.get(reverse("settings"))
    content = response.content.decode()

    assert response.status_code == 200
    assert "SMTP" in content
    assert "northwind.example" in content


def test_smtp_sender_refuses_external_delivery_in_demo_mode():
    OrganizationFactory()
    campaign = CampaignFactory()
    CampaignRecipientFactory(campaign=campaign)
    messages = build_messages(campaign, "http://testserver")

    with override_settings(
        DEMO_MODE=True,
        ALLOWED_RECIPIENT_DOMAINS=["northwind.example"],
    ):
        with pytest.raises(ExternalDeliveryBlocked, match="demo mode"):
            SmtpSender().send(campaign, messages)


def test_smtp_sender_refuses_without_an_allowlist():
    OrganizationFactory()
    campaign = CampaignFactory()
    CampaignRecipientFactory(campaign=campaign)
    messages = build_messages(campaign, "http://testserver")

    with override_settings(DEMO_MODE=False, ALLOWED_RECIPIENT_DOMAINS=[]):
        with pytest.raises(ExternalDeliveryBlocked, match="allowlisted"):
            SmtpSender().send(campaign, messages)


def test_smtp_sender_refuses_a_domain_outside_the_allowlist():
    OrganizationFactory()
    campaign = CampaignFactory()
    CampaignRecipientFactory(campaign=campaign)
    messages = build_messages(campaign, "http://testserver")

    with override_settings(
        DEMO_MODE=False,
        ALLOWED_RECIPIENT_DOMAINS=["other.example"],
    ):
        with pytest.raises(ExternalDeliveryBlocked, match="not allowlisted"):
            SmtpSender().send(campaign, messages)


def test_smtp_sender_delivers_to_an_allowlisted_domain():
    OrganizationFactory()
    lure = LureTemplateFactory()
    campaign = CampaignFactory(lure=lure)
    target = TargetFactory(email="priya@northwind.example")
    CampaignRecipientFactory(campaign=campaign, target=target)
    messages = build_messages(campaign, "http://testserver")
    mail.outbox.clear()

    with override_settings(
        DEMO_MODE=False,
        ALLOWED_RECIPIENT_DOMAINS=["northwind.example"],
        MAILERS={
            "default": {
                "BACKEND": "django.core.mail.backends.locmem.EmailBackend",
                "OPTIONS": {},
            }
        },
    ):
        SmtpSender().send(campaign, messages)

    assert len(mail.outbox) == 1
    sent = mail.outbox[0]
    assert sent.subject == lure.subject
    assert sent.to == ["priya@northwind.example"]
    assert sent.from_email == f"{lure.sender_name} <{lure.sender_email}>"
    assert sent.alternatives
    assert messages[0].cta_url in sent.body
