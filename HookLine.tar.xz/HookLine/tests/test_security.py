"""Security regression tests: headers, sanitization, tokens, CSRF, and logs."""

import logging
import re
from datetime import timedelta

import pytest
from django.core.cache import cache
from django.core.management import call_command
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from campaigns.models import Campaign, CampaignRecipient
from campaigns.tokens import generate_token
from core.logging import RedactRecipientRoutesFilter
from lures.sanitizer import render_lure, sanitize_html
from tests.factories import (
    CampaignFactory,
    CampaignRecipientFactory,
    LureTemplateFactory,
    OrganizationFactory,
    TargetFactory,
    TrackingEventFactory,
    UserFactory,
)
from tracking.models import TrackingEvent

pytestmark = pytest.mark.django_db

XSS_PAYLOAD = (
    "<p>Hi {{ first_name }}</p>"
    "<script>alert('xss')</script>"
    '<img src="https://evil.example/pixel.png" onerror="alert(1)">'
    '<a href="javascript:alert(1)">bad link</a>'
    '<a href="{{ cta_url }}">good link</a>'
    '<p style="background:url(https://evil.example/bg)">styled</p>'
    '<iframe src="https://evil.example/frame"></iframe>'
    '<form action="/capture"><input name="password"></form>'
)

BAD_MARKERS = [
    "alert('xss')",
    "onerror",
    "javascript:",
    "evil.example",
    "<iframe",
    'action="/capture"',
    'name="password"',
    'style="',
]


def make_recipient(body_html=None):
    OrganizationFactory()
    lure = LureTemplateFactory(
        body_html=body_html or XSS_PAYLOAD,
        red_flags=["Unexpected sender"],
    )
    campaign = CampaignFactory(
        lure=lure,
        status=Campaign.Status.ACTIVE,
        launched_at=timezone.now(),
    )
    target = TargetFactory(first_name="Priya", last_name="Patel")
    return CampaignRecipientFactory(
        campaign=campaign,
        target=target,
        sent_at=timezone.now(),
    )


def assert_no_bad_markers(content):
    for marker in BAD_MARKERS:
        assert marker not in content


def test_security_headers_on_admin_pages(client):
    client.force_login(UserFactory())

    response = client.get(reverse("dashboard"))

    assert response["X-Content-Type-Options"] == "nosniff"
    assert response["X-Frame-Options"] == "DENY"
    assert response["Referrer-Policy"] == "no-referrer"
    assert "camera=()" in response["Permissions-Policy"]


def test_security_headers_on_recipient_pages(client):
    recipient = make_recipient()

    response = client.get(reverse("tracking:inbox", args=[recipient.token]))

    assert response["X-Content-Type-Options"] == "nosniff"
    assert response["X-Frame-Options"] == "DENY"
    assert response["Referrer-Policy"] == "no-referrer"
    assert response["X-Robots-Tag"] == "noindex"
    assert "geolocation=()" in response["Permissions-Policy"]


def test_sanitize_html_removes_xss_payloads():
    cleaned = sanitize_html(XSS_PAYLOAD)

    assert_no_bad_markers(cleaned)
    assert "Hi " in cleaned
    assert "good link" in cleaned


def test_render_lure_removes_xss_payloads():
    rendered = render_lure(XSS_PAYLOAD, {"first_name": "Priya", "cta_url": "/t/x/"})

    assert_no_bad_markers(rendered)
    assert "Hi Priya" in rendered
    assert 'href="/t/x/"' in rendered


def test_inbox_and_education_do_not_render_xss_payloads(client):
    recipient = make_recipient()

    inbox = client.get(reverse("tracking:inbox", args=[recipient.token]))
    education = client.get(reverse("tracking:education", args=[recipient.token]))

    assert_no_bad_markers(inbox.content.decode())
    assert_no_bad_markers(education.content.decode())


def test_lure_preview_does_not_render_xss_payloads(client):
    client.force_login(UserFactory())

    response = client.post(
        reverse("lures:preview"),
        {
            "sender_name": "Billing Team",
            "sender_email": "billing@brightline.example",
            "subject": "Invoice",
            "cta_text": "Review",
            "body_html": XSS_PAYLOAD,
        },
    )

    assert_no_bad_markers(response.content.decode())


def test_tokens_have_high_entropy_and_are_unique():
    tokens = [generate_token() for _ in range(100)]

    assert len(set(tokens)) == 100
    assert all(len(token) >= 43 for token in tokens)
    assert all(re.fullmatch(r"[A-Za-z0-9_-]+", token) for token in tokens)

    field = CampaignRecipient._meta.get_field("token")
    assert field.unique is True
    assert field.max_length == 64


def test_log_filter_redacts_tokens_in_messages_and_args():
    log_filter = RedactRecipientRoutesFilter()

    message_record = logging.LogRecord(
        "django.server",
        logging.INFO,
        "",
        0,
        "GET /i/secret-token-123/ HTTP/1.1",
        (),
        None,
    )
    log_filter.filter(message_record)
    assert "secret-token-123" not in message_record.getMessage()
    assert "/i/<redacted>" in message_record.getMessage()

    args_record = logging.LogRecord(
        "app",
        logging.INFO,
        "",
        0,
        "path=%s campaign=%s",
        ("/t/another-secret/", 7),
        None,
    )
    log_filter.filter(args_record)
    rendered = args_record.getMessage()
    assert "another-secret" not in rendered
    assert "campaign=7" in rendered


def test_invalid_token_404_does_not_echo_the_token(client):
    response = client.get(reverse("tracking:inbox", args=["secret-token-999"]))

    assert response.status_code == 404
    assert "secret-token-999" not in response.content.decode()


@pytest.mark.parametrize(
    ("name", "args"),
    [
        ("lures:toggle", [1]),
        ("targets:exclusion", [1]),
        ("targets:group_delete", [1]),
        ("campaigns:launch", [1]),
        ("campaigns:close", [1]),
        ("campaigns:create", []),
        ("lures:create", []),
        ("targets:import", []),
        ("logout", []),
    ],
)
def test_admin_posts_enforce_csrf(name, args):
    client = Client(enforce_csrf_checks=True)
    client.force_login(UserFactory())

    response = client.post(reverse(name, args=args))

    assert response.status_code == 403


def test_report_post_is_rate_limited_per_token(client):
    recipient = make_recipient()
    url = reverse("tracking:report", args=[recipient.token])
    cache.clear()
    try:
        for _ in range(10):
            assert client.post(url).status_code == 302
        assert client.post(url).status_code == 429
    finally:
        cache.clear()


def test_purge_events_deletes_only_old_events():
    OrganizationFactory(retention_days=30)
    recent = TrackingEventFactory()
    old = TrackingEventFactory()
    TrackingEvent.objects.filter(pk=old.pk).update(occurred_at=timezone.now() - timedelta(days=31))

    call_command("purge_events")

    assert not TrackingEvent.objects.filter(pk=old.pk).exists()
    assert TrackingEvent.objects.filter(pk=recent.pk).exists()
