"""factory_boy factories shared by the test suite."""

import factory
from django.contrib.auth import get_user_model

from campaigns.models import Campaign, CampaignRecipient
from core.models import Organization
from lures.models import LureTemplate
from targets.models import Group, Target
from tracking.models import TrackingEvent


class UserFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = get_user_model()
        skip_postgeneration_save = True

    username = factory.Sequence(lambda n: f"user{n}")
    email = factory.LazyAttribute(lambda obj: f"{obj.username}@northwind.example")
    is_staff = True
    is_active = True

    @factory.post_generation
    def password(self, create, extracted, **kwargs):
        self.set_password(extracted or "hookline-test-password")
        if create:
            self.save(update_fields=["password"])


class OrganizationFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Organization
        django_get_or_create = ("id",)

    id = 1
    name = "Northwind Logistics"
    domain = "northwind.example"
    retention_days = 90


class TargetFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Target

    organization = factory.SubFactory(OrganizationFactory)
    first_name = factory.Sequence(lambda n: f"Alex{n}")
    last_name = "Chen"
    email = factory.Sequence(lambda n: f"target{n}@northwind.example")
    department = "Finance"


class GroupFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Group

    organization = factory.SubFactory(OrganizationFactory)
    name = factory.Sequence(lambda n: f"Group {n}")
    description = "Test group"


class LureTemplateFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = LureTemplate

    organization = factory.SubFactory(OrganizationFactory)
    name = factory.Sequence(lambda n: f"Lure {n}")
    description = "Test lure"
    principles = factory.LazyFunction(lambda: ["authority"])
    difficulty = LureTemplate.Difficulty.MEDIUM
    sender_name = "Northwind Accounts"
    sender_email = factory.Sequence(lambda n: f"accounts{n}@northwind.example")
    subject = "Invoice awaiting review"
    body_html = "<p>Hi {{ first_name }}, please review the attached invoice.</p>"
    cta_text = "Review invoice"
    red_flags = factory.LazyFunction(lambda: ["The sender domain is not northwind.example."])
    is_active = True


class CampaignFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Campaign

    organization = factory.SubFactory(OrganizationFactory)
    name = factory.Sequence(lambda n: f"Campaign {n}")
    lure = factory.SubFactory(LureTemplateFactory)
    created_by = factory.SubFactory(UserFactory)
    authorized_by = "Dana Ruiz, IT Manager"
    authorization_scope = "All staff, Q4 2026 awareness exercise."
    authorization_acknowledged = True


class CampaignRecipientFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = CampaignRecipient

    campaign = factory.SubFactory(CampaignFactory)
    target = factory.SubFactory(TargetFactory)


class TrackingEventFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = TrackingEvent

    recipient = factory.SubFactory(CampaignRecipientFactory)
    event_type = TrackingEvent.EventType.CLICK
