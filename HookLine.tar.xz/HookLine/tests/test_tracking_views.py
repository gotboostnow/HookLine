"""Tests for click tracking, reporting, and the education page."""

import pytest
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from campaigns.models import Campaign
from tests.factories import (
    CampaignFactory,
    CampaignRecipientFactory,
    LureTemplateFactory,
    OrganizationFactory,
    TargetFactory,
)
from tracking.models import TrackingEvent

pytestmark = pytest.mark.django_db


def make_recipient(
    status=Campaign.Status.ACTIVE,
    principles=None,
    red_flags=None,
    body_html=None,
    **recipient_kwargs,
):
    OrganizationFactory()
    lure = LureTemplateFactory(
        principles=principles if principles is not None else ["authority"],
        red_flags=red_flags if red_flags is not None else ["The sender domain is unfamiliar."],
        **({"body_html": body_html} if body_html is not None else {}),
    )
    campaign = CampaignFactory(
        status=status,
        lure=lure,
        launched_at=timezone.now(),
    )
    target = TargetFactory(first_name="Priya", last_name="Patel")
    recipient = CampaignRecipientFactory(
        campaign=campaign,
        target=target,
        sent_at=timezone.now(),
        **recipient_kwargs,
    )
    return recipient, lure


def education_url(recipient):
    return reverse("tracking:education", args=[recipient.token])


def test_click_sets_first_timestamp_and_creates_an_event(client):
    recipient, _ = make_recipient()

    response = client.get(reverse("tracking:click", args=[recipient.token]))

    assert response.status_code == 302
    assert response.url == education_url(recipient)
    recipient.refresh_from_db()
    assert recipient.clicked_at is not None
    assert recipient.events.filter(event_type=TrackingEvent.EventType.CLICK).count() == 1


def test_repeat_click_keeps_the_first_timestamp_but_adds_an_event(client):
    recipient, _ = make_recipient()
    client.get(reverse("tracking:click", args=[recipient.token]))
    recipient.refresh_from_db()
    first_clicked_at = recipient.clicked_at

    client.get(reverse("tracking:click", args=[recipient.token]))
    recipient.refresh_from_db()

    assert recipient.clicked_at == first_clicked_at
    assert recipient.events.filter(event_type=TrackingEvent.EventType.CLICK).count() == 2


def test_closed_campaign_click_redirects_without_recording(client):
    recipient, _ = make_recipient(status=Campaign.Status.CLOSED)

    response = client.get(reverse("tracking:click", args=[recipient.token]))

    assert response.status_code == 302
    assert response.url == education_url(recipient)
    recipient.refresh_from_db()
    assert recipient.clicked_at is None
    assert recipient.events.count() == 0


@pytest.mark.parametrize("status", [Campaign.Status.DRAFT])
def test_click_is_404_for_non_recipient_campaigns(client, status):
    recipient, _ = make_recipient(status=status)

    response = client.get(reverse("tracking:click", args=[recipient.token]))

    assert response.status_code == 404


def test_click_with_an_invalid_token_is_404(client):
    response = client.get(reverse("tracking:click", args=["not-a-token"]))

    assert response.status_code == 404


def test_report_sets_first_timestamp_and_creates_an_event(client):
    recipient, _ = make_recipient()

    response = client.post(reverse("tracking:report", args=[recipient.token]))

    assert response.status_code == 302
    assert response.url == education_url(recipient)
    recipient.refresh_from_db()
    assert recipient.reported_at is not None
    assert recipient.events.filter(event_type=TrackingEvent.EventType.REPORT).count() == 1


def test_repeat_report_keeps_the_first_timestamp_but_adds_an_event(client):
    recipient, _ = make_recipient()
    client.post(reverse("tracking:report", args=[recipient.token]))
    recipient.refresh_from_db()
    first_reported_at = recipient.reported_at

    client.post(reverse("tracking:report", args=[recipient.token]))
    recipient.refresh_from_db()

    assert recipient.reported_at == first_reported_at
    assert recipient.events.filter(event_type=TrackingEvent.EventType.REPORT).count() == 2


def test_closed_campaign_report_redirects_without_recording(client):
    recipient, _ = make_recipient(status=Campaign.Status.CLOSED)

    response = client.post(reverse("tracking:report", args=[recipient.token]))

    assert response.status_code == 302
    assert response.url == education_url(recipient)
    recipient.refresh_from_db()
    assert recipient.reported_at is None
    assert recipient.events.count() == 0


def test_report_requires_post(client):
    recipient, _ = make_recipient()

    response = client.get(reverse("tracking:report", args=[recipient.token]))

    assert response.status_code == 405


def test_report_enforces_csrf():
    recipient, _ = make_recipient()
    client = Client(enforce_csrf_checks=True)

    response = client.post(reverse("tracking:report", args=[recipient.token]))

    assert response.status_code == 403
    recipient.refresh_from_db()
    assert recipient.reported_at is None
    assert recipient.events.count() == 0


def test_report_succeeds_with_a_valid_csrf_token():
    recipient, _ = make_recipient()
    client = Client(enforce_csrf_checks=True)
    client.get(reverse("tracking:inbox", args=[recipient.token]))
    csrf_token = client.cookies["csrftoken"].value

    response = client.post(
        reverse("tracking:report", args=[recipient.token]),
        {"csrfmiddlewaretoken": csrf_token},
    )

    assert response.status_code == 302
    recipient.refresh_from_db()
    assert recipient.reported_at is not None
    assert recipient.events.count() == 1


def test_education_shows_the_reveal_outcome_flags_and_principles(client):
    recipient, lure = make_recipient(
        clicked_at=timezone.now(),
        principles=["urgency", "authority"],
        red_flags=["Same-day deadline", "Unfamiliar sender domain"],
    )

    response = client.get(education_url(recipient))
    content = response.content.decode()

    assert response.status_code == 200
    assert "This was a simulated phishing email" in content
    assert "No data was captured" in content
    assert "You clicked the link." in content
    assert lure.subject in content
    assert "Same-day deadline" in content
    assert "Unfamiliar sender domain" in content
    assert "Urgency" in content
    assert "Authority" in content
    assert "Time pressure short-circuits verification." in content
    assert "Hover over links before clicking" in content
    assert f'action="/t/{recipient.token}/report/"' in content
    assert f'href="/i/{recipient.token}/"' in content


def test_education_reported_variant_confirms_the_report(client):
    recipient, _ = make_recipient(reported_at=timezone.now())

    response = client.get(education_url(recipient))
    content = response.content.decode()

    assert "You reported this email" in content
    assert "Thanks for reporting it." in content
    assert "Report this email</button>" not in content


def test_education_view_records_no_event(client):
    recipient, _ = make_recipient()

    client.get(education_url(recipient))

    assert recipient.events.count() == 0


def test_education_renders_for_closed_campaigns_without_new_reports(client):
    recipient, _ = make_recipient(status=Campaign.Status.CLOSED)

    response = client.get(education_url(recipient))
    content = response.content.decode()

    assert response.status_code == 200
    assert "This campaign is closed" in content
    assert "Report this email</button>" not in content
    assert 'href="/i/' not in content


def test_education_is_404_for_draft_and_invalid_tokens(client):
    recipient, _ = make_recipient(status=Campaign.Status.DRAFT)

    assert client.get(education_url(recipient)).status_code == 404
    assert client.get(reverse("tracking:education", args=["missing"])).status_code == 404


def test_recipient_routes_send_privacy_headers(client):
    recipient, _ = make_recipient()

    responses = [
        client.get(reverse("tracking:click", args=[recipient.token])),
        client.post(reverse("tracking:report", args=[recipient.token])),
        client.get(education_url(recipient)),
    ]
    for response in responses:
        assert response["Referrer-Policy"] == "no-referrer"
        assert response["X-Robots-Tag"] == "noindex"


def test_tracking_does_not_store_ip_or_user_agent(client):
    recipient, _ = make_recipient()

    client.get(
        reverse("tracking:click", args=[recipient.token]),
        REMOTE_ADDR="203.0.113.42",
        HTTP_USER_AGENT="Test Browser/1.0",
    )

    event = recipient.events.get()
    assert event.metadata == {}
    assert not hasattr(event, "ip_address")
    assert not hasattr(event, "user_agent")
