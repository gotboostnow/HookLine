"""Tests for target management, CSV import, exclusions, and groups."""

import pytest
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse

from targets.models import Group, Target
from tests.factories import GroupFactory, OrganizationFactory, TargetFactory, UserFactory

pytestmark = pytest.mark.django_db

HEADER = "first_name,last_name,email,department,groups"


def login(client):
    user = UserFactory()
    client.force_login(user)
    return user


def upload(rows, header=HEADER):
    body = header + "\n" + "\n".join(rows)
    return SimpleUploadedFile("targets.csv", body.encode(), content_type="text/csv")


def test_list_shows_targets_and_exclusion_reason(client):
    OrganizationFactory()
    login(client)
    TargetFactory(first_name="Alex", last_name="Chen", department="Finance")
    TargetFactory(
        first_name="Priya",
        last_name="Patel",
        email="priya@northwind.example",
        department="Sales",
        is_excluded=True,
        exclusion_reason="On parental leave",
    )

    response = client.get(reverse("targets:list"))
    content = response.content.decode()

    assert response.status_code == 200
    assert "Alex Chen" in content
    assert "Priya Patel" in content
    assert "Excluded" in content
    assert "On parental leave" in content


def test_search_filters_by_name_and_email(client):
    OrganizationFactory()
    login(client)
    TargetFactory(first_name="Alex", last_name="Chen", email="alex@northwind.example")
    TargetFactory(first_name="Priya", last_name="Patel", email="priya@northwind.example")

    response = client.get(reverse("targets:list"), {"q": "priya"})
    content = response.content.decode()

    assert "Priya Patel" in content
    assert "Alex Chen" not in content

    response = client.get(reverse("targets:list"), {"q": "alex@northwind"})
    assert "Alex Chen" in response.content.decode()


def test_department_and_status_filters(client):
    OrganizationFactory()
    login(client)
    TargetFactory(first_name="Alex", last_name="Chen", department="Finance")
    TargetFactory(
        first_name="Priya",
        last_name="Patel",
        email="priya@northwind.example",
        department="Finance",
        is_excluded=True,
        exclusion_reason="Legal hold",
    )
    TargetFactory(
        first_name="Sam",
        last_name="Rivera",
        email="sam@northwind.example",
        department="Sales",
    )

    response = client.get(reverse("targets:list"), {"department": "Finance", "status": "excluded"})
    content = response.content.decode()

    assert "Priya Patel" in content
    assert "Alex Chen" not in content
    assert "Sam Rivera" not in content


def test_htmx_search_returns_only_the_table_partial(client):
    OrganizationFactory()
    login(client)
    TargetFactory(first_name="Alex", last_name="Chen")

    response = client.get(reverse("targets:list"), {"q": "alex"}, HTTP_HX_REQUEST="true")
    content = response.content.decode()

    assert response.status_code == 200
    assert "<!doctype html>" not in content
    assert "Alex Chen" in content
    assert 'id="target-table"' not in content


def test_list_paginates_twenty_five_targets(client):
    OrganizationFactory()
    login(client)
    for index in range(30):
        TargetFactory(email=f"person{index}@northwind.example")

    response = client.get(reverse("targets:list"))

    assert response.context["page_obj"].paginator.num_pages == 2
    assert len(response.context["targets"]) == 25


def test_create_target_assigns_the_organization(client):
    organization = OrganizationFactory()
    login(client)

    response = client.post(
        reverse("targets:create"),
        {
            "first_name": "Alex",
            "last_name": "Chen",
            "email": "Alex.Chen@Northwind.example",
            "department": "Finance",
        },
    )

    assert response.status_code == 302
    target = Target.objects.get()
    assert target.organization == organization
    assert target.email == "alex.chen@northwind.example"


def test_create_target_rejects_a_duplicate_email(client):
    OrganizationFactory()
    login(client)
    TargetFactory(email="alex@northwind.example")

    response = client.post(
        reverse("targets:create"),
        {
            "first_name": "Another",
            "last_name": "Alex",
            "email": "alex@northwind.example",
            "department": "Finance",
        },
    )

    assert response.status_code == 200
    assert "already exists" in response.content.decode()
    assert Target.objects.count() == 1


def test_edit_target_updates_fields(client):
    OrganizationFactory()
    login(client)
    target = TargetFactory(department="Finance")

    response = client.post(
        reverse("targets:edit", args=[target.pk]),
        {
            "first_name": target.first_name,
            "last_name": target.last_name,
            "email": target.email,
            "department": "Operations",
        },
    )

    assert response.status_code == 302
    target.refresh_from_db()
    assert target.department == "Operations"


def test_excluding_requires_a_reason(client):
    OrganizationFactory()
    login(client)
    target = TargetFactory()

    response = client.post(
        reverse("targets:exclusion", args=[target.pk]),
        {"action": "exclude", "reason": "  "},
        follow=True,
    )

    target.refresh_from_db()
    assert target.is_excluded is False
    assert "Add a reason" in response.content.decode()


def test_excluding_and_including_a_target(client):
    OrganizationFactory()
    login(client)
    target = TargetFactory()

    response = client.post(
        reverse("targets:exclusion", args=[target.pk]),
        {"action": "exclude", "reason": "Legal hold"},
        follow=True,
    )
    target.refresh_from_db()
    assert target.is_excluded is True
    assert target.exclusion_reason == "Legal hold"
    assert "Excluded" in response.content.decode()

    client.post(
        reverse("targets:exclusion", args=[target.pk]),
        {"action": "include"},
    )
    target.refresh_from_db()
    assert target.is_excluded is False
    assert target.exclusion_reason == ""


def test_exclusion_redirects_to_a_safe_next_url(client):
    OrganizationFactory()
    login(client)
    target = TargetFactory()

    response = client.post(
        reverse("targets:exclusion", args=[target.pk]),
        {
            "action": "exclude",
            "reason": "Opted out",
            "next": "https://evil.example/phish",
        },
    )

    assert response.status_code == 302
    assert response.url == reverse("targets:list")


def test_csv_import_creates_targets_and_groups(client):
    OrganizationFactory()
    login(client)

    response = client.post(
        reverse("targets:import"),
        {
            "csv_file": upload(
                [
                    "Alex,Chen,alex@northwind.example,Finance,Finance;All Staff",
                    "Priya,Patel,priya@northwind.example,Sales,All Staff",
                ]
            )
        },
        follow=True,
    )

    assert response.status_code == 200
    assert Target.objects.count() == 2
    assert Group.objects.count() == 2
    assert Target.objects.get(email="alex@northwind.example").groups.count() == 2
    assert "2 added" in response.content.decode()


def test_csv_import_updates_existing_targets_and_preserves_exclusions(client):
    OrganizationFactory()
    login(client)
    target = TargetFactory(
        email="alex@northwind.example",
        department="Finance",
        is_excluded=True,
        exclusion_reason="Legal hold",
    )

    client.post(
        reverse("targets:import"),
        {
            "csv_file": upload(
                [
                    "Alex,Chen,alex@northwind.example,Operations,Executives",
                ]
            )
        },
    )

    assert Target.objects.count() == 1
    target.refresh_from_db()
    assert target.department == "Operations"
    assert target.is_excluded is True
    assert target.exclusion_reason == "Legal hold"
    assert list(target.groups.values_list("name", flat=True)) == ["Executives"]


def test_csv_import_reports_bad_rows_and_imports_valid_ones(client):
    OrganizationFactory()
    login(client)

    response = client.post(
        reverse("targets:import"),
        {
            "csv_file": upload(
                [
                    "Alex,Chen,not-an-email,Finance,",
                    "Priya,Patel,priya@northwind.example,Sales,All Staff",
                    "Alex,Chen,priya@northwind.example,Sales,All Staff",
                    ",,,,",
                ]
            )
        },
    )

    content = response.content.decode()

    assert response.status_code == 200
    assert Target.objects.count() == 1
    assert "is not a valid email address" in content
    assert "duplicate email" in content
    assert "are required" in content
    assert "1 added" in content


def test_csv_import_rejects_a_missing_required_column(client):
    OrganizationFactory()
    login(client)

    response = client.post(
        reverse("targets:import"),
        {"csv_file": upload(["Alex,Chen,alex@northwind.example"], header="first_name,email")},
    )

    assert response.status_code == 200
    assert "Missing required column(s): last_name." in response.content.decode()
    assert Target.objects.count() == 0


def test_csv_import_rejects_non_csv_files(client):
    OrganizationFactory()
    login(client)

    response = client.post(
        reverse("targets:import"),
        {"csv_file": SimpleUploadedFile("targets.txt", b"not,csv", content_type="text/plain")},
    )

    assert response.status_code == 200
    assert "Upload a .csv file." in response.content.decode()


def test_group_crud_flow(client):
    OrganizationFactory()
    login(client)
    finance = TargetFactory(department="Finance")
    sales = TargetFactory(
        first_name="Priya",
        last_name="Patel",
        email="priya@northwind.example",
        department="Sales",
    )

    response = client.post(
        reverse("targets:group_create"),
        {"name": "Finance", "description": "The finance team", "targets": [finance.pk]},
    )
    assert response.status_code == 302
    group = Group.objects.get(name="Finance")
    assert group.targets.get() == finance

    response = client.post(
        reverse("targets:group_edit", args=[group.pk]),
        {
            "name": "Finance and Sales",
            "description": "Revenue teams",
            "targets": [finance.pk, sales.pk],
        },
    )
    assert response.status_code == 302
    group.refresh_from_db()
    assert group.name == "Finance and Sales"
    assert group.targets.count() == 2

    response = client.post(reverse("targets:group_delete", args=[group.pk]))
    assert response.status_code == 302
    assert Group.objects.count() == 0
    assert Target.objects.count() == 2


def test_group_name_must_be_unique(client):
    OrganizationFactory()
    login(client)
    GroupFactory(name="Finance")

    response = client.post(
        reverse("targets:group_create"),
        {"name": "Finance", "description": "", "targets": []},
    )

    assert response.status_code == 200
    assert "already exists" in response.content.decode()
    assert Group.objects.count() == 1


def test_group_list_shows_member_counts(client):
    OrganizationFactory()
    login(client)
    group = GroupFactory(name="Finance")
    group.targets.add(TargetFactory(), TargetFactory())

    response = client.get(reverse("targets:groups"))

    assert response.status_code == 200
    assert response.context["groups"].get(name="Finance").member_count == 2
    assert "Finance" in response.content.decode()
