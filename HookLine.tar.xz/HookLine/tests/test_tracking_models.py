"""Tests for the tracking event log."""

import pytest

from tests.factories import CampaignRecipientFactory, TrackingEventFactory
from tracking.models import TrackingEvent

pytestmark = pytest.mark.django_db


def test_metadata_defaults_to_an_empty_dict():
    event = TrackingEventFactory()

    assert event.metadata == {}


def test_event_types():
    event = TrackingEventFactory(event_type=TrackingEvent.EventType.REPORT)

    assert event.event_type == "report"


def test_events_cascade_when_a_recipient_is_deleted():
    recipient = CampaignRecipientFactory()
    TrackingEventFactory(recipient=recipient)

    assert recipient.events.count() == 1

    recipient.delete()

    assert TrackingEvent.objects.count() == 0
