(function () {
  "use strict";

  var root = document.documentElement;
  var button = document.querySelector("[data-theme-toggle]");
  var order = ["system", "light", "dark"];

  function current() {
    return root.dataset.themePreference || "system";
  }

  function apply(preference) {
    var prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    var dark = preference === "dark" || (preference === "system" && prefersDark);
    root.dataset.theme = dark ? "dark" : "light";
    root.dataset.themePreference = preference;
    document.cookie =
      "hookline_theme=" +
      encodeURIComponent(preference) +
      "; path=/; max-age=31536000; samesite=lax";
    if (button) {
      button.textContent =
        preference === "system"
          ? "Theme: system"
          : preference === "dark"
            ? "Theme: dark"
            : "Theme: light";
    }
  }

  if (button) {
    button.addEventListener("click", function () {
      var next = order[(order.indexOf(current()) + 1) % order.length];
      apply(next);
    });
  }

  apply(current());
})();
