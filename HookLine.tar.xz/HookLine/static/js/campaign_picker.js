(function () {
  var picker = document.querySelector("[data-target-picker]");
  if (!picker) return;

  var search = picker.querySelector("[data-picker-search]");
  var group = picker.querySelector("[data-picker-group]");
  var selectAll = picker.querySelector("[data-picker-select-all]");
  var count = picker.querySelector("[data-picker-count]");
  var rows = Array.prototype.slice.call(
    picker.querySelectorAll("[data-target-row]")
  );

  var boxes = rows
    .map(function (row) {
      return row.querySelector('input[type="checkbox"]');
    })
    .filter(function (box) {
      return box && !box.disabled;
    });

  function visibleBoxes() {
    return rows
      .filter(function (row) {
        return !row.hidden;
      })
      .map(function (row) {
        return row.querySelector('input[type="checkbox"]');
      })
      .filter(function (box) {
        return box && !box.disabled;
      });
  }

  function updateCount() {
    var selected = boxes.filter(function (box) {
      return box.checked;
    }).length;
    if (count) count.textContent = selected + " selected";
  }

  function updateSelectAll() {
    if (!selectAll) return;
    var visible = visibleBoxes();
    var checked = visible.filter(function (box) {
      return box.checked;
    }).length;
    selectAll.checked = visible.length > 0 && checked === visible.length;
    selectAll.indeterminate = checked > 0 && checked < visible.length;
  }

  function applyFilters() {
    var term = (search && search.value ? search.value : "").trim().toLowerCase();
    var groupId = group ? group.value : "";

    rows.forEach(function (row) {
      var matchesTerm =
        !term || (row.dataset.search || "").indexOf(term) !== -1;
      var matchesGroup =
        !groupId ||
        (row.dataset.groups || "").split(/\s+/).indexOf(groupId) !== -1;
      row.hidden = !(matchesTerm && matchesGroup);
    });

    updateSelectAll();
    updateCount();
  }

  if (search) search.addEventListener("input", applyFilters);
  if (group) group.addEventListener("change", applyFilters);

  if (selectAll) {
    selectAll.addEventListener("change", function () {
      visibleBoxes().forEach(function (box) {
        box.checked = selectAll.checked;
      });
      updateCount();
      updateSelectAll();
    });
  }

  boxes.forEach(function (box) {
    box.addEventListener("change", function () {
      updateCount();
      updateSelectAll();
    });
  });

  applyFilters();
})();
